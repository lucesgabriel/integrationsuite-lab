# SAP CPI Groovy Mapping Templates

Coleccion de 14 templates de mapeo Groovy para SAP Cloud Integration (CPI). Cada template demuestra un patron de conversion entre formatos: IDoc, JSON, XML y CSV.

Cada carpeta `Txx_*` contiene:

- documentacion funcional del template;
- documentacion del script Groovy asociado en formato Markdown.

Nota: estos archivos son ejemplos documentados. Antes de usarlos en un iFlow real, extraer o adaptar el bloque Groovy y comentar `TestRun()` para SAP Cloud Integration.

## Mapa de templates

```
                    ┌─────────────────────────────────────────────────────────┐
                    │                  FORMATOS DE ENTRADA                    │
                    │   IDoc XML    │   JSON Tree   │   JSON Flat │  XML Flat │
                    ├───────────────┼───────────────┼─────────────┼───────────┤
  F  JSON Tree      │     T01       │               │             │           │
  O  XML Tree       │     T02       │               │             │           │
  R  IDoc XML       │               │     T03       │             │           │
  M  IDoc XML       │               │               │     T04*    │           │
  A  JSON Flat      │     T05       │     T07       │             │           │
  T  XML Flat       │     T06       │     T08       │             │           │
  O  JSON           │               │               │             │           │
  S  JSON (csv hdr) │               │               │   T09 A+M   │           │
     XML (csv hdr)  │               │               │   T10 A+M   │           │
  S  JSON (no hdr)  │               │               │   T11 A+M   │           │
  A  XML (no hdr)   │               │               │   T12 A+M   │           │
  L  CSV            │               │               │     T13     │    T14    │
  I                                                                            │
  D  * T04 usa XML Tree como input, no XML Flat                               │
  A                                                                            │
                    └─────────────────────────────────────────────────────────┘
```

## Indice de templates

### Grupo 1: IDOC ↔ Estructuras Jerarquicas (Tree)

| Template | Conversion | Script documentado | Documentacion |
|----------|-----------|--------|---------------|
| **T01** | IDoc XML → JSON Tree | [IDOC_Orders_to_Tree_JSON.md](T01_IDOC_to_TREE_JSON/IDOC_Orders_to_Tree_JSON.md) | [T01_IDOC_to_TREE_JSON.md](T01_IDOC_to_TREE_JSON/T01_IDOC_to_TREE_JSON.md) |
| **T02** | IDoc XML → XML Tree | [IDOC_Orders_to_Tree_XML.md](T02_IDOC_to_TREE_XML/IDOC_Orders_to_Tree_XML.md) | [T02_IDOC_to_TREE_XML.md](T02_IDOC_to_TREE_XML/T02_IDOC_to_TREE_XML.md) |
| **T03** | JSON Tree → IDoc XML | [JSON_Tree_to_IDOC_Orders.md](T03_JSON_TREE_to_IDOC/JSON_Tree_to_IDOC_Orders.md) | [T03_JSON_TREE_to_IDOC.md](T03_JSON_TREE_to_IDOC/T03_JSON_TREE_to_IDOC.md) |
| **T04** | XML Tree → IDoc XML | [XML_Tree_to_IDOC_Orders.md](T04_XML_TREE_to_IDOC/XML_Tree_to_IDOC_Orders.md) | [T04_XML_TREE_to_IDOC.md](T04_XML_TREE_to_IDOC/T04_XML_TREE_to_IDOC.md) |

### Grupo 2: Aplanamiento (Flattenning)

| Template | Conversion | Script documentado | Documentacion |
|----------|-----------|--------|---------------|
| **T05** | IDoc XML → JSON Flat | [IDOC_Orders_to_Flat_JSON.md](T05_IDOC_to_FLAT_JSON/IDOC_Orders_to_Flat_JSON.md) | [T05_IDOC_to_FLAT_JSON.md](T05_IDOC_to_FLAT_JSON/T05_IDOC_to_FLAT_JSON.md) |
| **T06** | IDoc XML → XML Flat | [IDOC_Orders_to_Flat_XML.md](T06_IDOC_to_FLAT_XML/IDOC_Orders_to_Flat_XML.md) | [T06_IDOC_to_FLAT_XML.md](T06_IDOC_to_FLAT_XML/T06_IDOC_to_FLAT_XML.md) |
| **T07** | JSON Tree → JSON Flat | [JSON_Tree_to_Flat_JSON.md](T07_JSON_TREE_to_FLAT_JSON/JSON_Tree_to_Flat_JSON.md) | [T07_JSON_TREE_to_FLAT_JSON.md](T07_JSON_TREE_to_FLAT_JSON/T07_JSON_TREE_to_FLAT_JSON.md) |
| **T08** | JSON Tree → XML Flat | [JSON_Tree_to_Flat_XML.md](T08_JSON_TREE_to_FLAT_XML/JSON_Tree_to_Flat_XML.md) | [T08_JSON_TREE_to_FLAT_XML.md](T08_JSON_TREE_to_FLAT_XML/T08_JSON_TREE_to_FLAT_XML.md) |

### Grupo 3: CSV con Header

| Template | Conversion | Scripts documentados | Documentacion |
|----------|-----------|---------|---------------|
| **T09** | CSV (con header) → JSON | [Auto](T09_CSV_with_Header_to_JSON/CSV_with_Header_to_JSON_Auto.md) + [Manual](T09_CSV_with_Header_to_JSON/CSV_with_Header_to_JSON_Manual.md) | [T09_CSV_with_Header_to_JSON.md](T09_CSV_with_Header_to_JSON/T09_CSV_with_Header_to_JSON.md) |
| **T10** | CSV (con header) → XML | [Auto](T10_CSV_with_Header_to_XML/CSV_with_Header_to_XML_Auto.md) + [Manual](T10_CSV_with_Header_to_XML/CSV_with_Header_to_XML_Manual.md) | [T10_CSV_with_Header_to_XML.md](T10_CSV_with_Header_to_XML/T10_CSV_with_Header_to_XML.md) |

### Grupo 4: CSV sin Header

| Template | Conversion | Scripts documentados | Documentacion |
|----------|-----------|---------|---------------|
| **T11** | CSV (sin header) → JSON | [Auto](T11_CSV_no_Header_to_JSON/CSV_no_Header_to_JSON_Auto.md) + [Manual](T11_CSV_no_Header_to_JSON/CSV_no_Header_to_JSON_Manual.md) | [T11_CSV_no_Header_to_JSON.md](T11_CSV_no_Header_to_JSON/T11_CSV_no_Header_to_JSON.md) |
| **T12** | CSV (sin header) → XML | [Auto](T12_CSV_no_Header_to_XML/CSV_no_Header_to_XML_Auto.md) + [Manual](T12_CSV_no_Header_to_XML/CSV_no_Header_to_XML_Manual.md) | [T12_CSV_no_Header_to_XML.md](T12_CSV_no_Header_to_XML/T12_CSV_no_Header_to_XML.md) |

### Grupo 5: Conversion a CSV

| Template | Conversion | Script documentado | Documentacion |
|----------|-----------|--------|---------------|
| **T13** | JSON Flat → CSV | [JSON_FLAT_to_CSV.md](T13_JSON_FLAT_to_CSV/JSON_FLAT_to_CSV.md) | [T13_JSON_FLAT_to_CSV.md](T13_JSON_FLAT_to_CSV/T13_JSON_FLAT_to_CSV.md) |
| **T14** | XML Flat → CSV | [XML_FLAT_to_CSV.md](T14_XML_FLAT_to_CSV/XML_FLAT_to_CSV.md) | [T14_XML_FLAT_to_CSV.md](T14_XML_FLAT_to_CSV/T14_XML_FLAT_to_CSV.md) |

## Tecnologias y librerias

| Libreria | Uso | Templates |
|----------|-----|-----------|
| `groovy.json.JsonSlurper` | Parsear JSON de entrada | T03, T07, T08, T13 |
| `groovy.json.StreamingJsonBuilder` | Generar JSON de salida | T01, T05, T07, T09, T11 |
| `groovy.json.JsonOutput` | Formatear JSON (prettyPrint) | T01, T05, T07, T09, T11 |
| `groovy.xml.XmlSlurper` | Parsear XML de entrada | T01-T06, T08, T14 |
| `groovy.xml.StreamingMarkupBuilder` | Generar XML de salida | T02-T04, T06, T08, T10, T12 |
| `groovy.xml.XmlUtil` | Serializar XML (indentado) | T02-T04, T06, T08, T10, T12 |
| `org.supercsv.*` | Leer y escribir CSV | T09-T14 |

## Patron de estructura de cada script

```groovy
/* https://sapintegrationsuitecourse.com */
import ...

def Message processData(Message message) {
    // Entry point SAP CPI - NO modificar la firma
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()
    message.setBody(DoMapping(body, headers, properties))
    return message
}

// COMENTAR antes de subir a CPI - Solo para debug local
TestRun()

void TestRun() {
    // Lee archivo de input local y escribe archivo de output
}

def DoMapping(String body, Map headers, Map properties) {
    // LOGICA PRINCIPAL DE MAPEO
}
```

## Reglas importantes para uso en SAP CPI

1. **Comentar `TestRun()`** antes de subir el script a SAP CPI
2. Los archivos en la carpeta `Data/` son solo para **pruebas locales**
3. Los scripts en T03 y T04 requieren **propiedades del mensaje** (`ReceiverPort`, `ReceiverPartner`)
4. La libreria **SuperCSV** esta disponible en SAP CPI sin configuracion adicional
5. El metodo de entrada es siempre `processData(Message message)`

## Cadenas de conversion tipicas

```
IDoc SAP → JSON Tree (T01) → JSON Flat (T07) → CSV (T13)
IDoc SAP → XML Flat (T06) → CSV (T14)
CSV sin header (T11/T12) → IDoc via T03/T04
JSON Tree externo (T03) → IDoc SAP para posting
```
