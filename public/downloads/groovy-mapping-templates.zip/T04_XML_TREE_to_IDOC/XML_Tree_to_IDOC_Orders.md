# XML_Tree_to_IDOC_Orders.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T04 |
| **Archivo** | `XML_Tree_to_IDOC_Orders.groovy` |
| **Conversion** | XML Tree → IDoc XML (ORDERS05) |
| **Formato entrada** | XML (Tree jerarquico) |
| **Formato salida** | XML (IDoc SAP) |
| **Propiedades requeridas** | `ReceiverPort`, `ReceiverPartner` |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.xml.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    props.put("ReceiverPort", "SAPSID")
    props.put("ReceiverPartner", "SIDCLNT100")

    File inputFile = new File("$dataDir\\xml_tree.txt")
    File outputFile = new File("$dataDir\\xml_tree_to_idoc_orders_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {
    def InputPayload = new XmlSlurper().parseText(body)

    def builder = new StreamingMarkupBuilder()

    //Required Idoc Control Record variables
    def V_TABNAM = "EDI_DC 40"
    def V_DIRECT = "2"
    def V_IDOCTYP = "ORDERS05"
    def V_CIMTYP = ""
    def V_MESTYP = "ORDERS"
    def V_SNDPOR = "XYZPORT" //Any port name represent source system
    def V_SNDPRT = "LS"
    def V_SNDPFC = ""
    def V_SNDPRN = "XYZ" //Any source system name
    def V_RCVPOR = properties.get("ReceiverPort").toString()
    def V_RCVPRT = "LS"
    def V_RCVPFC = ""
    def V_RCVPRN = properties.get("ReceiverPartner").toString()

    // MAPPING
    def writer = builder.bind {
        mkp.xmlDeclaration()

        ORDERS05 {
            InputPayload.order.each { this_order ->
                IDOC(BEGIN: '1') {
                    EDI_DC40(BEGIN: '1') {
                        TABNAM("$V_TABNAM")
                        DIRECT("$V_DIRECT")
                        IDOCTYP("$V_IDOCTYP")
                        CIMTYP("$V_CIMTYP")
                        MESTYP("$V_MESTYP")
                        SNDPOR("$V_SNDPOR")
                        SNDPRT("$V_SNDPRT")
                        SNDPFC("$V_SNDPFC")
                        SNDPRN("$V_SNDPRN")
                        RCVPOR("$V_RCVPOR")
                        RCVPRT("$V_RCVPRT")
                        RCVPFC("$V_RCVPFC")
                        RCVPRN("$V_RCVPRN")
                    }

                    def this_header = this_order.header

                    E1EDK01(SEGMENT: '1') {
                        BELNR(this_header.order_no.toString())
                    }
                    E1EDK03(SEGMENT: '1') {
                        IDDAT("012")
                        DATUM(this_header.order_date.toString())
                    }
                    E1EDKA1(SEGMENT: '1') {
                        PARVW("AG")
                        DATUM(this_header.sold_to.toString())
                    }
                    E1EDKA1(SEGMENT: '1') {
                        PARVW("WE")
                        DATUM(this_header.ship_to.toString())
                    }

                    this_order.item.each{ this_item ->
                        E1EDP01(SEGMENT: '1') {
                            POSEX(this_item.line_item.toString())
                            MENGE(this_item.quantity.toString())
                            MENEE(this_item.quantity_uom.toString().toUpperCase())
                            NTGEW(this_item.weight.toString())
                            GEWEI(this_item.weight_uom.toString().toUpperCase())

                            this_item.schedule.line.each{ this_line ->
                                E1EDP20(SEGMENT: '1') {
                                    WMENG(this_line.schedule_qty.toString())
                                    EDATU(this_line.schedule_date.toString())
                                }
                            }

                            E1EDP19(SEGMENT: '1') {
                                QUALF("001")
                                String V_IDTNR = this_item.material.toString()
                                V_IDTNR = V_IDTNR.padLeft(18, "0")
                                IDTNR(V_IDTNR)
                            }
                        }
                    }
                }
            }
        }
    }

    // WRITING
    //def output = writer.toString()
    def output = XmlUtil.serialize(writer.toString())

    return output
}
```

---

## Explicacion por secciones

### 1. Diferencias criticas con T03 (JSON Tree → IDoc)

| Aspecto | T03 (JSON → IDoc) | T04 (XML → IDoc) |
|---------|-------------------|------------------|
| Parser entrada | `JsonSlurper` | `XmlSlurper` |
| Raiz de iteracion | `InputPayload.orders.each` | `InputPayload.order.each` |
| Acceso a campos | `this_header.order_no ?: ""` | `this_header.order_no.toString()` |
| Manejo de nulos | Operador Elvis `?:` | `.toString()` directo |
| Iteracion schedule | `this_item.schedule.each` | `this_item.schedule.line.each` |

### 2. Iteracion desde el XML de entrada

```groovy
// T03 (JSON): InputPayload.orders → array JSON
InputPayload.orders.each { this_order -> }

// T04 (XML): InputPayload.order → nodos XML <order>
InputPayload.order.each { this_order -> }
```

**Nota:** En el XML de entrada la raiz es `<orders>` con hijos `<order>`.
`XmlSlurper` navega: `InputPayload` = `<orders>`, entonces `InputPayload.order` = todos los `<order>`.

### 3. Acceso a campos del XML de entrada

```groovy
def this_header = this_order.header

E1EDK01(SEGMENT: '1') {
    BELNR(this_header.order_no.toString())   // XmlSlurper retorna GPathResult, no String
}
```

Con `XmlSlurper` todos los nodos son `GPathResult` → necesitan `.toString()` explicito.
Con `JsonSlurper` los valores ya son tipos primitivos de Groovy → se usa `?: ""` para nulls.

### 4. Acceso a schedules en XML (nodo `<line>`)

```groovy
// XML de entrada:
// <schedule>
//   <line>
//     <schedule_qty>10.000</schedule_qty>
//     <schedule_date>20211210</schedule_date>
//   </line>
// </schedule>

this_item.schedule.line.each { this_line ->
    E1EDP20(SEGMENT: '1') {
        WMENG(this_line.schedule_qty.toString())
        EDATU(this_line.schedule_date.toString())
    }
}
```

En T03 (JSON): `this_item.schedule` ya es un array de objetos directamente.
En T04 (XML): hay un nivel extra `<line>` → `this_item.schedule.line.each`.

### 5. Conversion de UOM a mayusculas (sin variable temporal)

```groovy
// T04: mas compacto, convierte directamente en la llamada
MENEE(this_item.quantity_uom.toString().toUpperCase())
GEWEI(this_item.weight_uom.toString().toUpperCase())

// T03: usa variable temporal
String V_MENEE = (this_item.quantity_uom ?: "").toUpperCase()
MENEE(V_MENEE)
```

### 6. Padding del material

```groovy
E1EDP19(SEGMENT: '1') {
    QUALF("001")
    String V_IDTNR = this_item.material.toString()  // XML → String
    V_IDTNR = V_IDTNR.padLeft(18, "0")              // "800111" → "000000000000800111"
    IDTNR(V_IDTNR)
}
```

---

## Mapeo de campos XML → IDoc

| Elemento XML entrada | Segmento IDoc | Campo IDoc | Transformacion |
|----------------------|---------------|------------|----------------|
| `order/header/order_no` | `E1EDK01` | `BELNR` | `.toString()` |
| `order/header/order_date` | `E1EDK03` | `DATUM` | `.toString()` (IDDAT="012") |
| `order/header/sold_to` | `E1EDKA1` | `DATUM` | `.toString()` (PARVW="AG") |
| `order/header/ship_to` | `E1EDKA1` | `DATUM` | `.toString()` (PARVW="WE") |
| `order/item/line_item` | `E1EDP01` | `POSEX` | `.toString()` |
| `order/item/quantity` | `E1EDP01` | `MENGE` | `.toString()` |
| `order/item/quantity_uom` | `E1EDP01` | `MENEE` | `.toString().toUpperCase()` |
| `order/item/weight` | `E1EDP01` | `NTGEW` | `.toString()` |
| `order/item/weight_uom` | `E1EDP01` | `GEWEI` | `.toString().toUpperCase()` |
| `order/item/schedule/line/schedule_qty` | `E1EDP20` | `WMENG` | `.toString()` |
| `order/item/schedule/line/schedule_date` | `E1EDP20` | `EDATU` | `.toString()` |
| `order/item/material` | `E1EDP19` | `IDTNR` | `.toString().padLeft(18,"0")` |
| Propiedad `ReceiverPort` | `EDI_DC40` | `RCVPOR` | `properties.get(...)` |
| Propiedad `ReceiverPartner` | `EDI_DC40` | `RCVPRN` | `properties.get(...)` |

---

## Notas para SAP CPI

- ⚠️ Comentar `TestRun()` antes de desplegar
- ⚠️ Configurar `ReceiverPort` y `ReceiverPartner` en **Content Modifier** previo
- ✅ Personalizar `V_SNDPOR` y `V_SNDPRN`
- ✅ El XML de entrada debe tener estructura `<orders><order><header>` y `<schedule><line>`
