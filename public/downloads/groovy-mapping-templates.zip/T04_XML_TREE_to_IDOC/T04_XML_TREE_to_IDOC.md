# T04 - XML Tree to IDOC

## Descripcion

Convierte una estructura XML jerarquica (arbol con ordenes, items y schedules) al formato IDoc XML SAP ORDERS05. Es el equivalente de T03 pero tomando XML como entrada en lugar de JSON.

## Transformacion

```
INPUT:  XML Tree (orders > order > header + item > schedule > line)
OUTPUT: IDOC XML (ORDERS05)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `XML_Tree_to_IDOC_Orders.groovy` | Script principal de mapeo |
| `Data/xml_tree.txt` | Datos de entrada de ejemplo (XML Tree) |
| `Data/xml_tree_to_idoc_orders_output.txt` | Salida esperada (IDOC XML) |

## Librerias utilizadas

```groovy
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.xml.*
```

- `XmlSlurper` - para parsear el input XML Tree
- `StreamingMarkupBuilder` - para construir el output IDoc XML
- `XmlUtil.serialize` - para formatear el XML resultante

## Propiedades de mensaje requeridas (CPI)

| Propiedad | Descripcion | Ejemplo |
|-----------|-------------|---------|
| `ReceiverPort` | Puerto receptor SAP | `SAPSID` |
| `ReceiverPartner` | Partner receptor SAP | `SIDCLNT100` |

## Comparacion T03 vs T04

| Aspecto | T03 (JSON Tree → IDoc) | T04 (XML Tree → IDoc) |
|---------|------------------------|------------------------|
| Parser de entrada | `JsonSlurper` | `XmlSlurper` |
| Iteracion raiz | `InputPayload.orders.each` | `InputPayload.order.each` |
| Acceso a schedule | `this_item.schedule.each` | `this_item.schedule.line.each` |
| Acceso a campos | `this_header.order_no ?: ""` | `this_header.order_no.toString()` |
| Manejo de nulos | Operador Elvis `?:` | `.toString()` directo |

## Logica de mapeo XML → IDoc

| Elemento XML | Segmento IDoc | Campo IDoc |
|--------------|---------------|------------|
| `header/order_no` | `E1EDK01` | `BELNR` |
| `header/order_date` | `E1EDK03` (IDDAT=012) | `DATUM` |
| `header/sold_to` | `E1EDKA1` (PARVW=AG) | `DATUM` |
| `header/ship_to` | `E1EDKA1` (PARVW=WE) | `DATUM` |
| `item/line_item` | `E1EDP01` | `POSEX` |
| `item/quantity` | `E1EDP01` | `MENGE` |
| `item/quantity_uom` | `E1EDP01` | `MENEE` (toUpperCase) |
| `item/weight` | `E1EDP01` | `NTGEW` |
| `item/weight_uom` | `E1EDP01` | `GEWEI` (toUpperCase) |
| `item/schedule/line/schedule_qty` | `E1EDP20` | `WMENG` |
| `item/schedule/line/schedule_date` | `E1EDP20` | `EDATU` |
| `item/material` | `E1EDP19` (QUALF=001) | `IDTNR` (padLeft 18) |

### Transformaciones especiales

- `quantity_uom` y `weight_uom`: `.toString().toUpperCase()`
- `material (IDTNR)`: `.padLeft(18, "0")` para rellenar 18 caracteres
- Schedules: iteracion sobre `this_item.schedule.line.each` (nodo `<line>` dentro de `<schedule>`)

## Estructura del script

```groovy
def Message processData(Message message)  // Entry point CPI
void TestRun()                            // Solo para debug local
def DoMapping(String body, Map headers, Map properties)  // Logica principal
```

> **Nota CPI:** Comentar `TestRun()` antes de subir a SAP CPI.

## Ejemplo de entrada (XML Tree)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<orders>
  <order>
    <header>
      <idoc_no>888888</idoc_no>
      <order_no>5000123456</order_no>
      <sold_to>AAAA-111</sold_to>
      <ship_to>BBBB-222</ship_to>
      <order_date>20211201</order_date>
    </header>
    <item>
      <line_item>00001</line_item>
      <material>800111</material>
      <quantity>10.000</quantity>
      <quantity_uom>pce</quantity_uom>
      <weight>20</weight>
      <weight_uom>kgm</weight_uom>
      <schedule>
        <line>
          <schedule_qty>10.000</schedule_qty>
          <schedule_date>20211210</schedule_date>
        </line>
      </schedule>
    </item>
  </order>
</orders>
```

## Ejemplo de salida (IDOC XML)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<ORDERS05>
  <IDOC BEGIN="1">
    <EDI_DC40 BEGIN="1">
      <TABNAM>EDI_DC 40</TABNAM>
      <DIRECT>2</DIRECT>
      <IDOCTYP>ORDERS05</IDOCTYP>
      <MESTYP>ORDERS</MESTYP>
      <SNDPOR>XYZPORT</SNDPOR>
      <SNDPRN>XYZ</SNDPRN>
      <RCVPOR>SAPSID</RCVPOR>
      <RCVPRN>SIDCLNT100</RCVPRN>
    </EDI_DC40>
    <E1EDK01 SEGMENT="1">
      <BELNR>5000123456</BELNR>
    </E1EDK01>
    <E1EDP01 SEGMENT="1">
      <POSEX>00001</POSEX>
      <MENGE>10.000</MENGE>
      <MENEE>PCE</MENEE>
      <E1EDP20 SEGMENT="1">
        <WMENG>10.000</WMENG>
        <EDATU>20211210</EDATU>
      </E1EDP20>
      <E1EDP19 SEGMENT="1">
        <QUALF>001</QUALF>
        <IDTNR>000000000000800111</IDTNR>
      </E1EDP19>
    </E1EDP01>
  </IDOC>
</ORDERS05>
```
