# CSV_no_Header_to_JSON_Manual.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T11 - Variante Manual |
| **Archivo** | `CSV_no_Header_to_JSON_Manual.groovy` |
| **Conversion** | CSV sin header → JSON (campos seleccionados manualmente) |
| **Formato entrada** | CSV sin primera fila de cabecera |
| **Formato salida** | JSON plano |
| **Libreria CSV** | SuperCSV (`org.supercsv`) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.StreamingJsonBuilder
import groovy.util.*
import groovy.xml.*
import org.supercsv.cellprocessor.*
import org.supercsv.cellprocessor.constraint.*
import org.supercsv.cellprocessor.ift.*
import org.supercsv.io.*
import org.supercsv.prefs.*
import org.supercsv.quote.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\csv_data_no_header.txt")
    File outputFile = new File("$dataDir\\csv_data_no_header_to_json_manual_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {

    //Standard CSV
    ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), CsvPreference.STANDARD_PREFERENCE)

    //Custom CsvPreference parameters
    //char quoteChar = '"'
    //int delimiterChar = ','
    //String endOfLine = "\r\n"
    //CsvPreference customCsvPreference = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
    //ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), customCsvPreference)

    String fieldList = "idoc_no,order_no,ship_to,sold_to,order_date,line_item,material,quantity,quantity_uom,weight,weight_uom"
    String[] header = fieldList.split(',')
    int columnsCount = header.length
    CellProcessor[] processor = new CellProcessor[columnsCount]

    def writer = new StringWriter()
    def builder = new StreamingJsonBuilder(writer)

    def v_row_list = []

    while ((rowMap = mapReader.read(header, processor)) != null) {
        v_row_list.add(rowMap)  // Sin renombrar - guarda con nombres de fieldList
    }

    builder {
        row(v_row_list) { rowMap ->
            "idoc_no"(rowMap["idoc_no"])
            "order_no"(rowMap["order_no"])
            "line_item"(rowMap["line_item"])
            "material"(rowMap["material"])
            "quantity"(rowMap["quantity"])
            "quantity_uom"(rowMap["quantity_uom"])
        }
    }

    def output = JsonOutput.prettyPrint(writer.toString())
}
```

---

## Explicacion por secciones

### 1. Diferencia con T11 Auto en el bucle de lectura

**T11 Auto:** Renombra con `formatFieldName` y guarda mapa renombrado
```groovy
while ((rowMap = mapReader.read(header, processor)) != null) {
    def rowMapRenamed = [:]
    header.each { this_field ->
        def fieldName = formatFieldName(this_field)
        rowMapRenamed.put(fieldName, fieldValue)
    }
    v_row_list.add(rowMapRenamed)
}
```

**T11 Manual:** Guarda el rowMap directamente (sin renombrar)
```groovy
while ((rowMap = mapReader.read(header, processor)) != null) {
    v_row_list.add(rowMap)  // rowMap usa los nombres de fieldList directamente
}
```

### 2. Diferencia en el bloque builder

**T11 Auto:** Itera dinamicamente todos los campos del mapa
```groovy
builder {
    row(v_row_list) { rowMap ->
        rowMap.each { rowField ->
            "$rowField.key"(rowField.value)  // Todos los campos
        }
    }
}
```

**T11 Manual:** Selecciona estaticamente los campos necesarios
```groovy
builder {
    row(v_row_list) { rowMap ->
        "idoc_no"(rowMap["idoc_no"])       // Solo campos seleccionados
        "order_no"(rowMap["order_no"])
        "line_item"(rowMap["line_item"])
        "material"(rowMap["material"])
        "quantity"(rowMap["quantity"])
        "quantity_uom"(rowMap["quantity_uom"])
    }
}
```

### 3. Acceso al rowMap con nombres de fieldList

Como la `fieldList` define los nombres con guion bajo (`idoc_no`, `order_no`, etc.), el acceso es directo:

```groovy
rowMap["idoc_no"]       // Columna 1 del CSV
rowMap["order_no"]      // Columna 2 del CSV
rowMap["line_item"]     // Columna 6 del CSV
rowMap["material"]      // Columna 7 del CSV
rowMap["quantity"]      // Columna 8 del CSV
rowMap["quantity_uom"]  // Columna 9 del CSV
```

**Campos omitidos en el output:**
- `ship_to` (columna 3)
- `sold_to` (columna 4)
- `order_date` (columna 5)
- `weight` (columna 10)
- `weight_uom` (columna 11)

### 4. Sin funcion formatFieldName

La variante Manual **no necesita** `formatFieldName()` porque:
- Los nombres en `fieldList` ya son validos como claves JSON
- Los nombres JSON de salida se definen explicitamente como literales

---

## Tabla comparativa T11 Auto vs Manual

| Aspecto | T11 Auto | T11 Manual |
|---------|----------|------------|
| `fieldList` | Si (igual en ambos) | Si (igual en ambos) |
| Bucle de lectura | Acumula con renombrado | Acumula sin renombrado |
| `formatFieldName()` | Si | No |
| Builder | Itera `rowMap.each {}` | Campos explícitos |
| Campos en JSON | Todos los de `fieldList` | Solo los seleccionados |
| `rowMap["nombre"]` | Con nombre sanitizado | Con nombre exacto de fieldList |

---

## Ejemplo de salida JSON (Manual - campos seleccionados)

```json
{
    "row": [
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "line_item": "00001",
            "material": "800111",
            "quantity": "10.000",
            "quantity_uom": "pce"
        },
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "line_item": "00002",
            "material": "800222",
            "quantity": "100.000",
            "quantity_uom": "pce"
        }
    ]
}
```

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ La `fieldList` sigue siendo necesaria para mapear columnas a nombres
- ✅ Solo incluir en el builder los campos que se necesitan en el output
- ✅ Para acceder a los campos del rowMap usar exactamente los nombres de `fieldList`
