# T11 - CSV no Header to JSON

## Descripcion

Convierte un archivo CSV **sin fila de cabecera** a formato JSON. Como el CSV no tiene nombres de columna, los nombres de campo se definen manualmente en el script mediante una lista `fieldList`. Incluye variantes **Auto** y **Manual**.

## Transformacion

```
INPUT:  CSV sin header (solo filas de datos, sin primera fila de nombres)
OUTPUT: JSON Flat (array de rows)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `CSV_no_Header_to_JSON_Auto.groovy` | Mapeo automatico usando fieldList |
| `CSV_no_Header_to_JSON_Manual.groovy` | Mapeo manual de campos seleccionados |
| `Data/csv_data_no_header.txt` | CSV sin header de ejemplo |
| `Data/csv_data_no_header_to_json_auto_output.txt` | Salida Auto |
| `Data/csv_data_no_header_to_json_manual_output.txt` | Salida Manual |

## Librerias utilizadas

```groovy
import groovy.json.JsonOutput
import groovy.json.StreamingJsonBuilder
import org.supercsv.cellprocessor.*
import org.supercsv.io.*
import org.supercsv.prefs.*
import org.supercsv.quote.*
```

## Diferencia clave con T09 (CSV with Header)

| Aspecto | T09 (con header) | T11 (sin header) |
|---------|------------------|------------------|
| Lectura de header | `mapReader.getHeader(true)` | **No se llama** - se define manualmente |
| Fuente de nombres | Primera fila del CSV | Variable `fieldList` en el script |
| CSV de entrada | Primera fila = nombres | Primera fila = primer dato |

## Definicion del header manual

En lugar de leer la primera fila del CSV, se define una lista de nombres de campo en el codigo:

```groovy
String fieldList = "idoc_no,order_no,ship_to,sold_to,order_date,line_item,material,quantity,quantity_uom,weight,weight_uom"
String[] header = fieldList.split(',')
int columnsCount = header.length
CellProcessor[] processor = new CellProcessor[columnsCount]
```

Los nombres se asignan a las columnas CSV en orden posicional (columna 1 = `idoc_no`, columna 2 = `order_no`, etc.).

## Variante AUTO

Genera JSON con **todos los campos** de `fieldList`, sanitizando nombres de campo:

```groovy
while ((rowMap = mapReader.read(header, processor)) != null) {
    def rowMapRenamed = [:]
    header.each { this_field ->
        def fieldName = formatFieldName(this_field)
        def fieldValue = rowMap[this_field]
        rowMapRenamed.put(fieldName, fieldValue)
    }
    v_row_list.add(rowMapRenamed)
}

builder {
    row(v_row_list) { rowMap ->
        rowMap.each { rowField ->
            "$rowField.key"(rowField.value)
        }
    }
}
```

Como los nombres en `fieldList` ya son validos (solo letras, numeros, guion bajo), `formatFieldName()` no cambia nada en este caso.

## Variante MANUAL

Selecciona solo **campos especificos** de la lista completa:

```groovy
builder {
    row(v_row_list) { rowMap ->
        "idoc_no"(rowMap["idoc_no"])
        "order_no"(rowMap["order_no"])
        "line_item"(rowMap["line_item"])
        "material"(rowMap["material"])
        "quantity"(rowMap["quantity"])
        "quantity_uom"(rowMap["quantity_uom"])
    }
}
```

## Ejemplo de entrada (CSV sin header)

```csv
888888,5000123456,BBBB-222,AAAA-111,20211201,00001,800111,10.000,pce,20,kgm
888888,5000123456,BBBB-222,AAAA-111,20211201,00002,800222,100.000,pce,200,kgm
```

## Correspondencia columna → campo

| Posicion | Valor ejemplo | Nombre asignado |
|----------|---------------|-----------------|
| 1 | `888888` | `idoc_no` |
| 2 | `5000123456` | `order_no` |
| 3 | `BBBB-222` | `ship_to` |
| 4 | `AAAA-111` | `sold_to` |
| 5 | `20211201` | `order_date` |
| 6 | `00001` | `line_item` |
| 7 | `800111` | `material` |
| 8 | `10.000` | `quantity` |
| 9 | `pce` | `quantity_uom` |
| 10 | `20` | `weight` |
| 11 | `kgm` | `weight_uom` |

## Ejemplo de salida Auto (JSON)

```json
{
    "row": [
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00001",
            "material": "800111",
            "quantity": "10.000",
            "quantity_uom": "pce",
            "weight": "20",
            "weight_uom": "kgm"
        },
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00002",
            "material": "800222",
            "quantity": "100.000",
            "quantity_uom": "pce",
            "weight": "200",
            "weight_uom": "kgm"
        }
    ]
}
```

## Ejemplo de salida Manual (JSON)

```json
{
    "row": [
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "line_item": "00001",
            "material": "800111",
            "quantity": "10.000",
            "quantity_uom": "pce"
        }
    ]
}
```
