# CSV_no_Header_to_JSON_Auto.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T11 - Variante Auto |
| **Archivo** | `CSV_no_Header_to_JSON_Auto.groovy` |
| **Conversion** | CSV sin header → JSON (todos los campos via fieldList) |
| **Formato entrada** | CSV sin primera fila de cabecera |
| **Formato salida** | JSON plano |
| **Libreria CSV** | SuperCSV (`org.supercsv`) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.StreamingJsonBuilder
import groovy.util.*
import groovy.xml.*
import org.supercsv.cellprocessor.*
import org.supercsv.cellprocessor.constraint.*
import org.supercsv.cellprocessor.ift.*
import org.supercsv.io.*
import org.supercsv.prefs.*
import org.supercsv.quote.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\csv_data_no_header.txt")
    File outputFile = new File("$dataDir\\csv_data_no_header_to_json_auto_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {

    //Standard CSV
    ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), CsvPreference.STANDARD_PREFERENCE)

    //Custom CsvPreference parameters
//    char quoteChar = '"'
//    int delimiterChar = ','
//    String endOfLine = "\r\n"
//    CsvPreference customCsvPreference = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
//    ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), customCsvPreference)

    String fieldList = "idoc_no,order_no,ship_to,sold_to,order_date,line_item,material,quantity,quantity_uom,weight,weight_uom"
    String[] header = fieldList.split(',')
    int columnsCount = header.length
    CellProcessor[] processor = new CellProcessor[columnsCount]

    def writer = new StringWriter()
    def builder = new StreamingJsonBuilder(writer)

    def v_row_list = []

    while ((rowMap = mapReader.read(header, processor)) != null) {
        def rowMapRenamed = [:]
        header.each { this_field ->
            def fieldName = formatFieldName(this_field)
            def fieldValue = rowMap[this_field]
            rowMapRenamed.put(fieldName, fieldValue)
        }
        v_row_list.add(rowMapRenamed)
    }

    builder {
        row(v_row_list) { rowMap ->
            rowMap.each { rowField ->
                "$rowField.key"(rowField.value)
            }
        }
    }

    def output = JsonOutput.prettyPrint(writer.toString())
}

def formatFieldName(String fieldName) {
    fieldName = fieldName.replaceAll("[^a-zA-Z0-9_]", "")
    //fieldName = fieldName.toLowerCase()
    return fieldName
}
```

---

## Explicacion por secciones

### 1. Diferencia fundamental con T09 Auto (CSV con header)

```groovy
// T09 Auto (CSV CON header):
String[] header = mapReader.getHeader(true)
// Lee la primera fila del CSV como header → avanza al primer dato

// T11 Auto (CSV SIN header):
String fieldList = "idoc_no,order_no,ship_to,sold_to,order_date,line_item,material,quantity,quantity_uom,weight,weight_uom"
String[] header = fieldList.split(',')
// Define el header manualmente → el CSV completo son datos
```

### 2. La fieldList como header virtual

```groovy
String fieldList = "idoc_no,order_no,ship_to,sold_to,order_date,line_item,material,quantity,quantity_uom,weight,weight_uom"
String[] header = fieldList.split(',')
// header = ["idoc_no", "order_no", "ship_to", "sold_to", "order_date",
//           "line_item", "material", "quantity", "quantity_uom", "weight", "weight_uom"]
```

Los nombres en `fieldList` se asignan por **posicion** a las columnas del CSV:
- Columna 1 → `idoc_no`
- Columna 2 → `order_no`
- Columna 3 → `ship_to`
- ... y así sucesivamente

### 3. CSV de entrada (sin header)

```
888888,5000123456,BBBB-222,AAAA-111,20211201,00001,800111,10.000,pce,20,kgm
888888,5000123456,BBBB-222,AAAA-111,20211201,00002,800222,100.000,pce,200,kgm
```

La primera fila **ya es un dato** (no el header). SuperCSV lee desde la primera fila usando los nombres de `fieldList`.

### 4. Bucle de lectura y renombrado Auto

```groovy
while ((rowMap = mapReader.read(header, processor)) != null) {
    // rowMap = {"idoc_no": "888888", "order_no": "5000123456", ...}
    // (usando los nombres de fieldList como claves)

    def rowMapRenamed = [:]
    header.each { this_field ->
        def fieldName  = formatFieldName(this_field)  // "idoc_no" → "idoc_no" (sin cambios)
        def fieldValue = rowMap[this_field]
        rowMapRenamed.put(fieldName, fieldValue)
    }
    v_row_list.add(rowMapRenamed)
}
```

**Nota:** Como los nombres en `fieldList` ya son validos (solo letras, numeros, guion bajo), `formatFieldName()` no modifica nada en este caso. La funcion es la misma por consistencia con T09.

### 5. Correspondencia columna CSV → campo JSON

| Posicion | Valor CSV | Nombre en fieldList | Nombre JSON salida |
|----------|-----------|---------------------|-------------------|
| 1 | `888888` | `idoc_no` | `idoc_no` |
| 2 | `5000123456` | `order_no` | `order_no` |
| 3 | `BBBB-222` | `ship_to` | `ship_to` |
| 4 | `AAAA-111` | `sold_to` | `sold_to` |
| 5 | `20211201` | `order_date` | `order_date` |
| 6 | `00001` | `line_item` | `line_item` |
| 7 | `800111` | `material` | `material` |
| 8 | `10.000` | `quantity` | `quantity` |
| 9 | `pce` | `quantity_uom` | `quantity_uom` |
| 10 | `20` | `weight` | `weight` |
| 11 | `kgm` | `weight_uom` | `weight_uom` |

---

## Ejemplo de salida JSON (Auto - todos los campos)

```json
{
    "row": [
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00001",
            "material": "800111",
            "quantity": "10.000",
            "quantity_uom": "pce",
            "weight": "20",
            "weight_uom": "kgm"
        },
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00002",
            "material": "800222",
            "quantity": "100.000",
            "quantity_uom": "pce",
            "weight": "200",
            "weight_uom": "kgm"
        }
    ]
}
```

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ El numero de campos en `fieldList` debe coincidir con el numero de columnas del CSV
- ✅ El orden en `fieldList` debe coincidir exactamente con el orden de columnas del CSV
- ⚠️ Si el CSV tiene mas columnas que nombres en `fieldList`, las columnas extra se ignoraran
- ⚠️ Si `fieldList` tiene mas nombres que columnas en el CSV, SuperCSV puede lanzar error
