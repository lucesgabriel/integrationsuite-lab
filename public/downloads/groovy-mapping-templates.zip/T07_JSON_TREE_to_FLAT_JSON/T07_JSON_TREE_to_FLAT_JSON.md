# T07 - JSON Tree to Flat JSON

## Descripcion

Convierte una estructura JSON jerarquica (arbol con ordenes, items y schedules anidados) a un JSON plano (flat) donde cada fila representa una combinacion de cabecera + item + schedule. Transforma de JSON a JSON cambiando la estructura de jerarquica a plana.

## Transformacion

```
INPUT:  JSON Tree (orders > header + items > schedule)
OUTPUT: JSON Flat (array de rows - una fila por schedule)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `JSON_Tree_to_Flat_JSON.groovy` | Script principal de mapeo |
| `Data/json_tree.txt` | Datos de entrada de ejemplo (JSON Tree) |
| `Data/json_tree_to_flat_json_output.txt` | Salida esperada (JSON Flat) |

## Librerias utilizadas

```groovy
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.xml.*
```

- `JsonSlurper` - para parsear el input JSON Tree
- `StreamingJsonBuilder` - para construir el output JSON Flat
- `JsonOutput.prettyPrint` - para formatear el JSON

## Logica de flattenning

```
JSON Tree:                    JSON Flat:
orders[0]                     row[0]: header + item[0] + schedule[0]
  header                      row[1]: header + item[1] + schedule[0]
  item[0]                     row[2]: header + item[1] + schedule[1]
    schedule[0]
  item[1]
    schedule[0]
    schedule[1]
```

### Iteracion de tres niveles

```groovy
InputPayload.orders.each { this_order ->
    def this_header = this_order.header
    // extraer campos cabecera

    this_order.item.each { this_item ->
        // extraer campos item

        this_item.schedule.each { this_schedule ->
            // extraer campos schedule
            // crear fila plana y agregar a lista
            v_row_list.add(v_row)
        }
    }
}
```

## Campos de entrada (JSON Tree)

```json
{
    "orders": [{
        "header": {
            "idoc_no", "order_no", "sold_to", "ship_to", "order_date"
        },
        "item": [{
            "line_item", "material", "quantity", "quantity_uom",
            "weight", "weight_uom",
            "schedule": [{ "schedule_qty", "schedule_date" }]
        }]
    }]
}
```

## Campos de salida (JSON Flat por row)

| Campo | Fuente JSON Tree |
|-------|-----------------|
| `idoc_no` | `header.idoc_no` |
| `order_no` | `header.order_no` |
| `ship_to` | `header.ship_to` |
| `sold_to` | `header.sold_to` |
| `order_date` | `header.order_date` |
| `line_item` | `item.line_item` |
| `material` | `item.material` |
| `schedule_qty` | `item.schedule.schedule_qty` |
| `schedule_date` | `item.schedule.schedule_date` |

**Nota:** Los campos `quantity`, `quantity_uom`, `weight`, `weight_uom` del item no se incluyen en el output flat (se seleccionan solo los campos necesarios).

## Manejo de valores nulos

Se usa el operador Elvis `?:` para todos los campos:
```groovy
String v_idoc_no = this_header.idoc_no ?: ""
String v_order_no = this_header.order_no ?: ""
```

## Estructura del script

```groovy
def Message processData(Message message)  // Entry point CPI
void TestRun()                            // Solo para debug local
def DoMapping(String body, Map headers, Map properties)  // Logica principal
```

> **Nota CPI:** Comentar `TestRun()` antes de subir a SAP CPI.

## Ejemplo de entrada (JSON Tree)

```json
{
    "orders": [{
        "header": {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "sold_to": "AAAA-111",
            "ship_to": "BBBB-222",
            "order_date": "20211201"
        },
        "item": [
            {
                "line_item": "00001",
                "material": "800111",
                "schedule": [{ "schedule_qty": "10.000", "schedule_date": "20211210" }]
            },
            {
                "line_item": "00002",
                "material": "800222",
                "schedule": [
                    { "schedule_qty": "40.000", "schedule_date": "20211210" },
                    { "schedule_qty": "60.000", "schedule_date": "20211220" }
                ]
            }
        ]
    }]
}
```

## Ejemplo de salida (JSON Flat)

```json
{
    "row": [
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00001",
            "material": "800111",
            "schedule_qty": "10.000",
            "schedule_date": "20211210"
        },
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00002",
            "material": "800222",
            "schedule_qty": "40.000",
            "schedule_date": "20211210"
        },
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00002",
            "material": "800222",
            "schedule_qty": "60.000",
            "schedule_date": "20211220"
        }
    ]
}
```

## Relacion con otros templates

```
T01 (IDOC → JSON Tree)  ──>  T07 (JSON Tree → JSON Flat)
T05 (IDOC → JSON Flat)       [mismo resultado final]
```
