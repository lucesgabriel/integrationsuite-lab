# JSON_Tree_to_Flat_JSON.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T07 |
| **Archivo** | `JSON_Tree_to_Flat_JSON.groovy` |
| **Conversion** | JSON Tree → JSON Flat (array de rows) |
| **Formato entrada** | JSON jerarquico |
| **Formato salida** | JSON plano |
| **Patron** | Flattenning (aplanamiento) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.xml.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\json_tree.txt")
    File outputFile = new File("$dataDir\\json_tree_to_flat_json_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {
    def InputPayload = new JsonSlurper().parseText(body)

    def writer = new StringWriter()
    def builder = new StreamingJsonBuilder(writer)

    def v_row_list = []

    InputPayload.orders.each { this_order ->

        def this_header = this_order.header

        String v_idoc_no    = this_header.idoc_no    ?: ""
        String v_order_no   = this_header.order_no   ?: ""
        String v_ship_to    = this_header.ship_to    ?: ""
        String v_sold_to    = this_header.sold_to    ?: ""
        String v_order_date = this_header.order_date ?: ""

        this_order.item.each { this_item ->
            String v_line_item = this_item.line_item ?: ""
            String v_material  = this_item.material  ?: ""

            this_item.schedule.each { this_schedule ->
                String v_schedule_qty  = this_schedule.schedule_qty  ?: ""
                String v_schedule_date = this_schedule.schedule_date ?: ""

                def v_row = [:]
                v_row.idoc_no       = v_idoc_no
                v_row.order_no      = v_order_no
                v_row.ship_to       = v_ship_to
                v_row.sold_to       = v_sold_to
                v_row.order_date    = v_order_date
                v_row.line_item     = v_line_item
                v_row.material      = v_material
                v_row.schedule_qty  = v_schedule_qty
                v_row.schedule_date = v_schedule_date

                v_row_list.add(v_row)
            }
        }
    }

    // MAPPING
    builder {
        row(v_row_list) { this_row ->
            idoc_no(this_row.idoc_no)
            order_no(this_row.order_no)
            ship_to(this_row.ship_to)
            sold_to(this_row.sold_to)
            order_date(this_row.order_date)
            line_item(this_row.line_item)
            material(this_row.material)
            schedule_qty(this_row.schedule_qty)
            schedule_date(this_row.schedule_date)
        }
    }

    def output = JsonOutput.prettyPrint(writer.toString())

    return output
}
```

---

## Explicacion por secciones

### 1. Comparacion con T05 (IDOC → JSON Flat)

La logica es identica en concepto, pero el input es **JSON** en lugar de **XML IDoc**:

| Aspecto | T05 (IDoc → JSON Flat) | T07 (JSON Tree → JSON Flat) |
|---------|------------------------|------------------------------|
| Parser entrada | `XmlSlurper` | `JsonSlurper` |
| Raiz de iteracion | `InputPayload.IDOC.each` | `InputPayload.orders.each` |
| Acceso a cabecera | Segmentos IDoc directos | `this_order.header` sub-objeto |
| Manejo de nulos | `.toString()` + variable vacia | Operador Elvis `?: ""` |
| Iteracion schedule | `this_E1EDP01.E1EDP20.each` | `this_item.schedule.each` |

### 2. Acceso a la cabecera JSON

```groovy
InputPayload.orders.each { this_order ->
    def this_header = this_order.header   // Referencia al sub-objeto header

    String v_idoc_no    = this_header.idoc_no    ?: ""   // Elvis: null → ""
    String v_order_no   = this_header.order_no   ?: ""
    String v_ship_to    = this_header.ship_to    ?: ""
    String v_sold_to    = this_header.sold_to    ?: ""
    String v_order_date = this_header.order_date ?: ""
```

### 3. Iteracion de items y schedules JSON

```groovy
this_order.item.each { this_item ->
    // Los items son un array JSON directamente accesible
    String v_line_item = this_item.line_item ?: ""
    String v_material  = this_item.material  ?: ""

    // No necesita filtrar por QUALF como en IDoc
    // El material ya viene directamente en el JSON

    this_item.schedule.each { this_schedule ->
        // schedules es un array JSON directamente (no <line> XML)
        String v_schedule_qty  = this_schedule.schedule_qty  ?: ""
        String v_schedule_date = this_schedule.schedule_date ?: ""

        // Crear fila plana
        def v_row = [:]
        // ... llenar con datos de los tres niveles
        v_row_list.add(v_row)
    }
}
```

### 4. Diferencia en acceso al material vs IDoc

**En T05 (IDoc):** el material requiere filtrar el segmento `E1EDP19` por `QUALF=001`:
```groovy
this_E1EDP01.E1EDP19.each { this_E1EDP19 ->
    if (this_E1EDP19.QUALF.toString() == "001") {
        v_material = this_E1EDP19.IDTNR.toString().replaceFirst("^0*", "")
    }
}
```

**En T07 (JSON):** el material es un campo directo del item:
```groovy
String v_material = this_item.material ?: ""
// Simple, sin filtros adicionales
```

### 5. Campos omitidos en el flat output

El JSON Tree de entrada tiene campos adicionales (`quantity`, `quantity_uom`, `weight`, `weight_uom`) que **no se incluyen** en el flat output. Solo se mapean los campos necesarios:

| Campo JSON entrada | Incluido en flat output |
|--------------------|------------------------|
| `item.line_item` | ✅ Si |
| `item.material` | ✅ Si |
| `item.quantity` | ❌ No |
| `item.quantity_uom` | ❌ No |
| `item.weight` | ❌ No |
| `item.weight_uom` | ❌ No |
| `item.schedule.schedule_qty` | ✅ Si |
| `item.schedule.schedule_date` | ✅ Si |

---

## Campos del v_row (fila plana)

```
v_row = {
    idoc_no:       (nivel order/header)
    order_no:      (nivel order/header)
    ship_to:       (nivel order/header)
    sold_to:       (nivel order/header)
    order_date:    (nivel order/header)
    line_item:     (nivel item)
    material:      (nivel item)
    schedule_qty:  (nivel schedule)
    schedule_date: (nivel schedule)
}
```

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ No requiere propiedades del mensaje
- ✅ Compatible como input para T13 (JSON Flat → CSV)
- ✅ Import `groovy.xml.*` incluido aunque no se usa directamente (buena practica)
