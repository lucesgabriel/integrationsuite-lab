# JSON_Tree_to_IDOC_Orders.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T03 |
| **Archivo** | `JSON_Tree_to_IDOC_Orders.groovy` |
| **Conversion** | JSON Tree → IDoc XML (ORDERS05) |
| **Formato entrada** | JSON |
| **Formato salida** | XML (IDoc SAP) |
| **Propiedades requeridas** | `ReceiverPort`, `ReceiverPartner` |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.xml.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    props.put("ReceiverPort", "SAPSID")
    props.put("ReceiverPartner", "SIDCLNT100")

    File inputFile = new File("$dataDir\\json_tree.txt")
    File outputFile = new File("$dataDir\\json_tree_to_idoc_orders_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {
    def InputPayload = new JsonSlurper().parseText(body)

    def builder = new StreamingMarkupBuilder()

    //Required Idoc Control Record variables
    def V_TABNAM = "EDI_DC 40"
    def V_DIRECT = "2"
    def V_IDOCTYP = "ORDERS05"
    def V_CIMTYP = ""
    def V_MESTYP = "ORDERS"
    def V_SNDPOR = "XYZPORT" //Any port name represent source system
    def V_SNDPRT = "LS"
    def V_SNDPFC = ""
    def V_SNDPRN = "XYZ" //Any source system name
    def V_RCVPOR = properties.get("ReceiverPort").toString()
    def V_RCVPRT = "LS"
    def V_RCVPFC = ""
    def V_RCVPRN = properties.get("ReceiverPartner").toString()

    // MAPPING
    def writer = builder.bind {
        mkp.xmlDeclaration()

        ORDERS05 {
            InputPayload.orders.each { this_order ->
                IDOC(BEGIN: '1') {
                    EDI_DC40(BEGIN: '1') {
                        TABNAM("$V_TABNAM")
                        DIRECT("$V_DIRECT")
                        IDOCTYP("$V_IDOCTYP")
                        CIMTYP("$V_CIMTYP")
                        MESTYP("$V_MESTYP")
                        SNDPOR("$V_SNDPOR")
                        SNDPRT("$V_SNDPRT")
                        SNDPFC("$V_SNDPFC")
                        SNDPRN("$V_SNDPRN")
                        RCVPOR("$V_RCVPOR")
                        RCVPRT("$V_RCVPRT")
                        RCVPFC("$V_RCVPFC")
                        RCVPRN("$V_RCVPRN")
                    }

                    def this_header = this_order.header

                    E1EDK01(SEGMENT: '1') {
                        BELNR(this_header.order_no ?: "")
                    }
                    E1EDK03(SEGMENT: '1') {
                        IDDAT("012")
                        DATUM(this_header.order_date ?: "")
                    }
                    E1EDKA1(SEGMENT: '1') {
                        PARVW("AG")
                        DATUM(this_header.sold_to ?: "")
                    }
                    E1EDKA1(SEGMENT: '1') {
                        PARVW("WE")
                        DATUM(this_header.ship_to ?: "")
                    }

                    this_order.item.each{ this_item ->
                        E1EDP01(SEGMENT: '1') {
                            POSEX(this_item.line_item ?: "")
                            MENGE(this_item.quantity ?: "")

                            String V_MENEE = (this_item.quantity_uom ?: "").toUpperCase()
                            MENEE(V_MENEE)

                            NTGEW(this_item.weight ?: "")

                            String V_GEWEI = (this_item.weight_uom ?: "").toUpperCase()
                            GEWEI(V_GEWEI)

                            this_item.schedule.each{ this_schedule ->
                                E1EDP20(SEGMENT: '1') {
                                    WMENG(this_schedule.schedule_qty ?: "")
                                    EDATU(this_schedule.schedule_date ?: "")
                                }
                            }

                            E1EDP19(SEGMENT: '1') {
                                QUALF("001")
                                String V_IDTNR = this_item.material ?: ""
                                V_IDTNR = V_IDTNR.padLeft(18, "0")
                                IDTNR(V_IDTNR)
                            }
                        }
                    }
                }
            }
        }
    }

    // WRITING
    //def output = writer.toString()
    def output = XmlUtil.serialize(writer.toString())

    return output
}
```

---

## Explicacion por secciones

### 1. Imports

```groovy
import groovy.json.*   // JsonSlurper para parsear el JSON de entrada
import groovy.xml.*    // StreamingMarkupBuilder, XmlUtil para generar el IDoc XML
```

### 2. TestRun - Simulacion de propiedades

```groovy
void TestRun() {
    Map props = [:]
    props.put("ReceiverPort", "SAPSID")        // Simula propiedad del mensaje CPI
    props.put("ReceiverPartner", "SIDCLNT100") // Simula propiedad del mensaje CPI
    // ...
}
```

En SAP CPI estas propiedades se configuran con un **Content Modifier** antes del paso Groovy.

### 3. Variables del Control Record IDoc

```groovy
def V_TABNAM  = "EDI_DC 40"   // Nombre de tabla del control record
def V_DIRECT  = "2"            // Direccion: 2 = Outbound
def V_IDOCTYP = "ORDERS05"    // Tipo de IDoc
def V_MESTYP  = "ORDERS"      // Tipo de mensaje
def V_SNDPOR  = "XYZPORT"     // Puerto del sistema emisor (personalizar)
def V_SNDPRT  = "LS"          // Tipo de partner emisor: LS = Logical System
def V_SNDPRN  = "XYZ"         // Nombre del sistema emisor (personalizar)
def V_RCVPOR  = properties.get("ReceiverPort").toString()    // Desde propiedad CPI
def V_RCVPRN  = properties.get("ReceiverPartner").toString() // Desde propiedad CPI
```

### 4. Parseo del JSON de entrada

```groovy
def InputPayload = new JsonSlurper().parseText(body)
// Acceso: InputPayload.orders[0].header.order_no
//         InputPayload.orders[0].item[0].schedule[0].schedule_qty
```

### 5. Generacion del IDoc XML - Estructura raiz

```groovy
ORDERS05 {
    InputPayload.orders.each { this_order ->
        IDOC(BEGIN: '1') {          // Atributo BEGIN="1" en el elemento IDOC
            EDI_DC40(BEGIN: '1') {  // Control Record con atributo BEGIN="1"
                // ... campos del control record
            }
        }
    }
}
```

Los atributos XML se pasan como Map al elemento: `IDOC(BEGIN: '1')` → `<IDOC BEGIN="1">`.

### 6. Control Record (EDI_DC40)

```groovy
EDI_DC40(BEGIN: '1') {
    TABNAM("$V_TABNAM")   // Interpolacion de String Groovy
    DIRECT("$V_DIRECT")
    IDOCTYP("$V_IDOCTYP")
    // ...
    RCVPOR("$V_RCVPOR")   // Valor dinamico desde propiedades CPI
    RCVPRN("$V_RCVPRN")
}
```

### 7. Segmentos de cabecera del IDoc

```groovy
def this_header = this_order.header  // Referencia al sub-objeto header del JSON

E1EDK01(SEGMENT: '1') {
    BELNR(this_header.order_no ?: "")  // Operador Elvis: valor o cadena vacia
}
E1EDK03(SEGMENT: '1') {
    IDDAT("012")                       // Valor fijo: tipo de fecha = Orden de Compra
    DATUM(this_header.order_date ?: "")
}
E1EDKA1(SEGMENT: '1') {
    PARVW("AG")                        // Valor fijo: Sold-to Party
    DATUM(this_header.sold_to ?: "")
}
E1EDKA1(SEGMENT: '1') {
    PARVW("WE")                        // Valor fijo: Ship-to Party
    DATUM(this_header.ship_to ?: "")
}
```

### 8. Items y schedules del IDoc

```groovy
this_order.item.each { this_item ->
    E1EDP01(SEGMENT: '1') {
        POSEX(this_item.line_item ?: "")
        MENGE(this_item.quantity ?: "")

        // Conversion a MAYUSCULAS para MENEE y GEWEI
        String V_MENEE = (this_item.quantity_uom ?: "").toUpperCase()
        MENEE(V_MENEE)  // "pce" → "PCE"

        String V_GEWEI = (this_item.weight_uom ?: "").toUpperCase()
        GEWEI(V_GEWEI)  // "kgm" → "KGM"

        // Schedule lines como segmentos E1EDP20 dentro de E1EDP01
        this_item.schedule.each { this_schedule ->
            E1EDP20(SEGMENT: '1') {
                WMENG(this_schedule.schedule_qty ?: "")
                EDATU(this_schedule.schedule_date ?: "")
            }
        }

        // Material con padding de ceros a la izquierda
        E1EDP19(SEGMENT: '1') {
            QUALF("001")  // Valor fijo: material del comprador
            String V_IDTNR = this_item.material ?: ""
            V_IDTNR = V_IDTNR.padLeft(18, "0")  // "800111" → "000000000000800111"
            IDTNR(V_IDTNR)
        }
    }
}
```

---

## Mapeo de campos JSON → IDoc

| Campo JSON entrada | Segmento IDoc | Campo IDoc | Transformacion |
|--------------------|---------------|------------|----------------|
| `header.order_no` | `E1EDK01` | `BELNR` | `?: ""` |
| `header.order_date` | `E1EDK03` | `DATUM` | `?: ""` (IDDAT fijo="012") |
| `header.sold_to` | `E1EDKA1` | `DATUM` | `?: ""` (PARVW fijo="AG") |
| `header.ship_to` | `E1EDKA1` | `DATUM` | `?: ""` (PARVW fijo="WE") |
| `item.line_item` | `E1EDP01` | `POSEX` | `?: ""` |
| `item.quantity` | `E1EDP01` | `MENGE` | `?: ""` |
| `item.quantity_uom` | `E1EDP01` | `MENEE` | `.toUpperCase()` |
| `item.weight` | `E1EDP01` | `NTGEW` | `?: ""` |
| `item.weight_uom` | `E1EDP01` | `GEWEI` | `.toUpperCase()` |
| `item.schedule.schedule_qty` | `E1EDP20` | `WMENG` | `?: ""` |
| `item.schedule.schedule_date` | `E1EDP20` | `EDATU` | `?: ""` |
| `item.material` | `E1EDP19` | `IDTNR` | `.padLeft(18, "0")` (QUALF fijo="001") |
| Propiedad `ReceiverPort` | `EDI_DC40` | `RCVPOR` | `properties.get(...)` |
| Propiedad `ReceiverPartner` | `EDI_DC40` | `RCVPRN` | `properties.get(...)` |

---

## Notas para SAP CPI

- ⚠️ Comentar `TestRun()` antes de desplegar
- ⚠️ Configurar las propiedades `ReceiverPort` y `ReceiverPartner` en un **Content Modifier** previo
- ✅ Personalizar `V_SNDPOR` y `V_SNDPRN` con los valores del sistema emisor real
- ✅ `E1EDP19` se escribe **despues** de los `E1EDP20` (schedules antes del material en el segmento)
