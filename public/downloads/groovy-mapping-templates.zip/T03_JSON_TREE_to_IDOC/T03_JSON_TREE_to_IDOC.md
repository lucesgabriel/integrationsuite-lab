# T03 - JSON Tree to IDOC

## Descripcion

Convierte una estructura JSON jerarquica (arbol con ordenes, items y schedules) al formato IDoc XML SAP ORDERS05. Tambien requiere datos de las propiedades del mensaje CPI para el Control Record del IDoc.

## Transformacion

```
INPUT:  JSON Tree (orders > header + items > schedule)
OUTPUT: IDOC XML (ORDERS05)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `JSON_Tree_to_IDOC_Orders.groovy` | Script principal de mapeo |
| `Data/json_tree.txt` | Datos de entrada de ejemplo (JSON Tree) |
| `Data/json_tree_to_idoc_orders_output.txt` | Salida esperada (IDOC XML) |

## Librerias utilizadas

```groovy
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.xml.*
```

- `JsonSlurper` - para parsear el input JSON
- `StreamingMarkupBuilder` - para construir el output IDoc XML
- `XmlUtil.serialize` - para formatear el XML resultante

## Propiedades de mensaje requeridas (CPI)

El script lee dos propiedades del mensaje para construir el Control Record del IDoc:

| Propiedad | Descripcion | Ejemplo |
|-----------|-------------|---------|
| `ReceiverPort` | Puerto receptor SAP | `SAPSID` |
| `ReceiverPartner` | Partner receptor SAP | `SIDCLNT100` |

## Variables del Control Record IDoc

```groovy
def V_TABNAM  = "EDI_DC 40"
def V_DIRECT  = "2"           // Outbound
def V_IDOCTYP = "ORDERS05"
def V_CIMTYP  = ""
def V_MESTYP  = "ORDERS"
def V_SNDPOR  = "XYZPORT"    // Puerto fuente
def V_SNDPRT  = "LS"
def V_SNDPFC  = ""
def V_SNDPRN  = "XYZ"        // Sistema fuente
def V_RCVPOR  = properties.get("ReceiverPort")
def V_RCVPRT  = "LS"
def V_RCVPFC  = ""
def V_RCVPRN  = properties.get("ReceiverPartner")
```

## Logica de mapeo JSON -> IDoc

| Campo JSON | Segmento IDoc | Campo IDoc |
|------------|---------------|------------|
| `header.order_no` | `E1EDK01` | `BELNR` |
| `header.order_date` | `E1EDK03` (IDDAT=012) | `DATUM` |
| `header.sold_to` | `E1EDKA1` (PARVW=AG) | `DATUM` |
| `header.ship_to` | `E1EDKA1` (PARVW=WE) | `DATUM` |
| `item.line_item` | `E1EDP01` | `POSEX` |
| `item.quantity` | `E1EDP01` | `MENGE` |
| `item.quantity_uom` | `E1EDP01` | `MENEE` (toUpperCase) |
| `item.weight` | `E1EDP01` | `NTGEW` |
| `item.weight_uom` | `E1EDP01` | `GEWEI` (toUpperCase) |
| `item.schedule.schedule_qty` | `E1EDP20` | `WMENG` |
| `item.schedule.schedule_date` | `E1EDP20` | `EDATU` |
| `item.material` | `E1EDP19` (QUALF=001) | `IDTNR` (padLeft 18) |

### Transformaciones especiales

- `quantity_uom` y `weight_uom`: convertidos a MAYUSCULAS con `.toUpperCase()`
- `material (IDTNR)`: rellenado con ceros a la izquierda hasta 18 caracteres con `.padLeft(18, "0")`
- Uso del operador `?:` (Elvis) para manejo de valores nulos

## Estructura del script

```groovy
def Message processData(Message message)  // Entry point CPI
void TestRun()                            // Solo para debug local (con props simuladas)
def DoMapping(String body, Map headers, Map properties)  // Logica principal
```

> **Nota CPI:** Comentar `TestRun()` antes de subir a SAP CPI.

## Ejemplo de entrada (JSON Tree)

```json
{
    "orders": [
        {
            "header": {
                "idoc_no": "888888",
                "order_no": "5000123456",
                "sold_to": "AAAA-111",
                "ship_to": "BBBB-222",
                "order_date": "20211201"
            },
            "item": [
                {
                    "line_item": "00001",
                    "material": "800111",
                    "quantity": "10.000",
                    "quantity_uom": "pce",
                    "weight": "20",
                    "weight_uom": "kgm",
                    "schedule": [
                        {
                            "schedule_qty": "10.000",
                            "schedule_date": "20211210"
                        }
                    ]
                }
            ]
        }
    ]
}
```

## Ejemplo de salida (IDOC XML)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<ORDERS05>
  <IDOC BEGIN="1">
    <EDI_DC40 BEGIN="1">
      <TABNAM>EDI_DC 40</TABNAM>
      <DIRECT>2</DIRECT>
      <IDOCTYP>ORDERS05</IDOCTYP>
      <MESTYP>ORDERS</MESTYP>
      <SNDPOR>XYZPORT</SNDPOR>
      <SNDPRN>XYZ</SNDPRN>
      <RCVPOR>SAPSID</RCVPOR>
      <RCVPRN>SIDCLNT100</RCVPRN>
    </EDI_DC40>
    <E1EDK01 SEGMENT="1">
      <BELNR>5000123456</BELNR>
    </E1EDK01>
    <E1EDK03 SEGMENT="1">
      <IDDAT>012</IDDAT>
      <DATUM>20211201</DATUM>
    </E1EDK03>
    <E1EDKA1 SEGMENT="1">
      <PARVW>AG</PARVW>
      <DATUM>AAAA-111</DATUM>
    </E1EDKA1>
    <E1EDP01 SEGMENT="1">
      <POSEX>00001</POSEX>
      <MENGE>10.000</MENGE>
      <MENEE>PCE</MENEE>
      <NTGEW>20</NTGEW>
      <GEWEI>KGM</GEWEI>
      <E1EDP20 SEGMENT="1">
        <WMENG>10.000</WMENG>
        <EDATU>20211210</EDATU>
      </E1EDP20>
      <E1EDP19 SEGMENT="1">
        <QUALF>001</QUALF>
        <IDTNR>000000000000800111</IDTNR>
      </E1EDP19>
    </E1EDP01>
  </IDOC>
</ORDERS05>
```

## Estructura IDoc generada

```
ORDERS05
  IDOC (BEGIN=1)
    EDI_DC40 (Control Record)
    E1EDK01  (Order Data)
    E1EDK03  (Date - IDDAT=012)
    E1EDKA1  (Partner AG - Sold-to)
    E1EDKA1  (Partner WE - Ship-to)
    E1EDP01  (Item, por cada item)
      E1EDP20  (Schedule lines)
      E1EDP19  (Material QUALF=001)
```
