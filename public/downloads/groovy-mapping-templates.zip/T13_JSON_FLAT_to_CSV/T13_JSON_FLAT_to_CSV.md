# T13 - JSON Flat to CSV

## Descripcion

Convierte un JSON plano (flat con array de rows) a formato CSV. Soporta generacion automatica del header desde las claves del primer row JSON, escritura opcional del header, y multiples opciones de delimitador y modo de citas.

## Transformacion

```
INPUT:  JSON Flat ({ "row": [...] })
OUTPUT: CSV (con header y datos)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `JSON_FLAT_to_CSV.groovy` | Script principal de mapeo |
| `Data/json_flat.txt` | Datos de entrada de ejemplo (JSON Flat) |
| `Data/json_flat_to_csv_output.txt` | Salida esperada (CSV) |

## Librerias utilizadas

```groovy
import groovy.json.*
import groovy.xml.*
import org.supercsv.cellprocessor.ift.CellProcessor
import org.supercsv.io.CsvMapWriter
import org.supercsv.prefs.CsvPreference
import org.supercsv.quote.*
```

- `JsonSlurper` - para parsear el input JSON
- `CsvMapWriter` - escritor CSV de SuperCSV
- `CsvPreference` - configuracion del formato CSV

## Logica principal

### 1. Lectura del JSON

```groovy
def InputPayload = new JsonSlurper().parseText(body)
def v_row_list = []

// AUTO: toma todos los campos del JSON
InputPayload.row.each { this_row ->
    v_row_list.add(this_row)
}
```

### 2. Generacion automatica del header CSV

```groovy
// Extrae los nombres de campo del primer row
String fieldList = v_row_list[0].keySet().join(",")
String[] header = fieldList.split(',')
```

### 3. Escritura CSV

```groovy
def mapWriter = new CsvMapWriter(writer, CsvPreference.STANDARD_PREFERENCE)
mapWriter.writeHeader(header)  // Escribe fila de header
v_row_list.each { this_row ->
    mapWriter.write(this_row, header, processors)
}
mapWriter.close()
```

## Opciones de configuracion CSV (comentadas en el script)

### Opcion 1: Preferencia estandar (por defecto)
```groovy
def mapWriter = new CsvMapWriter(writer, CsvPreference.STANDARD_PREFERENCE)
```
- Delimitador: coma (`,`)
- Cita: comillas dobles (`"`)
- Fin de linea: `\r\n`

### Opcion 2: Con AlwaysQuoteMode (todos los campos entre comillas)
```groovy
CsvPreference StandardAlwaysQuote = new CsvPreference.Builder(CsvPreference.STANDARD_PREFERENCE)
    .useQuoteMode(new AlwaysQuoteMode()).build()
def mapWriter = new CsvMapWriter(writer, StandardAlwaysQuote)
```

### Opcion 3: Delimitador personalizado (Pipe)
```groovy
char quoteChar = '"'
int delimiterChar = '|'
String endOfLine = "\r\n"
CsvPreference PipeDelimited = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
def mapWriter = new CsvMapWriter(writer, PipeDelimited)
```

## Opcion: CSV sin header

Si no se necesita la fila de encabezado, omitir la linea:
```groovy
// mapWriter.writeHeader(header)  // Comentar para omitir header
```

## Seleccion manual de campos (comentada)

Para seleccionar y renombrar campos especificos:
```groovy
InputPayload.row.each { this_row ->
    def v_row = [:]
    v_row.put("idoc_no", this_row["idoc_no"])
    v_row.put("order_no", this_row["order_no"])
    v_row.put("line_item", this_row["line_item"])
    v_row.put("material", this_row["material"])
    v_row.put("plan_qty", this_row["schedule_qty"])    // Renombrado
    v_row.put("plan_date", this_row["schedule_date"])  // Renombrado
    v_row_list.add(v_row)
}
```

## Ejemplo de entrada (JSON Flat)

```json
{
    "row": [
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00001",
            "material": "800111",
            "schedule_qty": "10.000",
            "schedule_date": "20211210"
        },
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00002",
            "material": "800222",
            "schedule_qty": "40.000",
            "schedule_date": "20211210"
        },
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00002",
            "material": "800222",
            "schedule_qty": "60.000",
            "schedule_date": "20211220"
        }
    ]
}
```

## Ejemplo de salida (CSV)

```csv
idoc_no,order_no,ship_to,sold_to,order_date,line_item,material,schedule_qty,schedule_date
888888,5000123456,BBBB-222,AAAA-111,20211201,00001,800111,10.000,20211210
888888,5000123456,BBBB-222,AAAA-111,20211201,00002,800222,40.000,20211210
888888,5000123456,BBBB-222,AAAA-111,20211201,00002,800222,60.000,20211220
```

## Relacion con otros templates

```
T05 (IDOC → JSON Flat)  ──>  T13 (JSON Flat → CSV)
T07 (JSON Tree → JSON Flat)  ──>  T13
```

## Estructura del script

```groovy
def Message processData(Message message)  // Entry point CPI
void TestRun()                            // Solo para debug local
def DoMapping(String body, Map headers, Map properties)  // Logica principal
```

> **Nota CPI:** Comentar `TestRun()` antes de subir a SAP CPI.
