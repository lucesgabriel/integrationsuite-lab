# JSON_FLAT_to_CSV.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T13 |
| **Archivo** | `JSON_FLAT_to_CSV.groovy` |
| **Conversion** | JSON Flat → CSV |
| **Formato entrada** | JSON plano (`{ "row": [...] }`) |
| **Formato salida** | CSV (con header) |
| **Libreria CSV** | SuperCSV (`org.supercsv`) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.xml.*
import org.supercsv.cellprocessor.ift.CellProcessor
import org.supercsv.io.CsvMapWriter
import org.supercsv.prefs.CsvPreference
import org.supercsv.quote.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\json_flat.txt")
    File outputFile = new File("$dataDir\\json_flat_to_csv_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {
    def InputPayload = new JsonSlurper().parseText(body)

    def v_row_list = []

    //Auto take all fields from input json row
    InputPayload.row.each { this_row ->
        v_row_list.add(this_row)
    }

    //Manual specify output csv fields
//    InputPayload.row.each { this_row ->
//        def v_row = [:]
//        v_row.put("idoc_no", this_row["idoc_no"])
//        v_row.put("order_no", this_row["order_no"])
//        v_row.put("line_item", this_row["line_item"])
//        v_row.put("material", this_row["material"])
//        v_row.put("plan_qty", this_row["schedule_qty"]) //change output csv field name
//        v_row.put("plan_date", this_row["schedule_date"]) //change output csv field name
//        v_row_list.add(v_row)
//    }

    //Auto get list of header field name from first row
    String fieldList = v_row_list[0].keySet().join(",")

    String[] header = fieldList.split(',')
    def columnsCount = header.length
    CellProcessor[] processors = new CellProcessor[columnsCount]

    def writer = new StringWriter()

    //Use default standard preference
    def mapWriter = new CsvMapWriter(writer, CsvPreference.STANDARD_PREFERENCE)

    /*Use default standard preference with QuoteMode*/
//    CsvPreference StandardAlwaysQuote = new CsvPreference.Builder(CsvPreference.STANDARD_PREFERENCE).useQuoteMode(new AlwaysQuoteMode()).build()
//    def mapWriter = new CsvMapWriter(writer, StandardAlwaysQuote)

    /*Use custom preference - Pipe delimited*/
//    char quoteChar = '"'
//    int delimiterChar = '|'
//    String endOfLine = "\r\n"
//    CsvPreference PipeDelimited = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
//    def mapWriter = new CsvMapWriter(writer, PipeDelimited)

    /*If header not required no need use writeHeader*/
    mapWriter.writeHeader(header)

    v_row_list.each{ this_row ->
        mapWriter.write(this_row, header, processors)

    }
    mapWriter.close()

    def output = writer.toString()

    return output
}
```

---

## Explicacion por secciones

### 1. Imports SuperCSV para escritura

```groovy
import org.supercsv.cellprocessor.ift.CellProcessor  // Solo la interface (sin procesadores)
import org.supercsv.io.CsvMapWriter                   // Escritor CSV (a diferencia de los otros que usan CsvMapReader)
import org.supercsv.prefs.CsvPreference               // Configuracion del formato
import org.supercsv.quote.*                           // AlwaysQuoteMode y otros modos
```

T13 es el **unico template que usa `CsvMapWriter`** (escritor). Los demas templates de CSV (T09-T12) usan `CsvMapReader` (lector).

### 2. Parseo del JSON de entrada

```groovy
def InputPayload = new JsonSlurper().parseText(body)
// InputPayload.row = array JSON de objetos/mapas
```

### 3. Modo AUTO: toma todos los campos del JSON

```groovy
// ACTIVO:
InputPayload.row.each { this_row ->
    v_row_list.add(this_row)   // Agrega cada fila JSON directamente
}
```

Cada elemento de `InputPayload.row` es un `Map` de Groovy con los campos del JSON.

### 4. Modo MANUAL: seleccion y renombrado de campos (comentado)

```groovy
// COMENTADO (para activar en produccion si se necesita):
InputPayload.row.each { this_row ->
    def v_row = [:]
    v_row.put("idoc_no",   this_row["idoc_no"])
    v_row.put("order_no",  this_row["order_no"])
    v_row.put("line_item", this_row["line_item"])
    v_row.put("material",  this_row["material"])
    v_row.put("plan_qty",  this_row["schedule_qty"])    // Renombrado: schedule_qty → plan_qty
    v_row.put("plan_date", this_row["schedule_date"])   // Renombrado: schedule_date → plan_date
    v_row_list.add(v_row)
}
```

El modo manual permite **renombrar columnas** en el CSV de salida.

### 5. Generacion automatica del header CSV

```groovy
String fieldList = v_row_list[0].keySet().join(",")
// Toma las claves del primer elemento (row[0])
// Ejemplo: "idoc_no,order_no,ship_to,sold_to,order_date,line_item,material,schedule_qty,schedule_date"

String[] header = fieldList.split(',')
```

El orden de las columnas en el CSV de salida sigue el orden de las claves en el primer JSON row.

### 6. Configuracion del escritor CSV

#### Opcion 1 (activa): Preferencia estandar

```groovy
def mapWriter = new CsvMapWriter(writer, CsvPreference.STANDARD_PREFERENCE)
// Delimitador: coma
// Cita: comillas dobles (solo cuando necesario)
// Fin de linea: \r\n
```

#### Opcion 2 (comentada): Always Quote

```groovy
// CsvPreference StandardAlwaysQuote = new CsvPreference.Builder(CsvPreference.STANDARD_PREFERENCE)
//     .useQuoteMode(new AlwaysQuoteMode()).build()
// def mapWriter = new CsvMapWriter(writer, StandardAlwaysQuote)
// Resultado: "888888","5000123456","BBBB-222",...
```

#### Opcion 3 (comentada): Pipe delimitado

```groovy
// char quoteChar = '"'
// int delimiterChar = '|'
// String endOfLine = "\r\n"
// CsvPreference PipeDelimited = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
// def mapWriter = new CsvMapWriter(writer, PipeDelimited)
// Resultado: 888888|5000123456|BBBB-222|...
```

### 7. Escritura del CSV

```groovy
// Fila de cabecera (opcional - comentar si no se necesita header)
mapWriter.writeHeader(header)

// Filas de datos
v_row_list.each { this_row ->
    mapWriter.write(this_row, header, processors)
    // processors = null[] → sin transformacion de celdas
}

// IMPORTANTE: cerrar el writer
mapWriter.close()

def output = writer.toString()
```

**⚠️ `mapWriter.close()` es obligatorio** para que el buffer se vacíe y el CSV quede completo.

---

## Flujo completo del script

```
JSON Flat Input
      │
  JsonSlurper
      │
  InputPayload.row.each { }
      │
  v_row_list (List<Map>)
      │
  v_row_list[0].keySet() → header[]
      │
  CsvMapWriter.writeHeader(header)
      │
  v_row_list.each { mapWriter.write(...) }
      │
  mapWriter.close()
      │
  writer.toString()
      │
  CSV Output
```

---

## Ejemplo de entrada (JSON Flat)

```json
{
    "row": [
        {
            "idoc_no": "888888", "order_no": "5000123456",
            "ship_to": "BBBB-222", "sold_to": "AAAA-111",
            "order_date": "20211201", "line_item": "00001",
            "material": "800111", "schedule_qty": "10.000",
            "schedule_date": "20211210"
        },
        ...
    ]
}
```

## Ejemplo de salida (CSV)

```csv
idoc_no,order_no,ship_to,sold_to,order_date,line_item,material,schedule_qty,schedule_date
888888,5000123456,BBBB-222,AAAA-111,20211201,00001,800111,10.000,20211210
888888,5000123456,BBBB-222,AAAA-111,20211201,00002,800222,40.000,20211210
888888,5000123456,BBBB-222,AAAA-111,20211201,00002,800222,60.000,20211220
```

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ `mapWriter.close()` es **obligatorio** para no perder datos
- ✅ El output es `writer.toString()` (sin prettyPrint, el CSV es plano)
- ✅ Para omitir el header CSV, comentar `mapWriter.writeHeader(header)`
- ✅ Compatible con el output de T05, T07 (JSON Flat con estructura `"row": [...]`)
