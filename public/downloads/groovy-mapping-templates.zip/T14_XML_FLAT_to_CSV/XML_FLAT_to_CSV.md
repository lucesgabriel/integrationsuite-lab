# XML_FLAT_to_CSV.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T14 |
| **Archivo** | `XML_FLAT_to_CSV.groovy` |
| **Conversion** | XML Flat → CSV |
| **Formato entrada** | XML plano (`<root><row>...</row></root>`) |
| **Formato salida** | CSV (con header) |
| **Libreria CSV** | SuperCSV (`org.supercsv`) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.xml.*
import org.supercsv.cellprocessor.ift.CellProcessor
import org.supercsv.io.CsvMapWriter
import org.supercsv.prefs.CsvPreference
import org.supercsv.quote.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\xml_flat.txt")
    File outputFile = new File("$dataDir\\xml_flat_to_csv_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {
    def InputPayload = new XmlSlurper().parseText(body)

    def v_row_list = []

    //Auto take all fields from input xml row
    InputPayload.row.each { this_row ->
        def v_row = [:]
        this_row.children().each{ this_field ->
            def v_fieldName = this_field.name()
            def v_fieldValue = this_field.text()
            v_row.put(v_fieldName, v_fieldValue)
        }
        v_row_list.add(v_row)
    }

    //Manual specify output csv fields
//    InputPayload.row.each { this_row ->
//        def v_row = [:]
//        v_row.put("idoc_no", this_row["idoc_no"])
//        v_row.put("order_no", this_row["order_no"])
//        v_row.put("line_item", this_row["line_item"])
//        v_row.put("material", this_row["material"])
//        v_row.put("plan_qty", this_row["schedule_qty"])  //change output csv field name
//        v_row.put("plan_date", this_row["schedule_date"])  //change output csv field name
//        v_row_list.add(v_row)
//    }

    //Auto get list of field from first row
    String fieldList = v_row_list[0].keySet().join(",")

    String[] header = fieldList.split(',')
    def columnsCount = header.length
    CellProcessor[] processors = new CellProcessor[columnsCount]

    def writer = new StringWriter()

    //Use default standard preference
    def mapWriter = new CsvMapWriter(writer, CsvPreference.STANDARD_PREFERENCE)

    /*Use default standard preference with QuoteMode*/
//    CsvPreference StandardAlwaysQuote = new CsvPreference.Builder(CsvPreference.STANDARD_PREFERENCE).useQuoteMode(new AlwaysQuoteMode()).build()
//    def mapWriter = new CsvMapWriter(writer, StandardAlwaysQuote)

    /*Use custom preference - Pipe delimited*/
//    char quoteChar = '"'
//    int delimiterChar = '|'
//    String endOfLine = "\r\n"
//    CsvPreference PipeDelimited = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
//    def mapWriter = new CsvMapWriter(writer, PipeDelimited)

    /*If header not required no need use writeHeader*/
    mapWriter.writeHeader(header)

    v_row_list.each{ this_row ->
        mapWriter.write(this_row, header, processors)
    }
    mapWriter.close()

    def output = writer.toString()

    return output
}
```

---

## Explicacion por secciones

### 1. Diferencia clave con T13 (JSON Flat → CSV)

La unica diferencia significativa esta en la **extraccion de datos** del input.

**T13 (JSON):** Extraccion directa desde objetos JSON
```groovy
InputPayload.row.each { this_row ->
    v_row_list.add(this_row)   // this_row ya es un Map de Groovy
}
```

**T14 (XML):** Extraccion navegando los nodos XML
```groovy
InputPayload.row.each { this_row ->
    def v_row = [:]
    this_row.children().each { this_field ->
        def v_fieldName  = this_field.name()   // Nombre del elemento XML
        def v_fieldValue = this_field.text()   // Contenido del elemento XML
        v_row.put(v_fieldName, v_fieldValue)
    }
    v_row_list.add(v_row)
}
```

Una vez que `v_row_list` esta construido, el codigo es **identico** en T13 y T14.

### 2. Navegacion de nodos XML con XmlSlurper

```groovy
InputPayload.row.each { this_row ->
    // this_row es un GPathResult representando <row>...</row>

    this_row.children().each { this_field ->
        // this_field es un GPathResult representando cada elemento hijo de <row>

        def v_fieldName  = this_field.name()   // "idoc_no", "order_no", etc.
        def v_fieldValue = this_field.text()   // "888888", "5000123456", etc.
    }
}
```

Para el XML:
```xml
<row>
  <idoc_no>888888</idoc_no>
  <order_no>5000123456</order_no>
</row>
```

- `this_field.name()` → `"idoc_no"`, `"order_no"` ...
- `this_field.text()` → `"888888"`, `"5000123456"` ...

### 3. Modo MANUAL (comentado)

```groovy
// Para seleccion manual de campos:
InputPayload.row.each { this_row ->
    def v_row = [:]
    v_row.put("idoc_no",   this_row["idoc_no"].text())    // Con .text() para XML
    v_row.put("order_no",  this_row["order_no"].text())
    v_row.put("line_item", this_row["line_item"].text())
    v_row.put("material",  this_row["material"].text())
    v_row.put("plan_qty",  this_row["schedule_qty"].text())    // Renombrado
    v_row.put("plan_date", this_row["schedule_date"].text())   // Renombrado
    v_row_list.add(v_row)
}
```

**Nota:** En el codigo comentado del script se usa `this_row["schedule_qty"]` sin `.text()`, pero en la practica se necesitaria `.text()` para obtener el String del nodo XML.

### 4. Resto del codigo (identico a T13)

```groovy
// Header auto desde primer row
String fieldList = v_row_list[0].keySet().join(",")
String[] header = fieldList.split(',')

// Escritura CSV
def mapWriter = new CsvMapWriter(writer, CsvPreference.STANDARD_PREFERENCE)
mapWriter.writeHeader(header)
v_row_list.each { this_row ->
    mapWriter.write(this_row, header, processors)
}
mapWriter.close()
```

---

## Comparacion T13 vs T14

| Aspecto | T13 (JSON → CSV) | T14 (XML → CSV) |
|---------|-----------------|-----------------|
| Parser | `JsonSlurper` | `XmlSlurper` |
| Iteracion | `InputPayload.row.each` | `InputPayload.row.each` |
| Tipo de `this_row` | `Map` Groovy directo | `GPathResult` XML |
| Extraccion de campos | `v_row_list.add(this_row)` | `this_row.children().each { .name() / .text() }` |
| Extraccion de nombre | `this_row.keySet()` (auto) | `this_field.name()` |
| Extraccion de valor | `this_row[key]` (directo) | `this_field.text()` |
| Header auto | `v_row_list[0].keySet()` | `v_row_list[0].keySet()` (igual, ya es Map) |
| Escritura CSV | Identico | Identico |

---

## Ejemplo de entrada (XML Flat)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <line_item>00001</line_item>
    <material>800111</material>
    <schedule_qty>10.000</schedule_qty>
    <schedule_date>20211210</schedule_date>
  </row>
</root>
```

## Ejemplo de salida (CSV)

```csv
idoc_no,order_no,ship_to,sold_to,line_item,material,schedule_qty,schedule_date
888888,5000123456,BBBB-222,AAAA-111,00001,800111,10.000,20211210
888888,5000123456,BBBB-222,AAAA-111,00002,800222,40.000,20211210
888888,5000123456,BBBB-222,AAAA-111,00002,800222,60.000,20211220
```

---

## Cadena de conversion tipica

```
IDoc XML → T06 (→ XML Flat) → T14 (→ CSV)
IDoc XML → T08 (JSON Tree → XML Flat) → T14 (→ CSV)
```

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ `mapWriter.close()` es **obligatorio**
- ✅ Compatible con output de T06 y T08 (XML Flat con estructura `<root><row>`)
- ✅ El orden de columnas CSV refleja el orden de elementos XML en el primer `<row>`
- ✅ `groovy.json.*` en imports aunque no se usa (consistencia con T13)
