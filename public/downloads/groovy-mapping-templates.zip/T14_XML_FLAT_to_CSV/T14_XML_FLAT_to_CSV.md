# T14 - XML Flat to CSV

## Descripcion

Convierte un XML plano (flat con elementos `<row>`) a formato CSV. Extrae automaticamente los nombres de campo de los elementos hijo de cada `<row>` XML y genera el CSV con header. Es el equivalente XML del template T13.

## Transformacion

```
INPUT:  XML Flat (<root><row>...</row></root>)
OUTPUT: CSV (con header y datos)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `XML_FLAT_to_CSV.groovy` | Script principal de mapeo |
| `Data/xml_flat.txt` | Datos de entrada de ejemplo (XML Flat) |
| `Data/xml_flat_to_csv_output.txt` | Salida esperada (CSV) |

## Librerias utilizadas

```groovy
import groovy.json.*
import groovy.xml.*
import org.supercsv.cellprocessor.ift.CellProcessor
import org.supercsv.io.CsvMapWriter
import org.supercsv.prefs.CsvPreference
import org.supercsv.quote.*
```

- `XmlSlurper` - para parsear el input XML
- `CsvMapWriter` - escritor CSV de SuperCSV

## Diferencia clave con T13 (JSON → CSV)

| Aspecto | T13 (JSON Flat → CSV) | T14 (XML Flat → CSV) |
|---------|------------------------|----------------------|
| Parser | `JsonSlurper` | `XmlSlurper` |
| Extraccion de campos | `this_row.keySet()` | `this_row.children().each { this_field.name() }` |
| Iteracion | `InputPayload.row.each` | `InputPayload.row.each` |
| Header auto | Desde `.keySet()` del mapa | Desde `.name()` de elementos hijo |

## Logica de extraccion de datos XML

La diferencia principal es como se convierte cada `<row>` XML a un mapa:

```groovy
InputPayload.row.each { this_row ->
    def v_row = [:]
    this_row.children().each { this_field ->
        def v_fieldName = this_field.name()   // nombre del elemento XML
        def v_fieldValue = this_field.text()  // valor del elemento XML
        v_row.put(v_fieldName, v_fieldValue)
    }
    v_row_list.add(v_row)
}
```

## Generacion automatica del header CSV

Igual que T13, el header se extrae del primer row:
```groovy
String fieldList = v_row_list[0].keySet().join(",")
String[] header = fieldList.split(',')
```

## Opciones de configuracion CSV (identicas a T13)

### Opcion 1: Preferencia estandar (por defecto)
```groovy
def mapWriter = new CsvMapWriter(writer, CsvPreference.STANDARD_PREFERENCE)
```

### Opcion 2: AlwaysQuoteMode
```groovy
CsvPreference StandardAlwaysQuote = new CsvPreference.Builder(CsvPreference.STANDARD_PREFERENCE)
    .useQuoteMode(new AlwaysQuoteMode()).build()
```

### Opcion 3: Delimitador Pipe
```groovy
char quoteChar = '"'
int delimiterChar = '|'
String endOfLine = "\r\n"
CsvPreference PipeDelimited = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
```

## Seleccion manual de campos (comentada)

```groovy
InputPayload.row.each { this_row ->
    def v_row = [:]
    v_row.put("idoc_no", this_row["idoc_no"])
    v_row.put("order_no", this_row["order_no"])
    v_row.put("line_item", this_row["line_item"])
    v_row.put("material", this_row["material"])
    v_row.put("plan_qty", this_row["schedule_qty"])    // Renombrado
    v_row.put("plan_date", this_row["schedule_date"])  // Renombrado
    v_row_list.add(v_row)
}
```

## Ejemplo de entrada (XML Flat)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <line_item>00001</line_item>
    <material>800111</material>
    <schedule_qty>10.000</schedule_qty>
    <schedule_date>20211210</schedule_date>
  </row>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <line_item>00002</line_item>
    <material>800222</material>
    <schedule_qty>40.000</schedule_qty>
    <schedule_date>20211210</schedule_date>
  </row>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <line_item>00002</line_item>
    <material>800222</material>
    <schedule_qty>60.000</schedule_qty>
    <schedule_date>20211220</schedule_date>
  </row>
</root>
```

## Ejemplo de salida (CSV)

```csv
idoc_no,order_no,ship_to,sold_to,line_item,material,schedule_qty,schedule_date
888888,5000123456,BBBB-222,AAAA-111,00001,800111,10.000,20211210
888888,5000123456,BBBB-222,AAAA-111,00002,800222,40.000,20211210
888888,5000123456,BBBB-222,AAAA-111,00002,800222,60.000,20211220
```

## Relacion con otros templates

```
T06 (IDOC → XML Flat)      ──>  T14 (XML Flat → CSV)
T08 (JSON Tree → XML Flat) ──>  T14
```

## Estructura del script

```groovy
def Message processData(Message message)  // Entry point CPI
void TestRun()                            // Solo para debug local
def DoMapping(String body, Map headers, Map properties)  // Logica principal
```

> **Nota CPI:** Comentar `TestRun()` antes de subir a SAP CPI.
