# T01 - IDOC to Tree JSON

## Descripcion

Convierte un mensaje IDoc SAP (formato XML) a una estructura JSON jerarquica (arbol) con ordenes, cabeceras, items y schedules anidados.

## Transformacion

```
INPUT:  IDOC XML (ORDERS05)
OUTPUT: JSON Tree (orders > header + items > schedule)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `IDOC_Orders_to_Tree_JSON.groovy` | Script principal de mapeo |
| `Data/idoc_orders.txt` | Datos de entrada de ejemplo (IDOC XML) |
| `Data/idoc_orders_to_tree_json_output.txt` | Salida esperada (JSON Tree) |

## Librerias utilizadas

```groovy
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
```

- `XmlSlurper` - para parsear el input IDoc XML
- `StreamingJsonBuilder` - para construir el output JSON
- `JsonOutput.prettyPrint` - para formatear el JSON resultante

## Logica de mapeo

### Segmentos IDoc leidos

| Segmento IDoc | Campo | Campo JSON de salida |
|---------------|-------|----------------------|
| `EDI_DC40` | `DOCNUM` | `header.idoc_no` (sin ceros a la izquierda) |
| `E1EDK01` | `BELNR` | `header.order_no` |
| `E1EDKA1` (PARVW=AG) | `PARTN` | `header.sold_to` |
| `E1EDKA1` (PARVW=WE) | `PARTN` | `header.ship_to` |
| `E1EDK03` (IDDAT=012) | `DATUM` | `header.order_date` |
| `E1EDP01` | `POSEX` | `item.line_item` |
| `E1EDP19` (QUALF=001) | `IDTNR` | `item.material` (sin ceros) |
| `E1EDP01` | `MENGE` | `item.quantity` |
| `E1EDP01` | `MENEE` | `item.quantity_uom` (lowercase) |
| `E1EDP01` | `NTGEW` | `item.weight` |
| `E1EDP01` | `GEWEI` | `item.weight_uom` (lowercase) |
| `E1EDP20` | `WMENG` | `item.schedule.schedule_qty` |
| `E1EDP20` | `EDATU` | `item.schedule.schedule_date` |

### Transformaciones especiales

- `DOCNUM`: se elimina ceros a la izquierda con `.replaceFirst("^0*", "")`
- `IDTNR`: se elimina ceros a la izquierda con `.replaceFirst("^0*", "")`
- `MENEE` / `GEWEI`: se convierten a minusculas con `.toLowerCase()`
- Filtra `E1EDKA1` por `PARVW` para separar sold_to (AG) y ship_to (WE)
- Filtra `E1EDK03` por `IDDAT=012` para la fecha de orden

## Estructura del script

```groovy
def Message processData(Message message)  // Entry point CPI
void TestRun()                            // Solo para debug local
def DoMapping(String body, Map headers, Map properties)  // Logica principal
```

> **Nota CPI:** Comentar `TestRun()` antes de subir a SAP CPI.

## Ejemplo de entrada (IDoc XML)

```xml
<ORDERS05>
  <IDOC BEGIN="1">
    <EDI_DC40 SEGMENT="1">
      <DOCNUM>0000000000888888</DOCNUM>
      <IDOCTYP>ORDERS05</IDOCTYP>
      <MESTYP>ORDERS</MESTYP>
    </EDI_DC40>
    <E1EDK01 SEGMENT="1">
      <BELNR>5000123456</BELNR>
    </E1EDK01>
    <E1EDK03 SEGMENT="1">
      <IDDAT>012</IDDAT>
      <DATUM>20211201</DATUM>
    </E1EDK03>
    <E1EDKA1 SEGMENT="1">
      <PARVW>AG</PARVW>
      <PARTN>AAAA-111</PARTN>
    </E1EDKA1>
    <E1EDKA1 SEGMENT="1">
      <PARVW>WE</PARVW>
      <PARTN>BBBB-222</PARTN>
    </E1EDKA1>
    <E1EDP01 SEGMENT="1">
      <POSEX>00001</POSEX>
      <MENGE>10.000</MENGE>
      <MENEE>PCE</MENEE>
      <NTGEW>20</NTGEW>
      <GEWEI>KGM</GEWEI>
      <E1EDP20 SEGMENT="1">
        <WMENG>10.000</WMENG>
        <EDATU>20211210</EDATU>
      </E1EDP20>
      <E1EDP19 SEGMENT="1">
        <QUALF>001</QUALF>
        <IDTNR>000000000000800111</IDTNR>
      </E1EDP19>
    </E1EDP01>
  </IDOC>
</ORDERS05>
```

## Ejemplo de salida (JSON Tree)

```json
{
    "orders": [
        {
            "header": {
                "idoc_no": "888888",
                "order_no": "5000123456",
                "sold_to": "AAAA-111",
                "ship_to": "BBBB-222",
                "order_date": "20211201"
            },
            "item": [
                {
                    "line_item": "00001",
                    "material": "800111",
                    "quantity": "10.000",
                    "quantity_uom": "pce",
                    "weight": "20",
                    "weight_uom": "kgm",
                    "schedule": [
                        {
                            "schedule_qty": "10.000",
                            "schedule_date": "20211210"
                        }
                    ]
                },
                {
                    "line_item": "00002",
                    "material": "800222",
                    "quantity": "100.000",
                    "quantity_uom": "pce",
                    "weight": "200",
                    "weight_uom": "kgm",
                    "schedule": [
                        {
                            "schedule_qty": "40.000",
                            "schedule_date": "20211210"
                        },
                        {
                            "schedule_qty": "60.000",
                            "schedule_date": "20211220"
                        }
                    ]
                }
            ]
        }
    ]
}
```

## Diagrama de flujo

```
IDOC XML (ORDERS05)
        |
   XmlSlurper
        |
   +-----------+
   | Iteracion |  InputPayload.IDOC.each
   | por IDOC  |
   +-----------+
        |
   +----------+     +----------+
   | Header   |     | Items    |
   | idoc_no  |     | E1EDP01  |
   | order_no |     | each{}   |
   | sold_to  |     +----+-----+
   | ship_to  |          |
   | order_   |     +----------+
   | date     |     | Schedule |
   +----------+     | E1EDP20  |
                    | each{}   |
                    +----------+
        |
  StreamingJsonBuilder
        |
  JsonOutput.prettyPrint
        |
    JSON Tree Output
```
