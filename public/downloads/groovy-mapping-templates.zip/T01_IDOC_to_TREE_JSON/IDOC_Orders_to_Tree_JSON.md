# IDOC_Orders_to_Tree_JSON.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T01 |
| **Archivo** | `IDOC_Orders_to_Tree_JSON.groovy` |
| **Conversion** | IDoc XML (ORDERS05) → JSON Tree jerarquico |
| **Formato entrada** | XML |
| **Formato salida** | JSON |
| **Estructura salida** | Jerarquica (Tree) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\idoc_orders.txt")
    File outputFile = new File("$dataDir\\idoc_orders_to_tree_json_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {
    def InputPayload = new XmlSlurper().parseText(body)

    def writer = new StringWriter()
    def builder = new StreamingJsonBuilder(writer)

    // MAPPING
    builder {
        orders(InputPayload.IDOC) { this_IDOC ->
            header {
                idoc_no(this_IDOC.EDI_DC40.DOCNUM.toString().replaceFirst("^0*", ""))
                order_no(this_IDOC.E1EDK01.BELNR.toString())

                this_IDOC.E1EDKA1.each { this_E1EDKA1 ->
                    if (this_E1EDKA1.PARVW.toString() == "WE") {
                        ship_to(this_E1EDKA1.PARTN.toString())
                    }
                    if (this_E1EDKA1.PARVW.toString() == "AG") {
                        sold_to(this_E1EDKA1.PARTN.toString())
                    }
                }

                this_IDOC.E1EDK03.each { this_E1EDK03 ->
                    if (this_E1EDK03.IDDAT.toString() == "012") {
                        order_date(this_E1EDK03.DATUM.toString())
                    }
                }
            }

            item(this_IDOC.E1EDP01) { this_E1EDP01 ->
                line_item(this_E1EDP01.POSEX.toString())

                this_E1EDP01.E1EDP19.each { this_E1EDP19 ->
                    if (this_E1EDP19.QUALF.toString() == "001") {
                        material(this_E1EDP19.IDTNR.toString().replaceFirst("^0*", ""))
                    }
                }

                quantity(this_E1EDP01.MENGE.toString())
                quantity_uom(this_E1EDP01.MENEE.toString().toLowerCase())
                weight(this_E1EDP01.NTGEW.toString())
                weight_uom(this_E1EDP01.GEWEI.toString().toLowerCase())

                schedule(this_E1EDP01.E1EDP20) { this_E1EDP20 ->
                    schedule_qty(this_E1EDP20.WMENG.toString())
                    schedule_date(this_E1EDP20.EDATU.toString())
                }
            }
        }
    }

    // WRITING
    //def output = writer.toString()
    def output = JsonOutput.prettyPrint(writer.toString())

    return output
}
```

---

## Explicacion por secciones

### 1. Imports

```groovy
import com.sap.gateway.ip.core.customdev.util.Message  // Clase Message de SAP CPI
import groovy.json.*  // JsonSlurper, StreamingJsonBuilder, JsonOutput
```

### 2. Metodo `processData` (Entry Point SAP CPI)

```groovy
def Message processData(Message message) {
    def body       = message.getBody(String)      // Lee el cuerpo como String
    def headers    = message.getHeaders()         // Mapa de headers del mensaje
    def properties = message.getProperties()      // Mapa de propiedades Exchange

    message.setBody(DoMapping(body, headers, properties))  // Establece el nuevo cuerpo

    return message
}
```

> Este metodo es el **punto de entrada** invocado por SAP CPI. Su firma no debe modificarse.

### 3. Metodo `TestRun` (Solo debug local)

```groovy
void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"
    // ...
}
```

- Obtiene el directorio del script dinamicamente
- Lee el archivo de input desde la carpeta `Data\`
- Escribe el resultado en el archivo de output
- **⚠️ DEBE COMENTARSE antes de subir a SAP CPI**

### 4. Metodo `DoMapping` - Parseo de entrada

```groovy
def InputPayload = new XmlSlurper().parseText(body)
```

`XmlSlurper` convierte el XML de entrada en un objeto Groovy navegable por rutas de puntos.

### 5. Metodo `DoMapping` - Construccion del JSON

```groovy
def writer = new StringWriter()
def builder = new StreamingJsonBuilder(writer)
```

`StreamingJsonBuilder` escribe JSON directamente al `StringWriter` de forma eficiente (streaming).

### 6. Bloque de mapeo: Cabecera (Header)

```groovy
builder {
    orders(InputPayload.IDOC) { this_IDOC ->
        header {
            idoc_no(this_IDOC.EDI_DC40.DOCNUM.toString().replaceFirst("^0*", ""))
            order_no(this_IDOC.E1EDK01.BELNR.toString())
            ...
        }
    }
}
```

| Expresion | Descripcion |
|-----------|-------------|
| `orders(InputPayload.IDOC)` | Itera cada `<IDOC>` del XML y genera el array `"orders"` |
| `{ this_IDOC -> ... }` | Closure que recibe cada instancia de IDOC |
| `.replaceFirst("^0*", "")` | Elimina ceros a la izquierda (regex) |
| `.toString()` | Convierte el nodo GPath a String |

### 7. Filtrado de segmentos repetidos (E1EDKA1 y E1EDK03)

```groovy
this_IDOC.E1EDKA1.each { this_E1EDKA1 ->
    if (this_E1EDKA1.PARVW.toString() == "WE") {
        ship_to(this_E1EDKA1.PARTN.toString())
    }
    if (this_E1EDKA1.PARVW.toString() == "AG") {
        sold_to(this_E1EDKA1.PARTN.toString())
    }
}
```

- `E1EDKA1` es un segmento repetible → se itera con `.each`
- Se filtra por `PARVW` para distinguir **ship_to** (WE = Goods Recipient) y **sold_to** (AG = Sold-to Party)

```groovy
this_IDOC.E1EDK03.each { this_E1EDK03 ->
    if (this_E1EDK03.IDDAT.toString() == "012") {
        order_date(this_E1EDK03.DATUM.toString())
    }
}
```

- `E1EDK03` es repetible (multiples fechas)
- Se filtra `IDDAT == "012"` → fecha de la orden de compra

### 8. Bloque de mapeo: Items

```groovy
item(this_IDOC.E1EDP01) { this_E1EDP01 ->
    line_item(this_E1EDP01.POSEX.toString())
    ...
    quantity_uom(this_E1EDP01.MENEE.toString().toLowerCase())
    weight_uom(this_E1EDP01.GEWEI.toString().toLowerCase())
    ...
}
```

- `item(this_IDOC.E1EDP01)` → genera el array `"item"` iterando todos los `<E1EDP01>`
- `.toLowerCase()` convierte `"PCE"` → `"pce"` y `"KGM"` → `"kgm"`

### 9. Bloque de mapeo: Material (E1EDP19 con filtro)

```groovy
this_E1EDP01.E1EDP19.each { this_E1EDP19 ->
    if (this_E1EDP19.QUALF.toString() == "001") {
        material(this_E1EDP19.IDTNR.toString().replaceFirst("^0*", ""))
    }
}
```

- `QUALF == "001"` → calificador de material (numero de parte del comprador)
- `IDTNR` puede venir con ceros a la izquierda: `"000000000000800111"` → `"800111"`

### 10. Bloque de mapeo: Schedules

```groovy
schedule(this_E1EDP01.E1EDP20) { this_E1EDP20 ->
    schedule_qty(this_E1EDP20.WMENG.toString())
    schedule_date(this_E1EDP20.EDATU.toString())
}
```

- `schedule(this_E1EDP01.E1EDP20)` → genera el array `"schedule"` con todas las schedule lines del item

### 11. Escritura del output

```groovy
// Opcion 1: JSON compacto (comentado)
// def output = writer.toString()

// Opcion 2: JSON formateado con indentacion (activo)
def output = JsonOutput.prettyPrint(writer.toString())
```

---

## Mapeo de campos

| Campo JSON salida | Segmento IDoc | Campo IDoc | Transformacion |
|-------------------|---------------|------------|----------------|
| `orders[].header.idoc_no` | `EDI_DC40` | `DOCNUM` | `.replaceFirst("^0*", "")` |
| `orders[].header.order_no` | `E1EDK01` | `BELNR` | `.toString()` |
| `orders[].header.sold_to` | `E1EDKA1[PARVW=AG]` | `PARTN` | `.toString()` |
| `orders[].header.ship_to` | `E1EDKA1[PARVW=WE]` | `PARTN` | `.toString()` |
| `orders[].header.order_date` | `E1EDK03[IDDAT=012]` | `DATUM` | `.toString()` |
| `orders[].item[].line_item` | `E1EDP01` | `POSEX` | `.toString()` |
| `orders[].item[].material` | `E1EDP19[QUALF=001]` | `IDTNR` | `.replaceFirst("^0*", "")` |
| `orders[].item[].quantity` | `E1EDP01` | `MENGE` | `.toString()` |
| `orders[].item[].quantity_uom` | `E1EDP01` | `MENEE` | `.toLowerCase()` |
| `orders[].item[].weight` | `E1EDP01` | `NTGEW` | `.toString()` |
| `orders[].item[].weight_uom` | `E1EDP01` | `GEWEI` | `.toLowerCase()` |
| `orders[].item[].schedule[].schedule_qty` | `E1EDP20` | `WMENG` | `.toString()` |
| `orders[].item[].schedule[].schedule_date` | `E1EDP20` | `EDATU` | `.toString()` |

---

## Notas importantes para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar en CPI
- ✅ La ruta `Data\` y los archivos `.txt` son solo para pruebas locales
- ✅ No se requieren propiedades del mensaje (a diferencia de T03/T04)
- ✅ El output es JSON formateado con `prettyPrint` (puede cambiarse a compacto comentando/descomentando)
