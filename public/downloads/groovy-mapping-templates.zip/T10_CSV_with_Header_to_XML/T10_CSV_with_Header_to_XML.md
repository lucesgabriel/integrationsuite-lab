# T10 - CSV with Header to XML

## Descripcion

Convierte un archivo CSV con fila de cabecera (header row) a formato XML. Incluye dos variantes: **Auto** (todos los campos del CSV con nombres sanitizados) y **Manual** (seleccion de campos especificos con renombrado). Es el equivalente XML del template T09.

## Transformacion

```
INPUT:  CSV con header row (primera linea = nombres de columnas)
OUTPUT: XML Flat (<root><row>...</row></root>)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `CSV_with_Header_to_XML_Auto.groovy` | Mapeo automatico (todos los campos) |
| `CSV_with_Header_to_XML_Manual.groovy` | Mapeo manual (campos seleccionados) |
| `Data/csv_data_with_header.txt` | CSV simple con header |
| `Data/csv_complex_with_header.txt` | CSV complejo (muchas columnas) |
| `Data/csv_data_with_header_to_xml_auto_output.txt` | Salida Auto con csv simple |
| `Data/csv_data_with_header_to_xml_manual_output.txt` | Salida Manual con csv simple |
| `Data/csv_complex_with_header_to_xml_auto_output.txt` | Salida Auto con csv complejo |
| `Data/csv_complex_with_header_to_xml_manual_output.txt` | Salida Manual con csv complejo |

## Librerias utilizadas

```groovy
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.*
import groovy.xml.*
import org.supercsv.cellprocessor.*
import org.supercsv.cellprocessor.constraint.*
import org.supercsv.cellprocessor.ift.*
import org.supercsv.io.*
import org.supercsv.prefs.*
import org.supercsv.quote.*
```

- **SuperCSV** - para lectura del CSV
- `StreamingMarkupBuilder` + `XmlUtil.serialize` - para generar el XML

## Comparacion T09 vs T10

| Aspecto | T09 (CSV → JSON) | T10 (CSV → XML) |
|---------|------------------|------------------|
| Builder | `StreamingJsonBuilder` | `StreamingMarkupBuilder` |
| Formato final | `JsonOutput.prettyPrint` | `XmlUtil.serialize` |
| Estructura raiz | `{ "row": [...] }` | `<root><row>...</row></root>` |
| Declaracion XML | No aplica | `mkp.xmlDeclaration()` implícita |

## Variante AUTO

Genera XML con **todos los campos** del CSV, sanitizando los nombres de columna para que sean elementos XML validos.

### Funcion de formateo
```groovy
def formatFieldName(String fieldName) {
    fieldName = fieldName.replaceAll("[^a-zA-Z0-9_]", "")
    return fieldName
}
```

### Flujo Auto (dentro del `builder.bind`)
```groovy
def writer = builder.bind {
    root {
        while ((rowMap = mapReader.read(header, processor)) != null) {
            row {
                header.each { this_field ->
                    if (this_field != null) {
                        def fieldName = formatFieldName(this_field)
                        def fieldValue = rowMap[this_field]
                        "$fieldName"(fieldValue)
                    }
                }
            }
        }
    }
}
```

**Nota:** La lectura del CSV ocurre directamente dentro del `builder.bind` (diferente a T09 donde se acumula primero en lista).

## Variante MANUAL

Selecciona campos especificos con nombres de destino definidos:

```groovy
def writer = builder.bind {
    root {
        while ((rowMap = mapReader.read(header, processor)) != null) {
            row {
                "idoc_no"(rowMap["idoc no"])
                "order_no"(rowMap["order no"])
                "line_item"(rowMap["line-item#"])
                "material"(rowMap["material"])
                "quantity"(rowMap["quantity"])
                "quantity_uom"(rowMap["quantity(uom)"])
            }
        }
    }
}
```

## Ejemplo de entrada (CSV con header)

```csv
idoc no,order no,ship to,sold to,order date,line-item#,material,quantity,quantity(uom),weight,weight(uom)
888888,5000123456,BBBB-222,AAAA-111,20211201,00001,800111,10.000,pce,20,kgm
888888,5000123456,BBBB-222,AAAA-111,20211201,00002,800222,100.000,pce,200,kgm
```

## Ejemplo de salida Auto (XML)

Todos los campos del CSV con nombres sanitizados:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
  <row>
    <idocno>888888</idocno>
    <orderno>5000123456</orderno>
    <shipto>BBBB-222</shipto>
    <soldto>AAAA-111</soldto>
    <orderdate>20211201</orderdate>
    <lineitem>00001</lineitem>
    <material>800111</material>
    <quantity>10.000</quantity>
    <quantityuom>pce</quantityuom>
    <weight>20</weight>
    <weightuom>kgm</weightuom>
  </row>
</root>
```

## Ejemplo de salida Manual (XML)

Solo campos seleccionados con nombres limpios:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <line_item>00001</line_item>
    <material>800111</material>
    <quantity>10.000</quantity>
    <quantity_uom>pce</quantity_uom>
  </row>
</root>
```

## Diferencias tecnicas Auto vs Manual

| Aspecto | Auto | Manual |
|---------|------|--------|
| Iteration pattern | `header.each { this_field -> }` dentro del `row{}` | Campos hardcodeados dentro del `row{}` |
| Null check | `if (this_field != null)` | No necesario (campos fijos) |
| Sanitizacion | `formatFieldName()` | Nombre destino definido directamente |
| CSV columns | Todas | Solo las especificadas |
