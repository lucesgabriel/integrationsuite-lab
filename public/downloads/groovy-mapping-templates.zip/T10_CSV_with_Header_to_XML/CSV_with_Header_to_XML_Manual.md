# CSV_with_Header_to_XML_Manual.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T10 - Variante Manual |
| **Archivo** | `CSV_with_Header_to_XML_Manual.groovy` |
| **Conversion** | CSV con header → XML (campos seleccionados manualmente) |
| **Formato entrada** | CSV con primera fila de cabecera |
| **Formato salida** | XML plano (`<root><row>`) |
| **Libreria CSV** | SuperCSV (`org.supercsv`) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.*
import groovy.xml.*
import org.supercsv.cellprocessor.*
import org.supercsv.cellprocessor.constraint.*
import org.supercsv.cellprocessor.ift.*
import org.supercsv.io.*
import org.supercsv.prefs.*
import org.supercsv.quote.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\csv_data_with_header.txt")
    File outputFile = new File("$dataDir\\csv_data_with_header_to_xml_manual_output.txt")
    //File inputFile = new File("$dataDir\\csv_complex_with_header.txt")
    //File outputFile = new File("$dataDir\\csv_complex_with_header_to_xml_manual_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {
    //Standard CSV
    ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), CsvPreference.STANDARD_PREFERENCE)

    //Custom CsvPreference parameters
//    char quoteChar = '"'
//    int delimiterChar = ','
//    String endOfLine = "\r\n"
//    CsvPreference customCsvPreference = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
//    ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), customCsvPreference)


    String[] header = mapReader.getHeader(true)
    int columnsCount = header.length
    CellProcessor[] processor = new CellProcessor[columnsCount]

    def builder = new StreamingMarkupBuilder()

    def writer = builder.bind {
        root {
            while ((rowMap = mapReader.read(header, processor)) != null) {
                row {
                    //Selected fields from csv_data_with_header.txt
                    "idoc_no"(rowMap["idoc no"])
                    "order_no"(rowMap["order no"])
                    "line_item"(rowMap["line-item#"])
                    "material"(rowMap["material"])
                    "quantity"(rowMap["quantity"])
                    "quantity_uom"(rowMap["quantity(uom)"])

                    //Selected fields from csv_complex_with_header.txt
//                    "ContactID"(rowMap["Contact ID"])
//                    "FirstName"(rowMap["First Name"])
//                    "LastName"(rowMap["Last Name"])
//                    "PreferredComm"(rowMap["Preferred Communication Method"])
//                    "Email"(rowMap["Email"])
//                    "Phone"(rowMap["Phone"])
                }
            }
        }
    }

    def output = XmlUtil.serialize(writer.toString())

    return output
}
```

---

## Explicacion por secciones

### 1. Diferencia clave con T10 Auto

El mapeo de campos es **explicito y estatico** dentro del closure `row { }`:

```groovy
row {
    // Nombre XML = nombre destino
    // rowMap["nombre CSV"] = columna del CSV con su nombre original
    "idoc_no"(rowMap["idoc no"])
    "order_no"(rowMap["order no"])
    "line_item"(rowMap["line-item#"])
    "material"(rowMap["material"])
    "quantity"(rowMap["quantity"])
    "quantity_uom"(rowMap["quantity(uom)"])
}
```

### 2. Patron de nombre XML vs nombre CSV

```groovy
"idoc_no"(rowMap["idoc no"])
//  ↑ Elemento XML    ↑ Columna CSV (exactamente como aparece en el header)
```

| Elemento XML salida | Columna CSV entrada |
|---------------------|---------------------|
| `<idoc_no>` | `"idoc no"` (con espacio) |
| `<order_no>` | `"order no"` (con espacio) |
| `<line_item>` | `"line-item#"` (guion y hash) |
| `<material>` | `"material"` (igual) |
| `<quantity>` | `"quantity"` (igual) |
| `<quantity_uom>` | `"quantity(uom)"` (con parentesis) |

### 3. Sin funcion formatFieldName

A diferencia de T10 Auto, la variante Manual **no necesita** `formatFieldName()` porque el nombre del elemento XML se define directamente en el codigo como literal string.

### 4. Streaming directo (igual que T10 Auto)

Ambas variantes (Auto y Manual) de T10 usan el mismo patron de streaming directo:

```groovy
def writer = builder.bind {
    root {
        while ((rowMap = mapReader.read(header, processor)) != null) {
            // Lee y escribe en la misma pasada
            row { ... }
        }
    }
}
```

### 5. Campos para CSV complejo (comentados)

```groovy
// Para usar con csv_complex_with_header.txt:
// "ContactID"(rowMap["Contact ID"])
// "FirstName"(rowMap["First Name"])
// "LastName"(rowMap["Last Name"])
// "PreferredComm"(rowMap["Preferred Communication Method"])
// "Email"(rowMap["Email"])
// "Phone"(rowMap["Phone"])
```

---

## Comparacion T10 Auto vs T10 Manual

| Aspecto | T10 Auto | T10 Manual |
|---------|----------|------------|
| Campos de salida | Todos | Solo seleccionados |
| Nombres de elemento XML | Sanitizados automaticamente | Definidos explicitamente |
| `formatFieldName()` | Si (requerida) | No (no necesaria) |
| Null check `this_field != null` | Si (necesario) | No (campos hardcodeados) |
| Iteracion en `row {}` | `header.each {}` dinamico | Campos estaticos directos |
| Adaptabilidad | Alto (cualquier CSV) | Bajo (especifico al CSV) |

---

## Ejemplo de salida (XML Manual)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <line_item>00001</line_item>
    <material>800111</material>
    <quantity>10.000</quantity>
    <quantity_uom>pce</quantity_uom>
  </row>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <line_item>00002</line_item>
    <material>800222</material>
    <quantity>100.000</quantity>
    <quantity_uom>pce</quantity_uom>
  </row>
</root>
```

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ Los nombres en `rowMap["..."]` deben coincidir exactamente con el header del CSV
- ✅ Los nombres de elementos XML deben ser identificadores XML validos (sin espacios ni caracteres especiales)
