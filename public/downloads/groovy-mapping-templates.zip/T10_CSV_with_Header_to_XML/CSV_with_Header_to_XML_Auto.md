# CSV_with_Header_to_XML_Auto.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T10 - Variante Auto |
| **Archivo** | `CSV_with_Header_to_XML_Auto.groovy` |
| **Conversion** | CSV con header → XML (todos los campos automaticamente) |
| **Formato entrada** | CSV con primera fila de cabecera |
| **Formato salida** | XML plano (`<root><row>`) |
| **Libreria CSV** | SuperCSV (`org.supercsv`) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.*
import groovy.xml.*
import org.supercsv.cellprocessor.*
import org.supercsv.cellprocessor.constraint.*
import org.supercsv.cellprocessor.ift.*
import org.supercsv.io.*
import org.supercsv.prefs.*
import org.supercsv.quote.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\csv_data_with_header.txt")
    File outputFile = new File("$dataDir\\csv_data_with_header_to_xml_auto_output.txt")
    //File inputFile = new File("$dataDir\\csv_complex_with_header.txt")
    //File outputFile = new File("$dataDir\\csv_complex_with_header_to_xml_auto_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {

    //Standard CSV
    ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), CsvPreference.STANDARD_PREFERENCE)

    //Custom CsvPreference parameters
//    char quoteChar = '"'
//    int delimiterChar = ','
//    String endOfLine = "\r\n"
//    CsvPreference customCsvPreference = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
//    ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), customCsvPreference)

    String[] header = mapReader.getHeader(true)
    int columnsCount = header.length
    CellProcessor[] processor = new CellProcessor[columnsCount]

    def builder = new StreamingMarkupBuilder()

    def writer = builder.bind {
        root {
            while ((rowMap = mapReader.read(header, processor)) != null) {
                row {
                    header.each{ this_field ->
                        if(this_field != null){
                            def fieldName = formatFieldName(this_field)
                            def fieldValue = rowMap[this_field]
                            "$fieldName"(fieldValue)
                        }
                    }
                }
            }
        }
    }

    def output = XmlUtil.serialize(writer.toString())

    return output
}

def formatFieldName(String fieldName) {
    fieldName = fieldName.replaceAll("[^a-zA-Z0-9_]", "")
    //fieldName = fieldName.toLowerCase()
    return fieldName
}
```

---

## Explicacion por secciones

### 1. Diferencia de imports con T09 Auto

```groovy
// T09 Auto (JSON output):
import groovy.json.JsonOutput
import groovy.json.StreamingJsonBuilder

// T10 Auto (XML output):
import groovy.util.*   // Utilidades Groovy
import groovy.xml.*    // StreamingMarkupBuilder, XmlUtil
// NO necesita groovy.json.*
```

### 2. Patron de escritura: Streaming directo (sin lista intermedia)

A diferencia de T09 Auto que acumula primero en `v_row_list`, T10 Auto lee y escribe **en una sola pasada** dentro del `builder.bind`:

```groovy
def writer = builder.bind {
    root {
        while ((rowMap = mapReader.read(header, processor)) != null) {
            // Lee del CSV y escribe al XML directamente
            row {
                header.each { this_field ->
                    if (this_field != null) {
                        def fieldName  = formatFieldName(this_field)
                        def fieldValue = rowMap[this_field]
                        "$fieldName"(fieldValue)
                    }
                }
            }
        }
    }
}
```

**Ventaja:** Menor uso de memoria (no acumula toda la lista en RAM).
**Desventaja:** La logica de lectura y escritura esta mezclada en el closure.

### 3. Null check del campo

```groovy
header.each { this_field ->
    if (this_field != null) {    // Proteccion: headers puede tener nulos en CSV con comas finales
        def fieldName = formatFieldName(this_field)
        // ...
    }
}
```

Esta comprobacion es necesaria porque algunos CSV con comas al final de la linea del header generan un elemento `null` en el array `header`.

### 4. Construccion dinamica de elementos XML

```groovy
"$fieldName"(fieldValue)
// Equivalente a: <fieldName>fieldValue</fieldName>
// Con nombre dinamico via interpolacion de String de Groovy
```

**Ejemplo:**
- `"idocno"("888888")` → `<idocno>888888</idocno>`
- `"quantityuom"("pce")` → `<quantityuom>pce</quantityuom>`

### 5. Funcion formatFieldName (identica a T09 Auto)

```groovy
def formatFieldName(String fieldName) {
    fieldName = fieldName.replaceAll("[^a-zA-Z0-9_]", "")
    return fieldName
}
```

Los nombres de columna CSV se sanitizan para ser nombres de elemento XML validos.

| Nombre CSV | Nombre XML |
|------------|------------|
| `"idoc no"` | `idocno` |
| `"line-item#"` | `lineitem` |
| `"quantity(uom)"` | `quantityuom` |

---

## Comparacion T09 Auto vs T10 Auto

| Aspecto | T09 Auto (→ JSON) | T10 Auto (→ XML) |
|---------|------------------|-----------------|
| Builder | `StreamingJsonBuilder` | `StreamingMarkupBuilder` |
| Patron | Acumula lista → construye JSON | Streaming directo (lee y escribe) |
| `v_row_list` | Si (lista intermedia) | No (sin lista intermedia) |
| Raiz output | `"row": [...]` | `<root><row>...</row></root>` |
| Declaracion | No | `mkp.xmlDeclaration()` (implicita en bind) |
| Serializacion | `JsonOutput.prettyPrint()` | `XmlUtil.serialize()` |

---

## Ejemplo de salida (XML Auto)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
  <row>
    <idocno>888888</idocno>
    <orderno>5000123456</orderno>
    <shipto>BBBB-222</shipto>
    <soldto>AAAA-111</soldto>
    <orderdate>20211201</orderdate>
    <lineitem>00001</lineitem>
    <material>800111</material>
    <quantity>10.000</quantity>
    <quantityuom>pce</quantityuom>
    <weight>20</weight>
    <weightuom>kgm</weightuom>
  </row>
</root>
```

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ El null check `if (this_field != null)` protege contra CSV con comas finales
- ✅ Compatible con CSV complejos de muchas columnas
