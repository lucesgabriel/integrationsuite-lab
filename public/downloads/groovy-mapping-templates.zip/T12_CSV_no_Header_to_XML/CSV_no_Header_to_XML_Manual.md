# CSV_no_Header_to_XML_Manual.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T12 - Variante Manual |
| **Archivo** | `CSV_no_Header_to_XML_Manual.groovy` |
| **Conversion** | CSV sin header → XML (campos seleccionados manualmente) |
| **Formato entrada** | CSV sin primera fila de cabecera |
| **Formato salida** | XML plano (`<root><row>`) |
| **Libreria CSV** | SuperCSV (`org.supercsv`) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.*
import groovy.xml.*
import org.supercsv.cellprocessor.*
import org.supercsv.cellprocessor.constraint.*
import org.supercsv.cellprocessor.ift.*
import org.supercsv.io.*
import org.supercsv.prefs.*
import org.supercsv.quote.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\csv_data_no_header.txt")
    File outputFile = new File("$dataDir\\csv_data_no_header_to_xml_manual_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {

    //Standard CSV
    ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), CsvPreference.STANDARD_PREFERENCE)

    //Custom CsvPreference parameters
    //char quoteChar = '"'
    //int delimiterChar = ','
    //String endOfLine = "\r\n"
    //CsvPreference customCsvPreference = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
    //ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), customCsvPreference)

    String fieldList = "idoc_no,order_no,ship_to,sold_to,order_date,line_item,material,quantity,quantity_uom,weight,weight_uom"
    String[] header = fieldList.split(',')
    int columnsCount = header.length
    CellProcessor[] processor = new CellProcessor[columnsCount]
    def rowMap = [:]   // ← Declaracion explicita requerida

    def builder = new StreamingMarkupBuilder()

    def writer = builder.bind {
        root {
            while ((rowMap = mapReader.read(header, processor)) != null) {
                row {
                    "idoc_no"(rowMap["idoc_no"])
                    "order_no"(rowMap["order_no"])
                    "line_item"(rowMap["line_item"])
                    "material"(rowMap["material"])
                    "quantity"(rowMap["quantity"])
                    "quantity_uom"(rowMap["quantity_uom"])
                }
            }
        }
    }

    def output = XmlUtil.serialize(writer.toString())

    return output
}
```

---

## Explicacion por secciones

### 1. La variante mas simple de los templates CSV

T12 Manual combina:
- CSV sin header (fieldList manual)
- XML output (StreamingMarkupBuilder)
- Seleccion manual de campos

Sin `formatFieldName()`, sin lista intermedia `v_row_list`, sin iteracion dinamica.

### 2. Declaracion obligatoria de rowMap

```groovy
def rowMap = [:]   // Declarado ANTES del builder.bind
```

Igual que T12 Auto, esta declaracion es obligatoria para que `rowMap` sea accesible dentro del closure de `StreamingMarkupBuilder`.

### 3. Mapeo explicito de campos CSV → XML

```groovy
row {
    "idoc_no"(rowMap["idoc_no"])       // XML = rowMap[fieldList nombre]
    "order_no"(rowMap["order_no"])
    "line_item"(rowMap["line_item"])
    "material"(rowMap["material"])
    "quantity"(rowMap["quantity"])
    "quantity_uom"(rowMap["quantity_uom"])
}
```

Como `fieldList` usa nombres con guion bajo (`idoc_no`, etc.), tanto el nombre del elemento XML como la clave del mapa son iguales en este caso.

**Campos incluidos:** 6 de 11

**Campos excluidos:**
- `ship_to` (columna 3)
- `sold_to` (columna 4)
- `order_date` (columna 5)
- `weight` (columna 10)
- `weight_uom` (columna 11)

### 4. Tabla comparativa de todas las variantes CSV

| Template | Input | Output | Header | Campos output | `rowMap` decl. |
|----------|-------|--------|--------|---------------|----------------|
| T09 Auto | CSV + header | JSON | `getHeader(true)` | Todos | No |
| T09 Manual | CSV + header | JSON | `getHeader(true)` | Seleccionados | No |
| T10 Auto | CSV + header | XML | `getHeader(true)` | Todos | No |
| T10 Manual | CSV + header | XML | `getHeader(true)` | Seleccionados | No |
| T11 Auto | CSV sin header | JSON | `fieldList` | Todos | No |
| T11 Manual | CSV sin header | JSON | `fieldList` | Seleccionados | No |
| T12 Auto | CSV sin header | XML | `fieldList` | Todos | **Si** |
| **T12 Manual** | **CSV sin header** | **XML** | **`fieldList`** | **Seleccionados** | **Si** |

---

## Ejemplo de salida (XML Manual)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <line_item>00001</line_item>
    <material>800111</material>
    <quantity>10.000</quantity>
    <quantity_uom>pce</quantity_uom>
  </row>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <line_item>00002</line_item>
    <material>800222</material>
    <quantity>100.000</quantity>
    <quantity_uom>pce</quantity_uom>
  </row>
</root>
```

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ `def rowMap = [:]` es **obligatorio** (diferencia con T10 Manual)
- ✅ Los nombres en `rowMap["..."]` deben coincidir con los nombres en `fieldList`
- ✅ Los nombres de elementos XML deben ser identificadores validos (sin espacios ni caracteres especiales)
