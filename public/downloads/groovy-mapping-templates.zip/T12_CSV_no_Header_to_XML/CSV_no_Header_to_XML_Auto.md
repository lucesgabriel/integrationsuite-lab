# CSV_no_Header_to_XML_Auto.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T12 - Variante Auto |
| **Archivo** | `CSV_no_Header_to_XML_Auto.groovy` |
| **Conversion** | CSV sin header → XML (todos los campos via fieldList) |
| **Formato entrada** | CSV sin primera fila de cabecera |
| **Formato salida** | XML plano (`<root><row>`) |
| **Libreria CSV** | SuperCSV (`org.supercsv`) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.*
import groovy.xml.*
import org.supercsv.cellprocessor.*
import org.supercsv.cellprocessor.constraint.*
import org.supercsv.cellprocessor.ift.*
import org.supercsv.io.*
import org.supercsv.prefs.*
import org.supercsv.quote.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\csv_data_no_header.txt")
    File outputFile = new File("$dataDir\\csv_data_no_header_to_xml_auto_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {

    //Standard CSV
    ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), CsvPreference.STANDARD_PREFERENCE)

    //Custom CsvPreference parameters
    //char quoteChar = '"'
    //int delimiterChar = ','
    //String endOfLine = "\r\n"
    //CsvPreference customCsvPreference = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
    //ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), customCsvPreference)

    String fieldList = "idoc_no,order_no,ship_to,sold_to,order_date,line_item,material,quantity,quantity_uom,weight,weight_uom"
    String[] header = fieldList.split(',')
    int columnsCount = header.length
    CellProcessor[] processor = new CellProcessor[columnsCount]
    def rowMap = [:]   // ← Declaracion explicita requerida en T12

    def builder = new StreamingMarkupBuilder()

    def writer = builder.bind {
        root {
            while ((rowMap = mapReader.read(header, processor)) != null) {
                row {
                    header.each{ this_field ->
                        if(this_field != null){
                            def fieldName = formatFieldName(this_field)
                            def fieldValue = rowMap[this_field]
                            "$fieldName"(fieldValue)
                        }
                    }
                }
            }
        }
    }

    def output = XmlUtil.serialize(writer.toString())

    return output
}

def formatFieldName(String fieldName) {
    fieldName = fieldName.replaceAll("[^a-zA-Z0-9_]", "")
    //fieldName = fieldName.toLowerCase()
    return fieldName
}
```

---

## Explicacion por secciones

### 1. Posicion en la matriz de templates

```
T09 Auto: CSV CON header → JSON  |  T10 Auto: CSV CON header → XML
T11 Auto: CSV SIN header → JSON  |  T12 Auto: CSV SIN header → XML  ← este archivo
```

### 2. Nota tecnica critica: declaracion de `rowMap`

```groovy
def rowMap = [:]   // ← NECESARIO en T12
```

Esta declaracion explicita es requerida porque `rowMap` se usa dentro del closure `builder.bind { ... }`. En Groovy, una variable definida dentro de un `while` no es accesible en el scope del closure si no se declara previamente.

Comparacion con templates similares:

| Template | Declaracion de rowMap | Motivo |
|----------|----------------------|--------|
| T09 Auto | No declarado (`while ((rowMap = ...))`) | `rowMap` queda en scope global implicito |
| T10 Auto | No declarado | Mismo caso |
| T11 Auto | No declarado | Fuera del bind, no hay problema |
| **T12 Auto** | **`def rowMap = [:]` declarado** | **Dentro de `builder.bind`, necesita scope previo** |
| T12 Manual | `def rowMap = [:]` declarado | Mismo caso |

### 3. fieldList como header virtual

```groovy
String fieldList = "idoc_no,order_no,ship_to,sold_to,order_date,line_item,material,quantity,quantity_uom,weight,weight_uom"
String[] header = fieldList.split(',')
// No se llama mapReader.getHeader(true) → el CSV no tiene header
```

### 4. Streaming directo dentro del bind

```groovy
def writer = builder.bind {
    root {
        while ((rowMap = mapReader.read(header, processor)) != null) {
            row {
                header.each { this_field ->
                    if (this_field != null) {
                        def fieldName  = formatFieldName(this_field)
                        def fieldValue = rowMap[this_field]
                        "$fieldName"(fieldValue)
                    }
                }
            }
        }
    }
}
```

Como los nombres en `fieldList` ya son validos, `formatFieldName()` los retorna sin cambios:
- `"idoc_no"` → `"idoc_no"` (sin modificacion)
- `"quantity_uom"` → `"quantityuom"` → NO, `"quantity_uom"` → `"quantity_uom"` (guion bajo se conserva)

**Regex aplicada:** `[^a-zA-Z0-9_]` → elimina todo excepto letras, numeros y guion bajo. El guion bajo se conserva.

### 5. Null check del campo

```groovy
if (this_field != null) { ... }
```

Aunque con `fieldList` manual es menos probable tener nulos, la comprobacion se mantiene por seguridad.

---

## Correspondencia posicional CSV → XML

| Posicion | CSV | `fieldList` nombre | Elemento XML |
|----------|-----|--------------------|--------------|
| 1 | `888888` | `idoc_no` | `<idoc_no>` |
| 2 | `5000123456` | `order_no` | `<order_no>` |
| 3 | `BBBB-222` | `ship_to` | `<ship_to>` |
| 4 | `AAAA-111` | `sold_to` | `<sold_to>` |
| 5 | `20211201` | `order_date` | `<order_date>` |
| 6 | `00001` | `line_item` | `<line_item>` |
| 7 | `800111` | `material` | `<material>` |
| 8 | `10.000` | `quantity` | `<quantity>` |
| 9 | `pce` | `quantity_uom` | `<quantity_uom>` |
| 10 | `20` | `weight` | `<weight>` |
| 11 | `kgm` | `weight_uom` | `<weight_uom>` |

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ La declaracion `def rowMap = [:]` es **obligatoria** en esta variante
- ✅ El numero de campos en `fieldList` debe coincidir exactamente con las columnas del CSV
