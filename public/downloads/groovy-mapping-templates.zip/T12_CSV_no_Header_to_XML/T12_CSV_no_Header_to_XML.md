# T12 - CSV no Header to XML

## Descripcion

Convierte un archivo CSV **sin fila de cabecera** a formato XML. Los nombres de campo se definen manualmente en el script mediante una `fieldList`. Es el equivalente XML del template T11.

## Transformacion

```
INPUT:  CSV sin header (solo filas de datos)
OUTPUT: XML Flat (<root><row>...</row></root>)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `CSV_no_Header_to_XML_Auto.groovy` | Mapeo automatico usando fieldList |
| `CSV_no_Header_to_XML_Manual.groovy` | Mapeo manual de campos seleccionados |
| `Data/csv_data_no_header.txt` | CSV sin header de ejemplo |
| `Data/csv_data_no_header_to_xml_auto_output.txt` | Salida Auto |
| `Data/csv_data_no_header_to_xml_manual_output.txt` | Salida Manual |

## Librerias utilizadas

```groovy
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.*
import groovy.xml.*
import org.supercsv.cellprocessor.*
import org.supercsv.io.*
import org.supercsv.prefs.*
import org.supercsv.quote.*
```

## Definicion del header manual

```groovy
String fieldList = "idoc_no,order_no,ship_to,sold_to,order_date,line_item,material,quantity,quantity_uom,weight,weight_uom"
String[] header = fieldList.split(',')
int columnsCount = header.length
CellProcessor[] processor = new CellProcessor[columnsCount]
def rowMap = [:]  // Nota: T12 declara rowMap explicitamente (diferencia con T11)
```

## Comparacion de templates CSV sin header

| Template | Input | Output |
|----------|-------|--------|
| T11 Auto | CSV sin header | JSON (todos los campos) |
| T11 Manual | CSV sin header | JSON (campos seleccionados) |
| **T12 Auto** | **CSV sin header** | **XML (todos los campos)** |
| **T12 Manual** | **CSV sin header** | **XML (campos seleccionados)** |

## Variante AUTO

Lee el CSV y genera XML con todos los campos de `fieldList`. La lectura ocurre dentro del `builder.bind`:

```groovy
def builder = new StreamingMarkupBuilder()
def writer = builder.bind {
    root {
        while ((rowMap = mapReader.read(header, processor)) != null) {
            row {
                header.each { this_field ->
                    if (this_field != null) {
                        def fieldName = formatFieldName(this_field)
                        def fieldValue = rowMap[this_field]
                        "$fieldName"(fieldValue)
                    }
                }
            }
        }
    }
}
def output = XmlUtil.serialize(writer.toString())
```

## Variante MANUAL

Selecciona campos especificos:

```groovy
def writer = builder.bind {
    root {
        while ((rowMap = mapReader.read(header, processor)) != null) {
            row {
                "idoc_no"(rowMap["idoc_no"])
                "order_no"(rowMap["order_no"])
                "line_item"(rowMap["line_item"])
                "material"(rowMap["material"])
                "quantity"(rowMap["quantity"])
                "quantity_uom"(rowMap["quantity_uom"])
            }
        }
    }
}
```

## Ejemplo de entrada (CSV sin header)

```csv
888888,5000123456,BBBB-222,AAAA-111,20211201,00001,800111,10.000,pce,20,kgm
888888,5000123456,BBBB-222,AAAA-111,20211201,00002,800222,100.000,pce,200,kgm
```

## Ejemplo de salida Auto (XML)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <order_date>20211201</order_date>
    <line_item>00001</line_item>
    <material>800111</material>
    <quantity>10.000</quantity>
    <quantity_uom>pce</quantity_uom>
    <weight>20</weight>
    <weight_uom>kgm</weight_uom>
  </row>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <order_date>20211201</order_date>
    <line_item>00002</line_item>
    <material>800222</material>
    <quantity>100.000</quantity>
    <quantity_uom>pce</quantity_uom>
    <weight>200</weight>
    <weight_uom>kgm</weight_uom>
  </row>
</root>
```

## Nota tecnica: declaracion de rowMap

T12 declara `def rowMap = [:]` explicitamente antes del bloque `builder.bind`, a diferencia de T11 donde se declara implicitamente. Esto es necesario porque `rowMap` debe estar disponible en el scope del closure de Groovy.

```groovy
def rowMap = [:]  // Declaracion explicita requerida en T12 Auto y Manual
def writer = builder.bind {
    root {
        while ((rowMap = mapReader.read(header, processor)) != null) { ... }
    }
}
```
