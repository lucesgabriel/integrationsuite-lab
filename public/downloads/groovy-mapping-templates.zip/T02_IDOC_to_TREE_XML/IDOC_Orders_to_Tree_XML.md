# IDOC_Orders_to_Tree_XML.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T02 |
| **Archivo** | `IDOC_Orders_to_Tree_XML.groovy` |
| **Conversion** | IDoc XML (ORDERS05) → XML Tree jerarquico |
| **Formato entrada** | XML (IDoc) |
| **Formato salida** | XML (Tree) |
| **Estructura salida** | Jerarquica (Tree) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun(){
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\idoc_orders.txt")
    File outputFile = new File("$dataDir\\idoc_orders_to_tree_xml_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {
    def InputPayload = new XmlSlurper().parseText(body)

    def builder = new StreamingMarkupBuilder()

    // MAPPING
    def writer = builder.bind {
        mkp.xmlDeclaration()

        orders {
            InputPayload.IDOC.each { this_IDOC ->
                order {
                    header {
                        idoc_no(this_IDOC.EDI_DC40.DOCNUM.toString().replaceFirst("^0*", ""))
                        order_no(this_IDOC.E1EDK01.BELNR.toString())

                        this_IDOC.E1EDKA1.each { this_E1EDKA1 ->
                            if (this_E1EDKA1.PARVW.toString() == "WE") {
                                ship_to(this_E1EDKA1.PARTN.toString())
                            }
                            if (this_E1EDKA1.PARVW.toString() == "AG") {
                                sold_to(this_E1EDKA1.PARTN.toString())
                            }
                        }

                        this_IDOC.E1EDK03.each { this_E1EDK03 ->
                            if (this_E1EDK03.IDDAT.toString() == "012") {
                                order_date(this_E1EDK03.DATUM.toString())
                            }
                        }
                    }
                    this_IDOC.E1EDP01.each { this_E1EDP01 ->
                        item {
                            line_item(this_E1EDP01.POSEX.toString())

                            this_E1EDP01.E1EDP19.each { this_E1EDP19 ->
                                if (this_E1EDP19.QUALF.toString() == "001") {
                                    material(this_E1EDP19.IDTNR.toString().replaceFirst("^0*", ""))
                                }
                            }

                            quantity(this_E1EDP01.MENGE.toString())
                            quantity_uom(this_E1EDP01.MENEE.toString().toLowerCase())
                            weight(this_E1EDP01.NTGEW.toString())
                            weight_uom(this_E1EDP01.GEWEI.toString().toLowerCase())

                            schedule {
                                this_E1EDP01.E1EDP20.each { this_E1EDP20 ->
                                    line {
                                        schedule_qty(this_E1EDP20.WMENG.toString())
                                        schedule_date(this_E1EDP20.EDATU.toString())
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // WRITING
    //def output = writer.toString()
    def output = XmlUtil.serialize(writer.toString())

    return output
}
```

---

## Explicacion por secciones

### 1. Import clave

```groovy
import groovy.xml.*   // XmlSlurper, StreamingMarkupBuilder, XmlUtil
```

A diferencia de T01 que usa `groovy.json.*`, este script solo necesita `groovy.xml.*`.

### 2. Construccion del XML de salida

```groovy
def builder = new StreamingMarkupBuilder()

def writer = builder.bind {
    mkp.xmlDeclaration()   // Genera: <?xml version="1.0" encoding="UTF-8"?>

    orders {               // Elemento raiz <orders>
        InputPayload.IDOC.each { this_IDOC ->
            order { ... } // <order> por cada IDOC
        }
    }
}
```

#### Diferencia fundamental con T01

| Aspecto | T01 (JSON) | T02 (XML) |
|---------|-----------|----------|
| Builder | `StreamingJsonBuilder(writer)` | `StreamingMarkupBuilder()` |
| Binding | `builder { ... }` (directo) | `builder.bind { ... }` (retorna writer) |
| Declaracion | No aplica | `mkp.xmlDeclaration()` |
| Serializacion | `JsonOutput.prettyPrint(writer.toString())` | `XmlUtil.serialize(writer.toString())` |

### 3. Iteracion de IDOCs

```groovy
InputPayload.IDOC.each { this_IDOC ->
    order { ... }
}
```

En T01 se usa la sintaxis: `orders(InputPayload.IDOC) { this_IDOC -> }` (mas compacta).
En T02 se usa `.each` explicito dentro del bloque `orders {}`.

### 4. Estructura de la cabecera

```groovy
header {
    idoc_no(this_IDOC.EDI_DC40.DOCNUM.toString().replaceFirst("^0*", ""))
    order_no(this_IDOC.E1EDK01.BELNR.toString())
    // filtros E1EDKA1 y E1EDK03 identicos a T01
}
```

### 5. Estructura de items con `.each` explicito

```groovy
this_IDOC.E1EDP01.each { this_E1EDP01 ->
    item {
        line_item(this_E1EDP01.POSEX.toString())
        // ...
    }
}
```

En T02, los items usan `this_IDOC.E1EDP01.each { ... }` dentro del bloque `order {}`.

### 6. Estructura de schedules con elemento `<line>`

```groovy
schedule {
    this_E1EDP01.E1EDP20.each { this_E1EDP20 ->
        line {
            schedule_qty(this_E1EDP20.WMENG.toString())
            schedule_date(this_E1EDP20.EDATU.toString())
        }
    }
}
```

En T01 (JSON): `schedule` es un array con objetos directos.
En T02 (XML): `<schedule>` contiene elementos `<line>` que envuelven cada schedule.

### 7. Serializacion XML

```groovy
// Opcion 1: XML sin formato (compacto)
// def output = writer.toString()

// Opcion 2: XML formateado con indentacion (activo)
def output = XmlUtil.serialize(writer.toString())
```

`XmlUtil.serialize()` agrega indentacion y el encoding UTF-8.

---

## Mapeo de campos

| Elemento XML salida | Segmento IDoc | Campo IDoc | Transformacion |
|---------------------|---------------|------------|----------------|
| `orders/order/header/idoc_no` | `EDI_DC40` | `DOCNUM` | `.replaceFirst("^0*", "")` |
| `orders/order/header/order_no` | `E1EDK01` | `BELNR` | `.toString()` |
| `orders/order/header/sold_to` | `E1EDKA1[PARVW=AG]` | `PARTN` | `.toString()` |
| `orders/order/header/ship_to` | `E1EDKA1[PARVW=WE]` | `PARTN` | `.toString()` |
| `orders/order/header/order_date` | `E1EDK03[IDDAT=012]` | `DATUM` | `.toString()` |
| `orders/order/item/line_item` | `E1EDP01` | `POSEX` | `.toString()` |
| `orders/order/item/material` | `E1EDP19[QUALF=001]` | `IDTNR` | `.replaceFirst("^0*", "")` |
| `orders/order/item/quantity` | `E1EDP01` | `MENGE` | `.toString()` |
| `orders/order/item/quantity_uom` | `E1EDP01` | `MENEE` | `.toLowerCase()` |
| `orders/order/item/weight` | `E1EDP01` | `NTGEW` | `.toString()` |
| `orders/order/item/weight_uom` | `E1EDP01` | `GEWEI` | `.toLowerCase()` |
| `orders/order/item/schedule/line/schedule_qty` | `E1EDP20` | `WMENG` | `.toString()` |
| `orders/order/item/schedule/line/schedule_date` | `E1EDP20` | `EDATU` | `.toString()` |

---

## Estructura XML de salida

```xml
<?xml version="1.0" encoding="UTF-8"?>
<orders>
  <order>
    <header>
      <idoc_no>888888</idoc_no>
      <order_no>5000123456</order_no>
      <sold_to>AAAA-111</sold_to>
      <ship_to>BBBB-222</ship_to>
      <order_date>20211201</order_date>
    </header>
    <item>
      <line_item>00001</line_item>
      <material>800111</material>
      <quantity>10.000</quantity>
      <quantity_uom>pce</quantity_uom>
      <weight>20</weight>
      <weight_uom>kgm</weight_uom>
      <schedule>
        <line>
          <schedule_qty>10.000</schedule_qty>
          <schedule_date>20211210</schedule_date>
        </line>
      </schedule>
    </item>
  </order>
</orders>
```
