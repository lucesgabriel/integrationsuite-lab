# T02 - IDOC to Tree XML

## Descripcion

Convierte un mensaje IDoc SAP (ORDERS05 XML) a una estructura XML jerarquica (arbol) con elementos anidados de ordenes, cabecera, items y schedules.

## Transformacion

```
INPUT:  IDOC XML (ORDERS05)
OUTPUT: XML Tree (orders > order > header + item > schedule > line)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `IDOC_Orders_to_Tree_XML.groovy` | Script principal de mapeo |
| `Data/idoc_orders.txt` | Datos de entrada de ejemplo (IDOC XML) |
| `Data/idoc_orders_to_tree_xml_output.txt` | Salida esperada (XML Tree) |

## Librerias utilizadas

```groovy
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*
```

- `XmlSlurper` - para parsear el input IDoc XML
- `StreamingMarkupBuilder` - para construir el output XML
- `XmlUtil.serialize` - para formatear el XML resultante con indentacion

## Logica de mapeo

### Segmentos IDoc leidos

| Segmento IDoc | Campo | Elemento XML de salida |
|---------------|-------|------------------------|
| `EDI_DC40` | `DOCNUM` | `header/idoc_no` (sin ceros) |
| `E1EDK01` | `BELNR` | `header/order_no` |
| `E1EDKA1` (PARVW=AG) | `PARTN` | `header/sold_to` |
| `E1EDKA1` (PARVW=WE) | `PARTN` | `header/ship_to` |
| `E1EDK03` (IDDAT=012) | `DATUM` | `header/order_date` |
| `E1EDP01` | `POSEX` | `item/line_item` |
| `E1EDP19` (QUALF=001) | `IDTNR` | `item/material` (sin ceros) |
| `E1EDP01` | `MENGE` | `item/quantity` |
| `E1EDP01` | `MENEE` | `item/quantity_uom` (lowercase) |
| `E1EDP01` | `NTGEW` | `item/weight` |
| `E1EDP01` | `GEWEI` | `item/weight_uom` (lowercase) |
| `E1EDP20` | `WMENG` | `item/schedule/line/schedule_qty` |
| `E1EDP20` | `EDATU` | `item/schedule/line/schedule_date` |

### Transformaciones especiales

- `DOCNUM`: elimina ceros a la izquierda con `.replaceFirst("^0*", "")`
- `IDTNR`: elimina ceros a la izquierda con `.replaceFirst("^0*", "")`
- `MENEE` / `GEWEI`: convertidos a minusculas con `.toLowerCase()`
- Filtro de `E1EDKA1` por `PARVW` para separar sold_to (AG) y ship_to (WE)
- Filtro de `E1EDK03` por `IDDAT=012` para fecha de orden

### Diferencia con T01 (JSON)

| Aspecto | T01 JSON | T02 XML |
|---------|----------|---------|
| Builder | `StreamingJsonBuilder` | `StreamingMarkupBuilder` |
| Formato final | `JsonOutput.prettyPrint` | `XmlUtil.serialize` |
| Schedule | Array JSON `schedule[]` | `<schedule><line>` anidado |
| Declaracion | Sin declaracion | `mkp.xmlDeclaration()` |

## Estructura del script

```groovy
def Message processData(Message message)  // Entry point CPI
void TestRun()                            // Solo para debug local
def DoMapping(String body, Map headers, Map properties)  // Logica principal
```

> **Nota CPI:** Comentar `TestRun()` antes de subir a SAP CPI.

## Ejemplo de entrada (IDoc XML)

```xml
<ORDERS05>
  <IDOC BEGIN="1">
    <EDI_DC40 SEGMENT="1">
      <DOCNUM>0000000000888888</DOCNUM>
    </EDI_DC40>
    <E1EDK01 SEGMENT="1">
      <BELNR>5000123456</BELNR>
    </E1EDK01>
    <E1EDKA1 SEGMENT="1">
      <PARVW>AG</PARVW>
      <PARTN>AAAA-111</PARTN>
    </E1EDKA1>
    <E1EDP01 SEGMENT="1">
      <POSEX>00001</POSEX>
      <E1EDP20 SEGMENT="1">
        <WMENG>10.000</WMENG>
        <EDATU>20211210</EDATU>
      </E1EDP20>
    </E1EDP01>
  </IDOC>
</ORDERS05>
```

## Ejemplo de salida (XML Tree)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<orders>
  <order>
    <header>
      <idoc_no>888888</idoc_no>
      <order_no>5000123456</order_no>
      <sold_to>AAAA-111</sold_to>
      <ship_to>BBBB-222</ship_to>
      <order_date>20211201</order_date>
    </header>
    <item>
      <line_item>00001</line_item>
      <material>800111</material>
      <quantity>10.000</quantity>
      <quantity_uom>pce</quantity_uom>
      <weight>20</weight>
      <weight_uom>kgm</weight_uom>
      <schedule>
        <line>
          <schedule_qty>10.000</schedule_qty>
          <schedule_date>20211210</schedule_date>
        </line>
      </schedule>
    </item>
    <item>
      <line_item>00002</line_item>
      <material>800222</material>
      <quantity>100.000</quantity>
      <quantity_uom>pce</quantity_uom>
      <weight>200</weight>
      <weight_uom>kgm</weight_uom>
      <schedule>
        <line>
          <schedule_qty>40.000</schedule_qty>
          <schedule_date>20211210</schedule_date>
        </line>
        <line>
          <schedule_qty>60.000</schedule_qty>
          <schedule_date>20211220</schedule_date>
        </line>
      </schedule>
    </item>
  </order>
</orders>
```

## Jerarquia XML de salida

```
orders
  order
    header
      idoc_no
      order_no
      sold_to
      ship_to
      order_date
    item (repetible)
      line_item
      material
      quantity
      quantity_uom
      weight
      weight_uom
      schedule
        line (repetible)
          schedule_qty
          schedule_date
```
