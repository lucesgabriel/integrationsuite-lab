# CSV_with_Header_to_JSON_Manual.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T09 - Variante Manual |
| **Archivo** | `CSV_with_Header_to_JSON_Manual.groovy` |
| **Conversion** | CSV con header → JSON (campos seleccionados manualmente) |
| **Formato entrada** | CSV con primera fila de cabecera |
| **Formato salida** | JSON plano |
| **Libreria CSV** | SuperCSV (`org.supercsv`) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.StreamingJsonBuilder
import groovy.util.*
import groovy.xml.*
import org.supercsv.cellprocessor.*
import org.supercsv.cellprocessor.constraint.*
import org.supercsv.cellprocessor.ift.*
import org.supercsv.io.*
import org.supercsv.prefs.*
import org.supercsv.quote.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\csv_data_with_header.txt")
    File outputFile = new File("$dataDir\\csv_data_with_header_to_json_manual_output.txt")
    //File inputFile = new File("$dataDir\\csv_complex_with_header.txt")
    //File outputFile = new File("$dataDir\\csv_complex_with_header_to_json_manual_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {

    //Standard CSV
    ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), CsvPreference.STANDARD_PREFERENCE)

    //Custom CsvPreference parameters
    //char quoteChar = '"'
    //int delimiterChar = ','
    //String endOfLine = "\r\n"
    //CsvPreference customCsvPreference = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
    //ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), customCsvPreference)

    String[] header = mapReader.getHeader(true)
    int columnsCount = header.length
    CellProcessor[] processor = new CellProcessor[columnsCount]

    def writer = new StringWriter()
    def builder = new StreamingJsonBuilder(writer)

    def v_row_list = []

    while ((rowMap = mapReader.read(header, processor)) != null) {
        v_row_list.add(rowMap)  // Se agrega el rowMap original sin renombrar
    }

    builder {
        row(v_row_list) { rowMap ->

            //Selected fields from csv_data_with_header.txt
            "idoc_no"(rowMap["idoc no"])
            "order_no"(rowMap["order no"])
            "line_item"(rowMap["line-item#"])
            "material"(rowMap["material"])
            "quantity"(rowMap["quantity"])
            "quantity_uom"(rowMap["quantity(uom)"])

            //Selected fields from csv_complex_with_header.txt
//            "ContactID"(rowMap["Contact ID"])
//            "FirstName"(rowMap["First Name"])
//            "LastName"(rowMap["Last Name"])
//            "PreferredComm"(rowMap["Preferred Communication Method"])
//            "Email"(rowMap["Email"])
//            "Phone"(rowMap["Phone"])
        }
    }

    def output = JsonOutput.prettyPrint(writer.toString())
}
```

---

## Explicacion por secciones

### 1. Diferencia critica con la variante Auto

La diferencia fundamental esta en el **bucle de lectura** y el **bloque de construccion del JSON**:

**Auto:** renombra durante la lectura, luego itera el mapa renombrado
```groovy
while ((rowMap = mapReader.read(header, processor)) != null) {
    def rowMapRenamed = [:]
    header.each { this_field ->
        def fieldName = formatFieldName(this_field)  // Sanitiza
        rowMapRenamed.put(fieldName, fieldValue)
    }
    v_row_list.add(rowMapRenamed)                    // Guarda renombrado
}

builder {
    row(v_row_list) { rowMap ->
        rowMap.each { rowField ->
            "$rowField.key"(rowField.value)          // Itera todos los campos
        }
    }
}
```

**Manual:** conserva el rowMap original, selecciona manualmente en el builder
```groovy
while ((rowMap = mapReader.read(header, processor)) != null) {
    v_row_list.add(rowMap)    // Guarda con nombres originales del CSV
}

builder {
    row(v_row_list) { rowMap ->
        "idoc_no"(rowMap["idoc no"])         // Nombre destino → Nombre origen CSV
        "order_no"(rowMap["order no"])
        "line_item"(rowMap["line-item#"])
        "material"(rowMap["material"])
        "quantity"(rowMap["quantity"])
        "quantity_uom"(rowMap["quantity(uom)"])
    }
}
```

### 2. Mapeo manual de campos

```groovy
"idoc_no"(rowMap["idoc no"])
//  ↑ clave JSON    ↑ columna CSV (con nombre original incluyendo espacios)
```

| Clave JSON salida | Columna CSV origen |
|-------------------|-------------------|
| `"idoc_no"` | `rowMap["idoc no"]` |
| `"order_no"` | `rowMap["order no"]` |
| `"line_item"` | `rowMap["line-item#"]` |
| `"material"` | `rowMap["material"]` |
| `"quantity"` | `rowMap["quantity"]` |
| `"quantity_uom"` | `rowMap["quantity(uom)"]` |

**Campos omitidos** (no incluidos en el output manual): `ship to`, `sold to`, `order date`, `weight`, `weight(uom)`

### 3. Campos para CSV complejo (comentados)

```groovy
//Selected fields from csv_complex_with_header.txt
// "ContactID"(rowMap["Contact ID"])
// "FirstName"(rowMap["First Name"])
// "LastName"(rowMap["Last Name"])
// "PreferredComm"(rowMap["Preferred Communication Method"])
// "Email"(rowMap["Email"])
// "Phone"(rowMap["Phone"])
```

Para cambiar el CSV fuente, hay que:
1. Cambiar el archivo de input en `TestRun()`
2. Comentar los campos del CSV simple
3. Descomentar los campos del CSV complejo

### 4. Ventajas del modo Manual

- **Control total** sobre los campos de salida
- **Renombrado explícito**: el nombre JSON puede ser completamente diferente al nombre CSV
- **Seleccion de campos**: solo se incluyen los necesarios, reduciendo el payload
- **Claridad**: el codigo documenta exactamente que campos se mapean y como

---

## Ejemplo de salida (CSV simple, campos seleccionados)

```json
{
    "row": [
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "line_item": "00001",
            "material": "800111",
            "quantity": "10.000",
            "quantity_uom": "pce"
        },
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "line_item": "00002",
            "material": "800222",
            "quantity": "100.000",
            "quantity_uom": "pce"
        }
    ]
}
```

**Notar:** Solo 6 campos en el output aunque el CSV tiene 11 columnas.

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ Ajustar los campos en el bloque `builder { row(...) { rowMap -> } }` segun el CSV especifico
- ✅ Los nombres de columna CSV en `rowMap["..."]` deben coincidir exactamente con el header del CSV (incluyendo espacios y caracteres especiales)
- ✅ No requiere la funcion `formatFieldName()` (a diferencia de Auto)
