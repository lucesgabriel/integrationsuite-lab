# CSV_with_Header_to_JSON_Auto.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T09 - Variante Auto |
| **Archivo** | `CSV_with_Header_to_JSON_Auto.groovy` |
| **Conversion** | CSV con header → JSON (todos los campos automaticamente) |
| **Formato entrada** | CSV con primera fila de cabecera |
| **Formato salida** | JSON plano |
| **Libreria CSV** | SuperCSV (`org.supercsv`) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.StreamingJsonBuilder
import groovy.util.*
import groovy.xml.*
import org.supercsv.cellprocessor.*
import org.supercsv.cellprocessor.constraint.*
import org.supercsv.cellprocessor.ift.*
import org.supercsv.io.*
import org.supercsv.prefs.*
import org.supercsv.quote.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\csv_data_with_header.txt")
    File outputFile = new File("$dataDir\\csv_data_with_header_to_json_auto_output.txt")
    //File inputFile = new File("$dataDir\\csv_complex_with_header.txt")
    //File outputFile = new File("$dataDir\\csv_complex_with_header_to_json_auto_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {

    //Standard CSV
    ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), CsvPreference.STANDARD_PREFERENCE)

    //Custom CsvPreference parameters
//    char quoteChar = '"'
//    int delimiterChar = ','
//    String endOfLine = "\r\n"
//    CsvPreference customCsvPreference = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
//    ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), customCsvPreference)

    String[] header = mapReader.getHeader(true)
    int columnsCount = header.length
    CellProcessor[] processor = new CellProcessor[columnsCount]

    def writer = new StringWriter()
    def builder = new StreamingJsonBuilder(writer)

    def v_row_list = []

    while ((rowMap = mapReader.read(header, processor)) != null) {
        def rowMapRenamed = [:]
        header.each { this_field ->
            def fieldName = formatFieldName(this_field)
            def fieldValue = rowMap[this_field]
            rowMapRenamed.put(fieldName, fieldValue)
        }
        v_row_list.add(rowMapRenamed)
    }

    builder {
        row(v_row_list) { rowMap ->
            rowMap.each { rowField ->
                "$rowField.key"(rowField.value)
            }
        }
    }

    def output = JsonOutput.prettyPrint(writer.toString())
}

def formatFieldName(String fieldName) {
    fieldName = fieldName.replaceAll("[^a-zA-Z0-9_]", "")
    //fieldName = fieldName.toLowerCase()
    return fieldName
}
```

---

## Explicacion por secciones

### 1. Imports SuperCSV

```groovy
import org.supercsv.cellprocessor.*             // Procesadores de celdas (Optional, NotNull, etc.)
import org.supercsv.cellprocessor.constraint.*  // Restricciones (StrMinMax, NotNull, etc.)
import org.supercsv.cellprocessor.ift.*         // Interface CellProcessor
import org.supercsv.io.*                        // CsvMapReader, CsvMapWriter
import org.supercsv.prefs.*                     // CsvPreference
import org.supercsv.quote.*                     // AlwaysQuoteMode, etc.
```

### 2. Inicializacion del lector CSV

```groovy
// Opcion estandar (coma, comillas dobles, CRLF)
ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), CsvPreference.STANDARD_PREFERENCE)

// Alternativa personalizada (comentada):
// char quoteChar = '"'
// int delimiterChar = ','
// String endOfLine = "\r\n"
// CsvPreference customCsvPreference = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
// ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), customCsvPreference)
```

### 3. Lectura del header

```groovy
String[] header = mapReader.getHeader(true)
// true = la primera linea ES el header (la consume y avanza al primer dato)
// Ejemplo: ["idoc no", "order no", "ship to", "sold to", ...]

int columnsCount = header.length
CellProcessor[] processor = new CellProcessor[columnsCount]
// processor con todos null = sin procesamiento de celda (trata todo como String)
```

### 4. Bucle de lectura y renombrado AUTO

```groovy
while ((rowMap = mapReader.read(header, processor)) != null) {
    // rowMap = {"idoc no": "888888", "order no": "5000123456", ...}

    def rowMapRenamed = [:]
    header.each { this_field ->
        def fieldName  = formatFieldName(this_field)  // Sanitiza el nombre
        def fieldValue = rowMap[this_field]            // Valor original
        rowMapRenamed.put(fieldName, fieldValue)       // Mapa con nombre limpio
    }
    v_row_list.add(rowMapRenamed)
}
```

### 5. Funcion `formatFieldName` - Sanitizacion de nombres

```groovy
def formatFieldName(String fieldName) {
    fieldName = fieldName.replaceAll("[^a-zA-Z0-9_]", "")
    // Regex: elimina todo lo que NO sea letra, numero o guion bajo
    //fieldName = fieldName.toLowerCase()  // Opcional: convertir a minusculas
    return fieldName
}
```

**Ejemplos de transformacion:**

| Nombre original (CSV header) | Nombre sanitizado (JSON key) |
|------------------------------|------------------------------|
| `"idoc no"` | `"idocno"` |
| `"order no"` | `"orderno"` |
| `"ship to"` | `"shipto"` |
| `"sold to"` | `"soldto"` |
| `"order date"` | `"orderdate"` |
| `"line-item#"` | `"lineitem"` |
| `"quantity(uom)"` | `"quantityuom"` |
| `"weight(uom)"` | `"weightuom"` |

### 6. Construccion del JSON de salida

```groovy
builder {
    row(v_row_list) { rowMap ->
        rowMap.each { rowField ->
            "$rowField.key"(rowField.value)   // Nombre dinamico del campo JSON
        }
    }
}
```

La interpolacion `"$rowField.key"` permite nombres de campo dinamicos en el JSON.

### 7. TestRun - Cambio entre archivos CSV de prueba

```groovy
// CSV simple (activo):
File inputFile = new File("$dataDir\\csv_data_with_header.txt")
File outputFile = new File("$dataDir\\csv_data_with_header_to_json_auto_output.txt")

// CSV complejo (comentado - descommentar para probar):
//File inputFile = new File("$dataDir\\csv_complex_with_header.txt")
//File outputFile = new File("$dataDir\\csv_complex_with_header_to_json_auto_output.txt")
```

---

## CSV de entrada soportados

### CSV simple (`csv_data_with_header.txt`)
```
idoc no,order no,ship to,sold to,order date,line-item#,material,quantity,quantity(uom),weight,weight(uom)
888888,5000123456,BBBB-222,AAAA-111,20211201,00001,800111,10.000,pce,20,kgm
```

### CSV complejo (`csv_complex_with_header.txt`)
CSV con mas de 70 columnas (datos de contacto CRM) con campos vacios, comillas y comas embebidas.

---

## Ejemplo de salida (CSV simple)

```json
{
    "row": [
        {
            "idocno": "888888",
            "orderno": "5000123456",
            "shipto": "BBBB-222",
            "soldto": "AAAA-111",
            "orderdate": "20211201",
            "lineitem": "00001",
            "material": "800111",
            "quantity": "10.000",
            "quantityuom": "pce",
            "weight": "20",
            "weightuom": "kgm"
        }
    ]
}
```

---

## Diferencias Auto vs Manual (T09)

| Aspecto | Auto (este archivo) | Manual (`CSV_with_Header_to_JSON_Manual.groovy`) |
|---------|--------------------|-------------------------------------------------|
| Campos de salida | Todos los del CSV | Solo los seleccionados en codigo |
| Nombres JSON | Sanitizados con `formatFieldName` | Definidos manualmente |
| Renombrado | No posible (nombre CSV → sanitizado) | Si (nombre origen → nombre destino) |
| Codigo | Dinamico (funciona con cualquier CSV) | Estatico (especifico para el CSV) |

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ Verificar que `CsvPreference.STANDARD_PREFERENCE` coincida con el delimitador del CSV de entrada
- ✅ Si los nombres de campo JSON resultantes no son validos, activar `.toLowerCase()` en `formatFieldName`
- ⚠️ Con CSV muy complejos, verificar que los campos con comas embebidas esten entre comillas en el CSV
