# T09 - CSV with Header to JSON

## Descripcion

Convierte un archivo CSV que incluye una fila de cabecera (header row) a formato JSON. Incluye dos variantes: **Auto** (mapeo automatico de todos los campos usando los nombres del header) y **Manual** (seleccion y renombrado manual de campos especificos).

## Transformacion

```
INPUT:  CSV con header row (primera linea = nombres de columnas)
OUTPUT: JSON Flat (array de rows)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `CSV_with_Header_to_JSON_Auto.groovy` | Mapeo automatico (todos los campos) |
| `CSV_with_Header_to_JSON_Manual.groovy` | Mapeo manual (campos seleccionados) |
| `Data/csv_data_with_header.txt` | CSV simple con header |
| `Data/csv_complex_with_header.txt` | CSV complejo (muchas columnas) |
| `Data/csv_data_with_header_to_json_auto_output.txt` | Salida Auto con csv simple |
| `Data/csv_data_with_header_to_json_manual_output.txt` | Salida Manual con csv simple |
| `Data/csv_complex_with_header_to_json_auto_output.txt` | Salida Auto con csv complejo |
| `Data/csv_complex_with_header_to_json_manual_output.txt` | Salida Manual con csv complejo |

## Librerias utilizadas

```groovy
import groovy.json.JsonOutput
import groovy.json.StreamingJsonBuilder
import org.supercsv.cellprocessor.*
import org.supercsv.cellprocessor.constraint.*
import org.supercsv.cellprocessor.ift.*
import org.supercsv.io.*
import org.supercsv.prefs.*
import org.supercsv.quote.*
```

- **SuperCSV** (`org.supercsv`) - libreria para lectura/escritura de CSV disponible en SAP CPI
- `CsvMapReader` - lector CSV que mapea a Map por nombre de columna
- `CsvPreference.STANDARD_PREFERENCE` - preferencia estandar (coma, comillas dobles, CRLF)

## Configuracion CSV

### Preferencia estandar (usada por defecto)
```groovy
ICsvMapReader mapReader = new CsvMapReader(new StringReader(body), CsvPreference.STANDARD_PREFERENCE)
```

### Preferencia personalizada (comentada, disponible para modificar)
```groovy
char quoteChar = '"'
int delimiterChar = ','
String endOfLine = "\r\n"
CsvPreference customCsvPreference = new CsvPreference.Builder(quoteChar, delimiterChar, endOfLine).build()
```

## Variante AUTO

Lee el header automaticamente y genera el JSON con **todos los campos** del CSV usando los nombres del header como claves JSON (despues de sanitizar caracteres especiales).

### Funcion de formateo de nombre de campo
```groovy
def formatFieldName(String fieldName) {
    fieldName = fieldName.replaceAll("[^a-zA-Z0-9_]", "")
    // Elimina todos los caracteres que no sean letras, numeros o guion bajo
    return fieldName
}
```

**Ejemplo:** `"idoc no"` → `"idocno"` | `"line-item#"` → `"lineitem"` | `"quantity(uom)"` → `"quantityuom"`

### Flujo Auto
```groovy
String[] header = mapReader.getHeader(true)  // Lee header y avanza al primer dato
// ...
while ((rowMap = mapReader.read(header, processor)) != null) {
    def rowMapRenamed = [:]
    header.each { this_field ->
        def fieldName = formatFieldName(this_field)  // Sanitizar nombre
        rowMapRenamed.put(fieldName, rowMap[this_field])
    }
    v_row_list.add(rowMapRenamed)
}
```

## Variante MANUAL

Lee el header pero solo extrae **campos seleccionados**, con posibilidad de renombrarlos.

### Flujo Manual
```groovy
while ((rowMap = mapReader.read(header, processor)) != null) {
    v_row_list.add(rowMap)
}

builder {
    row(v_row_list) { rowMap ->
        "idoc_no"(rowMap["idoc no"])        // renombra "idoc no" → "idoc_no"
        "order_no"(rowMap["order no"])       // renombra "order no" → "order_no"
        "line_item"(rowMap["line-item#"])    // renombra "line-item#" → "line_item"
        "material"(rowMap["material"])
        "quantity"(rowMap["quantity"])
        "quantity_uom"(rowMap["quantity(uom)"])
    }
}
```

## Ejemplo de entrada (CSV simple con header)

```csv
idoc no,order no,ship to,sold to,order date,line-item#,material,quantity,quantity(uom),weight,weight(uom)
888888,5000123456,BBBB-222,AAAA-111,20211201,00001,800111,10.000,pce,20,kgm
888888,5000123456,BBBB-222,AAAA-111,20211201,00002,800222,100.000,pce,200,kgm
```

## Ejemplo de salida Auto (JSON)

```json
{
    "row": [
        {
            "idocno": "888888",
            "orderno": "5000123456",
            "shipto": "BBBB-222",
            "soldto": "AAAA-111",
            "orderdate": "20211201",
            "lineitem": "00001",
            "material": "800111",
            "quantity": "10.000",
            "quantityuom": "pce",
            "weight": "20",
            "weightuom": "kgm"
        }
    ]
}
```

## Ejemplo de salida Manual (JSON)

```json
{
    "row": [
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "line_item": "00001",
            "material": "800111",
            "quantity": "10.000",
            "quantity_uom": "pce"
        }
    ]
}
```

## Diferencias Auto vs Manual

| Aspecto | Auto | Manual |
|---------|------|--------|
| Campos de salida | Todos los del CSV | Solo los seleccionados |
| Nombres de campo | Sanitizados automaticamente | Definidos por el desarrollador |
| Flexibilidad | Alta (no requiere codigo especifico) | Alta (control total del output) |
| Uso tipico | Prototipos / CSV dinamicos | Produccion / Campos conocidos |

## CSV Complejo de ejemplo

El archivo `csv_complex_with_header.txt` contiene datos de contacto CRM con mas de 70 columnas, para demostrar el manejo de CSV complejos con campos vacios y datos con comas entre comillas.
