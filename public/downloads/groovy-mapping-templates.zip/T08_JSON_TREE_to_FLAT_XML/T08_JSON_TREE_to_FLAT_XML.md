# T08 - JSON Tree to Flat XML

## Descripcion

Convierte una estructura JSON jerarquica (arbol) a un XML plano (flat) donde cada elemento `<row>` contiene todos los campos de cabecera, item y schedule en una sola fila. Combina input JSON con output XML plano.

## Transformacion

```
INPUT:  JSON Tree (orders > header + items > schedule)
OUTPUT: XML Flat (<root><row>...</row></root> - una fila por schedule)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `JSON_Tree_to_Flat_XML.groovy` | Script principal de mapeo |
| `Data/json_tree.txt` | Datos de entrada de ejemplo (JSON Tree) |
| `Data/json_tree_to_flat_xml_output.txt` | Salida esperada (XML Flat) |

## Librerias utilizadas

```groovy
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.xml.*
```

- `JsonSlurper` - para parsear el input JSON Tree
- `StreamingMarkupBuilder` - para construir el output XML Flat
- `XmlUtil.serialize` - para formatear el XML resultante

## Comparacion de templates de flattenning

| Template | Input | Output |
|----------|-------|--------|
| T05 | IDOC XML | JSON Flat |
| T06 | IDOC XML | XML Flat |
| T07 | JSON Tree | JSON Flat |
| **T08** | **JSON Tree** | **XML Flat** |

## Logica de flattenning

Identica a T07 para la extraccion de datos (triple iteracion orders > items > schedules), pero la escritura usa `StreamingMarkupBuilder`:

```groovy
def writer = builder.bind {
    mkp.xmlDeclaration()
    root {
        v_row_list.each { this_row ->
            row {
                idoc_no(this_row.idoc_no)
                order_no(this_row.order_no)
                ship_to(this_row.ship_to)
                sold_to(this_row.sold_to)
                order_date(this_row.order_date)
                line_item(this_row.line_item)
                material(this_row.material)
                schedule_qty(this_row.schedule_qty)
                schedule_date(this_row.schedule_date)
            }
        }
    }
}
```

## Campos de entrada vs salida

| Campo JSON entrada | Elemento XML salida |
|--------------------|---------------------|
| `header.idoc_no` | `<idoc_no>` |
| `header.order_no` | `<order_no>` |
| `header.ship_to` | `<ship_to>` |
| `header.sold_to` | `<sold_to>` |
| `header.order_date` | `<order_date>` |
| `item.line_item` | `<line_item>` |
| `item.material` | `<material>` |
| `item.schedule.schedule_qty` | `<schedule_qty>` |
| `item.schedule.schedule_date` | `<schedule_date>` |

## Estructura del script

```groovy
def Message processData(Message message)  // Entry point CPI
void TestRun()                            // Solo para debug local
def DoMapping(String body, Map headers, Map properties)  // Logica principal
```

> **Nota CPI:** Comentar `TestRun()` antes de subir a SAP CPI.

## Ejemplo de salida (XML Flat)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <order_date>20211201</order_date>
    <line_item>00001</line_item>
    <material>800111</material>
    <schedule_qty>10.000</schedule_qty>
    <schedule_date>20211210</schedule_date>
  </row>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <order_date>20211201</order_date>
    <line_item>00002</line_item>
    <material>800222</material>
    <schedule_qty>40.000</schedule_qty>
    <schedule_date>20211210</schedule_date>
  </row>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <order_date>20211201</order_date>
    <line_item>00002</line_item>
    <material>800222</material>
    <schedule_qty>60.000</schedule_qty>
    <schedule_date>20211220</schedule_date>
  </row>
</root>
```
