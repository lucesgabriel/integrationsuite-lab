# JSON_Tree_to_Flat_XML.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T08 |
| **Archivo** | `JSON_Tree_to_Flat_XML.groovy` |
| **Conversion** | JSON Tree → XML Flat (`<root><row>`) |
| **Formato entrada** | JSON jerarquico |
| **Formato salida** | XML plano |
| **Patron** | Flattenning (aplanamiento) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.xml.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\json_tree.txt")
    File outputFile = new File("$dataDir\\json_tree_to_flat_xml_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {
    def InputPayload = new JsonSlurper().parseText(body)

    def builder = new StreamingMarkupBuilder()

    def v_row_list = []

    InputPayload.orders.each { this_order ->

        def this_header = this_order.header

        String v_idoc_no    = this_header.idoc_no    ?: ""
        String v_order_no   = this_header.order_no   ?: ""
        String v_ship_to    = this_header.ship_to    ?: ""
        String v_sold_to    = this_header.sold_to    ?: ""
        String v_order_date = this_header.order_date ?: ""

        this_order.item.each { this_item ->
            String v_line_item = this_item.line_item ?: ""
            String v_material  = this_item.material  ?: ""

            this_item.schedule.each { this_schedule ->
                String v_schedule_qty  = this_schedule.schedule_qty  ?: ""
                String v_schedule_date = this_schedule.schedule_date ?: ""

                def v_row = [:]
                v_row.idoc_no       = v_idoc_no
                v_row.order_no      = v_order_no
                v_row.ship_to       = v_ship_to
                v_row.sold_to       = v_sold_to
                v_row.order_date    = v_order_date
                v_row.line_item     = v_line_item
                v_row.material      = v_material
                v_row.schedule_qty  = v_schedule_qty
                v_row.schedule_date = v_schedule_date

                v_row_list.add(v_row)
            }
        }
    }

    // MAPPING
    def writer = builder.bind {
        mkp.xmlDeclaration()

        root {
            v_row_list.each{ this_row ->
                row {
                    idoc_no(this_row.idoc_no)
                    order_no(this_row.order_no)
                    ship_to(this_row.ship_to)
                    sold_to(this_row.sold_to)
                    order_date(this_row.order_date)
                    line_item(this_row.line_item)
                    material(this_row.material)
                    schedule_qty(this_row.schedule_qty)
                    schedule_date(this_row.schedule_date)
                }
            }
        }
    }

    // WRITING
    //def output = writer.toString()
    def output = XmlUtil.serialize(writer.toString())

    return output
}
```

---

## Explicacion por secciones

### 1. Posicion en la matriz de templates

T08 combina el **input de T07** con el **output de T06**:

```
T07: JSON Tree → JSON Flat  (misma extraccion, diferente escritura)
T06: IDoc XML  → XML Flat   (diferente extraccion, misma escritura)
T08: JSON Tree → XML Flat   (extraccion de T07 + escritura de T06)
```

### 2. Fase de extraccion (identica a T07)

```groovy
def InputPayload = new JsonSlurper().parseText(body)  // JSON → objeto Groovy

// Triple iteracion: orders > items > schedules
InputPayload.orders.each { this_order ->
    def this_header = this_order.header
    // extraccion de campos con operador Elvis ?: ""
    // ...
    this_order.item.each { this_item ->
        // ...
        this_item.schedule.each { this_schedule ->
            def v_row = [:]
            // llenar fila plana
            v_row_list.add(v_row)
        }
    }
}
```

### 3. Fase de escritura XML (identica a T06)

```groovy
def builder = new StreamingMarkupBuilder()

def writer = builder.bind {
    mkp.xmlDeclaration()    // <?xml version="1.0" encoding="UTF-8"?>

    root {                  // <root>
        v_row_list.each { this_row ->
            row {           // <row> por cada fila plana
                idoc_no(this_row.idoc_no)
                order_no(this_row.order_no)
                ship_to(this_row.ship_to)
                sold_to(this_row.sold_to)
                order_date(this_row.order_date)
                line_item(this_row.line_item)
                material(this_row.material)
                schedule_qty(this_row.schedule_qty)
                schedule_date(this_row.schedule_date)
            }
        }
    }
}

def output = XmlUtil.serialize(writer.toString())
```

### 4. Tabla comparativa de los 4 templates de flattenning

| Template | Input Parser | v_row_list origen | Output Builder | Serializacion |
|----------|-------------|-------------------|----------------|---------------|
| T05 | `XmlSlurper` (IDoc) | IDoc segments | `StreamingJsonBuilder` | `JsonOutput.prettyPrint` |
| T06 | `XmlSlurper` (IDoc) | IDoc segments | `StreamingMarkupBuilder` | `XmlUtil.serialize` |
| T07 | `JsonSlurper` | JSON tree | `StreamingJsonBuilder` | `JsonOutput.prettyPrint` |
| **T08** | **`JsonSlurper`** | **JSON tree** | **`StreamingMarkupBuilder`** | **`XmlUtil.serialize`** |

### 5. Output XML generado

```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <order_date>20211201</order_date>
    <line_item>00001</line_item>
    <material>800111</material>
    <schedule_qty>10.000</schedule_qty>
    <schedule_date>20211210</schedule_date>
  </row>
  <row>...</row>
  <row>...</row>
</root>
```

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ No requiere propiedades del mensaje
- ✅ Compatible como input para T14 (XML Flat → CSV)
- ✅ `groovy.json.*` y `groovy.xml.*` ambos necesarios (JSON input + XML output)
