# T06 - IDOC to Flat XML

## Descripcion

Convierte un IDoc SAP (ORDERS05 XML) a un XML plano (flat) donde cada elemento `<row>` representa una linea de schedule expandida con todos los datos de cabecera e item repetidos. Es el equivalente XML del template T05.

## Transformacion

```
INPUT:  IDOC XML (ORDERS05) - Estructura jerarquica
OUTPUT: XML Flat (<root><row>...</row></root> - una fila por schedule)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `IDOC_Orders_to_Flat_XML.groovy` | Script principal de mapeo |
| `Data/idoc_orders.txt` | Datos de entrada de ejemplo |
| `Data/idoc_orders_to_flat_xml_output.txt` | Salida esperada (XML Flat) |

## Librerias utilizadas

```groovy
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*
```

- `XmlSlurper` - para parsear el input IDoc XML
- `StreamingMarkupBuilder` - para construir el output XML
- `XmlUtil.serialize` - para formatear el XML resultante

## Comparacion T05 vs T06

| Aspecto | T05 (Flat JSON) | T06 (Flat XML) |
|---------|-----------------|-----------------|
| Librerias | `groovy.json.*` | `groovy.xml.*` |
| Builder | `StreamingJsonBuilder` | `StreamingMarkupBuilder` |
| Formato final | `JsonOutput.prettyPrint` | `XmlUtil.serialize` |
| Estructura raiz | `{ "row": [...] }` | `<root><row>...</row></root>` |
| Declaracion XML | No aplica | `mkp.xmlDeclaration()` |

## Campos en cada `<row>` de salida

| Elemento XML | Fuente IDoc |
|--------------|-------------|
| `<idoc_no>` | `EDI_DC40/DOCNUM` (sin ceros) |
| `<order_no>` | `E1EDK01/BELNR` |
| `<ship_to>` | `E1EDKA1[PARVW=WE]/PARTN` |
| `<sold_to>` | `E1EDKA1[PARVW=AG]/PARTN` |
| `<order_date>` | `E1EDK03[IDDAT=012]/DATUM` |
| `<line_item>` | `E1EDP01/POSEX` |
| `<material>` | `E1EDP19[QUALF=001]/IDTNR` (sin ceros) |
| `<schedule_qty>` | `E1EDP20/WMENG` |
| `<schedule_date>` | `E1EDP20/EDATU` |

## Logica de flattenning (identica a T05)

La logica de aplanamiento es identica a T05. Se acumula una lista `v_row_list` de mapas con los campos planos, luego se genera el XML:

```groovy
def v_row_list = []
// ... llenado del v_row_list con triple iteracion ...

def writer = builder.bind {
    mkp.xmlDeclaration()
    root {
        v_row_list.each { this_row ->
            row {
                idoc_no(this_row.idoc_no)
                order_no(this_row.order_no)
                // ...
            }
        }
    }
}
```

## Estructura del script

```groovy
def Message processData(Message message)  // Entry point CPI
void TestRun()                            // Solo para debug local
def DoMapping(String body, Map headers, Map properties)  // Logica principal
```

> **Nota CPI:** Comentar `TestRun()` antes de subir a SAP CPI.

## Ejemplo de salida (XML Flat)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <order_date>20211201</order_date>
    <line_item>00001</line_item>
    <material>800111</material>
    <schedule_qty>10.000</schedule_qty>
    <schedule_date>20211210</schedule_date>
  </row>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <order_date>20211201</order_date>
    <line_item>00002</line_item>
    <material>800222</material>
    <schedule_qty>40.000</schedule_qty>
    <schedule_date>20211210</schedule_date>
  </row>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <order_date>20211201</order_date>
    <line_item>00002</line_item>
    <material>800222</material>
    <schedule_qty>60.000</schedule_qty>
    <schedule_date>20211220</schedule_date>
  </row>
</root>
```

## Casos de uso tipicos

- Integracion con sistemas de base de datos relacionales
- Generacion de feeds para procesos batch
- Preparacion de datos para conversion a CSV (ver T14)
- Integracion con sistemas que no soportan XML jerarquico
