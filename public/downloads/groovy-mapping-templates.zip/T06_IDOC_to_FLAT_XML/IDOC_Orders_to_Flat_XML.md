# IDOC_Orders_to_Flat_XML.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T06 |
| **Archivo** | `IDOC_Orders_to_Flat_XML.groovy` |
| **Conversion** | IDoc XML (ORDERS05) → XML Flat (`<root><row>`) |
| **Formato entrada** | XML (IDoc SAP) |
| **Formato salida** | XML plano |
| **Patron** | Flattenning (aplanamiento) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\idoc_orders.txt")
    File outputFile = new File("$dataDir\\idoc_orders_to_flat_xml_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {
    def InputPayload = new XmlSlurper().parseText(body)

    def builder = new StreamingMarkupBuilder()

    def v_row_list = []

    InputPayload.IDOC.each { this_IDOC ->
        String v_idoc_no = ''
        String v_order_no = ''
        String v_ship_to = ''
        String v_sold_to = ''
        String v_order_date = ''

        v_idoc_no = this_IDOC.EDI_DC40.DOCNUM.toString().replaceFirst("^0*", "")
        v_order_no = this_IDOC.E1EDK01.BELNR.toString()

        this_IDOC.E1EDKA1.each { this_E1EDKA1 ->
            if (this_E1EDKA1.PARVW.toString() == "WE") {
                v_ship_to = this_E1EDKA1.PARTN.toString()
            }
            if (this_E1EDKA1.PARVW.toString() == "AG") {
                v_sold_to = this_E1EDKA1.PARTN.toString()
            }
        }

        this_IDOC.E1EDK03.each { this_E1EDK03 ->
            if (this_E1EDK03.IDDAT.toString() == "012") {
                v_order_date = this_E1EDK03.DATUM.toString()
            }
        }

        this_IDOC.E1EDP01.each { this_E1EDP01 ->
            String v_line_item = this_E1EDP01.POSEX.toString()
            String v_material = ''
            this_E1EDP01.E1EDP19.each { this_E1EDP19 ->
                if (this_E1EDP19.QUALF.toString() == "001") {
                    v_material = this_E1EDP19.IDTNR.toString().replaceFirst("^0*", "")
                }
            }

            this_E1EDP01.E1EDP20.each { this_E1EDP20 ->
                String v_schedule_qty = this_E1EDP20.WMENG.toString()
                String v_schedule_date = this_E1EDP20.EDATU.toString()

                def v_row = [:]
                v_row.idoc_no = v_idoc_no
                v_row.order_no = v_order_no
                v_row.ship_to = v_ship_to
                v_row.sold_to = v_sold_to
                v_row.order_date = v_order_date
                v_row.line_item = v_line_item
                v_row.material = v_material
                v_row.schedule_qty = v_schedule_qty
                v_row.schedule_date = v_schedule_date

                v_row_list.add(v_row)
            }
        }
    }

    // MAPPING
    def writer = builder.bind {
        mkp.xmlDeclaration()

        root {
            v_row_list.each{ this_row ->
                row {
                    idoc_no(this_row.idoc_no)
                    order_no(this_row.order_no)
                    ship_to(this_row.ship_to)
                    sold_to(this_row.sold_to)
                    order_date(this_row.order_date)
                    line_item(this_row.line_item)
                    material(this_row.material)
                    schedule_qty(this_row.schedule_qty)
                    schedule_date(this_row.schedule_date)
                }
            }
        }
    }

    // WRITING
    //def output = writer.toString()
    def output = XmlUtil.serialize(writer.toString())

    return output
}
```

---

## Explicacion por secciones

### 1. Logica de extraccion (identica a T05)

La fase de extraccion y construccion del `v_row_list` es **exactamente identica** a T05. La diferencia reside unicamente en la fase de escritura del output.

### 2. Diferencia en la fase de escritura: XML vs JSON

**T05 (JSON):**
```groovy
def writer = new StringWriter()
def builder = new StreamingJsonBuilder(writer)

builder {                          // Bloque directo del builder
    row(v_row_list) { this_row ->  // Iteracion integrada en el builder
        idoc_no(this_row.idoc_no)
        // ...
    }
}
def output = JsonOutput.prettyPrint(writer.toString())
```

**T06 (XML):**
```groovy
def builder = new StreamingMarkupBuilder()

def writer = builder.bind {        // Retorna el writer via bind{}
    mkp.xmlDeclaration()           // Declaracion XML obligatoria
    root {                         // Elemento raiz <root>
        v_row_list.each { this_row ->  // Iteracion explicita con .each
            row {                  // Elemento <row> por cada fila
                idoc_no(this_row.idoc_no)
                // ...
            }
        }
    }
}
def output = XmlUtil.serialize(writer.toString())
```

### 3. Puntos clave de diferencia

| Aspecto | T05 (Flat JSON) | T06 (Flat XML) |
|---------|-----------------|-----------------|
| Libreria | `groovy.json.*` | `groovy.xml.*` |
| Builder init | `new StreamingJsonBuilder(writer)` | `new StreamingMarkupBuilder()` |
| Binding | `builder { ... }` | `builder.bind { ... }` |
| Declaracion | Sin declaracion | `mkp.xmlDeclaration()` |
| Raiz | `row([...]) { }` → `"row": [...]` | `root { ... }` → `<root>` |
| Iteracion en builder | Integrada en `row(lista)` | Explicita con `.each` |
| Serializacion | `JsonOutput.prettyPrint()` | `XmlUtil.serialize()` |

### 4. Estructura del XML generado

```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
  <row>
    <idoc_no>888888</idoc_no>
    <order_no>5000123456</order_no>
    <ship_to>BBBB-222</ship_to>
    <sold_to>AAAA-111</sold_to>
    <order_date>20211201</order_date>
    <line_item>00001</line_item>
    <material>800111</material>
    <schedule_qty>10.000</schedule_qty>
    <schedule_date>20211210</schedule_date>
  </row>
  <!-- Una <row> por cada schedule line -->
</root>
```

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ No requiere propiedades del mensaje
- ✅ Compatible como input para T14 (XML Flat → CSV)
