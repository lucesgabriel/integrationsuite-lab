# IDOC_Orders_to_Flat_JSON.groovy

## Informacion general

| Propiedad | Valor |
|-----------|-------|
| **Template** | T05 |
| **Archivo** | `IDOC_Orders_to_Flat_JSON.groovy` |
| **Conversion** | IDoc XML (ORDERS05) → JSON Flat (array de rows) |
| **Formato entrada** | XML (IDoc SAP) |
| **Formato salida** | JSON plano |
| **Patron** | Flattenning (aplanamiento) |
| **Fuente** | https://sapintegrationsuitecourse.com |

---

## Codigo completo

```groovy
/* https://sapintegrationsuitecourse.com */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to CPI. This TestRun() for local debug only
TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\idoc_orders.txt")
    File outputFile = new File("$dataDir\\idoc_orders_to_flat_json_output.txt")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {
    def InputPayload = new XmlSlurper().parseText(body)

    def writer = new StringWriter()
    def builder = new StreamingJsonBuilder(writer)

    def v_row_list = []

    InputPayload.IDOC.each { this_IDOC ->
        String v_idoc_no = ''
        String v_order_no = ''
        String v_ship_to = ''
        String v_sold_to = ''
        String v_order_date = ''

        v_idoc_no = this_IDOC.EDI_DC40.DOCNUM.toString().replaceFirst("^0*", "")
        v_order_no = this_IDOC.E1EDK01.BELNR.toString()

        this_IDOC.E1EDKA1.each { this_E1EDKA1 ->
            if (this_E1EDKA1.PARVW.toString() == "WE") {
                v_ship_to = this_E1EDKA1.PARTN.toString()
            }
            if (this_E1EDKA1.PARVW.toString() == "AG") {
                v_sold_to = this_E1EDKA1.PARTN.toString()
            }
        }

        this_IDOC.E1EDK03.each { this_E1EDK03 ->
            if (this_E1EDK03.IDDAT.toString() == "012") {
                v_order_date = this_E1EDK03.DATUM.toString()
            }
        }

        this_IDOC.E1EDP01.each { this_E1EDP01 ->
            String v_line_item = this_E1EDP01.POSEX.toString()
            String v_material = ''
            this_E1EDP01.E1EDP19.each { this_E1EDP19 ->
                if (this_E1EDP19.QUALF.toString() == "001") {
                    v_material = this_E1EDP19.IDTNR.toString().replaceFirst("^0*", "")
                }
            }

            this_E1EDP01.E1EDP20.each { this_E1EDP20 ->
                String v_schedule_qty = this_E1EDP20.WMENG.toString()
                String v_schedule_date = this_E1EDP20.EDATU.toString()

                def v_row = [:]
                v_row.idoc_no = v_idoc_no
                v_row.order_no = v_order_no
                v_row.ship_to = v_ship_to
                v_row.sold_to = v_sold_to
                v_row.order_date = v_order_date
                v_row.line_item = v_line_item
                v_row.material = v_material
                v_row.schedule_qty = v_schedule_qty
                v_row.schedule_date = v_schedule_date

                v_row_list.add(v_row)
            }
        }
    }

    // MAPPING
    builder {
        row(v_row_list) { this_row ->
            idoc_no(this_row.idoc_no)
            order_no(this_row.order_no)
            ship_to(this_row.ship_to)
            sold_to(this_row.sold_to)
            order_date(this_row.order_date)
            line_item(this_row.line_item)
            material(this_row.material)
            schedule_qty(this_row.schedule_qty)
            schedule_date(this_row.schedule_date)
        }
    }

    def output = JsonOutput.prettyPrint(writer.toString())

    return output
}
```

---

## Explicacion por secciones

### 1. Patron de flattenning: dos fases

A diferencia de T01 que construye el JSON directamente durante la iteracion, T05 usa **dos fases**:

**Fase 1:** Extraccion y acumulacion en `v_row_list`
```groovy
def v_row_list = []
// Triple iteracion: IDOC > E1EDP01 > E1EDP20
// Cada fila en v_row_list = una schedule line con todos los datos aplanados
```

**Fase 2:** Construccion del JSON desde la lista
```groovy
builder {
    row(v_row_list) { this_row -> ... }
}
```

### 2. Variables de nivel IDOC (cabecera)

```groovy
InputPayload.IDOC.each { this_IDOC ->
    // Se declaran fuera de los loops internos para que persistan
    String v_idoc_no    = ''
    String v_order_no   = ''
    String v_ship_to    = ''
    String v_sold_to    = ''
    String v_order_date = ''

    // Se llenan una vez por IDOC
    v_idoc_no  = this_IDOC.EDI_DC40.DOCNUM.toString().replaceFirst("^0*", "")
    v_order_no = this_IDOC.E1EDK01.BELNR.toString()
    // ...
}
```

### 3. Variables de nivel item

```groovy
this_IDOC.E1EDP01.each { this_E1EDP01 ->
    // Se declaran dentro del loop de items, fuera del loop de schedules
    String v_line_item = this_E1EDP01.POSEX.toString()
    String v_material  = ''

    // Se busca el material filtrando E1EDP19
    this_E1EDP01.E1EDP19.each { this_E1EDP19 ->
        if (this_E1EDP19.QUALF.toString() == "001") {
            v_material = this_E1EDP19.IDTNR.toString().replaceFirst("^0*", "")
        }
    }
}
```

### 4. Creacion de la fila plana (nivel schedule)

```groovy
this_E1EDP01.E1EDP20.each { this_E1EDP20 ->
    String v_schedule_qty  = this_E1EDP20.WMENG.toString()
    String v_schedule_date = this_E1EDP20.EDATU.toString()

    // Se crea UN mapa por cada E1EDP20 con TODOS los datos
    def v_row = [:]
    v_row.idoc_no       = v_idoc_no      // dato de nivel IDOC
    v_row.order_no      = v_order_no     // dato de nivel IDOC
    v_row.ship_to       = v_ship_to      // dato de nivel IDOC
    v_row.sold_to       = v_sold_to      // dato de nivel IDOC
    v_row.order_date    = v_order_date   // dato de nivel IDOC
    v_row.line_item     = v_line_item    // dato de nivel item
    v_row.material      = v_material     // dato de nivel item
    v_row.schedule_qty  = v_schedule_qty // dato de nivel schedule
    v_row.schedule_date = v_schedule_date // dato de nivel schedule

    v_row_list.add(v_row)
}
```

### 5. Resultado del flattenning con datos de ejemplo

IDoc con 2 items (item1: 1 schedule, item2: 2 schedules) → **3 filas planas**:

| Row | idoc_no | line_item | material | schedule_qty | schedule_date |
|-----|---------|-----------|----------|--------------|---------------|
| 1 | 888888 | 00001 | 800111 | 10.000 | 20211210 |
| 2 | 888888 | 00002 | 800222 | 40.000 | 20211210 |
| 3 | 888888 | 00002 | 800222 | 60.000 | 20211220 |

### 6. Construccion del JSON de salida

```groovy
builder {
    row(v_row_list) { this_row ->
        idoc_no(this_row.idoc_no)
        order_no(this_row.order_no)
        ship_to(this_row.ship_to)
        sold_to(this_row.sold_to)
        order_date(this_row.order_date)
        line_item(this_row.line_item)
        material(this_row.material)
        schedule_qty(this_row.schedule_qty)
        schedule_date(this_row.schedule_date)
    }
}
```

`row(v_row_list) { ... }` genera el array JSON `"row": [...]` iterando la lista.

---

## Comparacion T01 vs T05

| Aspecto | T01 (Tree) | T05 (Flat) |
|---------|-----------|------------|
| Estrategia | Una pasada (build directo) | Dos fases (acumular + build) |
| Estructura salida | Jerarquica (orders > items > schedule) | Plana (una row por schedule) |
| Filas de salida | 1 objeto JSON con anidado | N x M filas planas |
| Repeticion datos | No (datos cabecera una vez) | Si (datos cabecera repetidos en cada fila) |

---

## Notas para SAP CPI

- ✅ Comentar `TestRun()` antes de desplegar
- ✅ No requiere propiedades del mensaje
- ✅ El output contiene el campo `"row"` como array JSON
