# T05 - IDOC to Flat JSON

## Descripcion

Convierte un IDoc SAP (ORDERS05 XML) a un JSON plano (flat) donde cada fila representa una linea de schedule expandida con todos los datos de cabecera e item repetidos. Util para integracion con bases de datos o sistemas que no soportan estructuras jerarquicas.

## Transformacion

```
INPUT:  IDOC XML (ORDERS05) - Estructura jerarquica
OUTPUT: JSON Flat (array de rows con todos los campos en una sola fila)
```

## Archivos

| Archivo | Descripcion |
|---------|-------------|
| `IDOC_Orders_to_Flat_JSON.groovy` | Script principal de mapeo |
| `Data/idoc_orders.txt` | Datos de entrada de ejemplo |
| `Data/idoc_orders_to_flat_json_output.txt` | Salida esperada (JSON Flat) |

## Librerias utilizadas

```groovy
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
```

- `XmlSlurper` - para parsear el input IDoc XML
- `StreamingJsonBuilder` - para construir el output JSON
- `JsonOutput.prettyPrint` - para formatear el JSON

## Concepto: Flattenning (Aplanamiento)

El aplanamiento resuelve la jerarquia IDoc:
```
IDOC (1)
  └── Item (N)
        └── Schedule (M)
```

Generando `1 x N x M` filas planas donde cada row contiene todos los datos de cabecera + item + schedule:

```
Row 1: cabecera + item_1 + schedule_1_1
Row 2: cabecera + item_2 + schedule_2_1
Row 3: cabecera + item_2 + schedule_2_2
```

## Campos en cada row de salida

| Campo | Fuente IDoc |
|-------|-------------|
| `idoc_no` | `EDI_DC40/DOCNUM` (sin ceros) |
| `order_no` | `E1EDK01/BELNR` |
| `ship_to` | `E1EDKA1[PARVW=WE]/PARTN` |
| `sold_to` | `E1EDKA1[PARVW=AG]/PARTN` |
| `order_date` | `E1EDK03[IDDAT=012]/DATUM` |
| `line_item` | `E1EDP01/POSEX` |
| `material` | `E1EDP19[QUALF=001]/IDTNR` (sin ceros) |
| `schedule_qty` | `E1EDP20/WMENG` |
| `schedule_date` | `E1EDP20/EDATU` |

## Logica de flattenning

```groovy
InputPayload.IDOC.each { this_IDOC ->
    // Variables cabecera (nivel IDOC)
    v_idoc_no = ...
    v_order_no = ...
    v_ship_to = ...

    this_IDOC.E1EDP01.each { this_E1EDP01 ->
        // Variables item (nivel item)
        v_line_item = ...
        v_material = ...

        this_E1EDP01.E1EDP20.each { this_E1EDP20 ->
            // Variables schedule (nivel schedule)
            // Una fila por cada schedule line
            v_row = [cabecera + item + schedule]
            v_row_list.add(v_row)
        }
    }
}
```

## Estructura del script

```groovy
def Message processData(Message message)  // Entry point CPI
void TestRun()                            // Solo para debug local
def DoMapping(String body, Map headers, Map properties)  // Logica principal
```

> **Nota CPI:** Comentar `TestRun()` antes de subir a SAP CPI.

## Ejemplo de salida (JSON Flat)

```json
{
    "row": [
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00001",
            "material": "800111",
            "schedule_qty": "10.000",
            "schedule_date": "20211210"
        },
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00002",
            "material": "800222",
            "schedule_qty": "40.000",
            "schedule_date": "20211210"
        },
        {
            "idoc_no": "888888",
            "order_no": "5000123456",
            "ship_to": "BBBB-222",
            "sold_to": "AAAA-111",
            "order_date": "20211201",
            "line_item": "00002",
            "material": "800222",
            "schedule_qty": "60.000",
            "schedule_date": "20211220"
        }
    ]
}
```

## Comparacion con T01 (Tree JSON)

| Aspecto | T01 Tree JSON | T05 Flat JSON |
|---------|---------------|---------------|
| Estructura | Jerarquica anidada | Plana (una fila por schedule) |
| Rows de salida | 1 por IDOC | N x M (items x schedules) |
| Uso tipico | APIs REST / Frontend | Base de datos / CSV |
| Datos cabecera | Una vez en header | Repetidos en cada fila |
