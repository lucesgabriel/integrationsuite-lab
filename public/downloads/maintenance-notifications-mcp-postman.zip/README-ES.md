# MIX-005 — paquete técnico público

Evidencia del laboratorio: 2 de octubre de 2026. Artículo: https://sapintegrationlab.com/blog/maintenance-notifications-mcp-server-ai-agent/
El manual inglés de 23 páginas se descarga por separado desde la web.

## Contenido y alcance

Colección Postman T00–T12, environment de ejemplo, contrato REST OpenAPI 3.0.3 y cuatro policies APIM. No incluye credenciales, hosts privados, respuestas guardadas ni el puente local de Claude.
El contrato REST no es el esquema MCP generado: la creación requiere arguments.requestBody. El patrón numérico del equipo no implementa una allowlist. Los resultados están documentados en el caso; descargar no ejecuta pruebas. La evidencia 429 de T09 sigue pendiente.

## Ejecución manual

1. Importar los dos JSON de postman/. Seleccionar el environment y completar localmente mcpUrl, tokenUrl, clientId y clientSecret de la suscripción. No compartir exports con secretos.
2. T00 envía grant_type=client_credentials en el formulario. Si el Token URL emitido ya contiene ese parámetro, adaptar el body para evitar duplicarlo.
3. Ejecutar T00, T01 initialize, T02 notifications/initialized y T03 tools/list en orden. T01 no envía sessionId. En las siguientes llamadas, usar el header únicamente si el servidor devolvió sesión; deshabilitarlo si no la devolvió.
4. Los scripts almacenan accessToken, sessionId, protocolVersion, lastResponse y lastNotification en el environment. Limpiarlos antes de compartir. Solo procesan respuestas JSON: usar un cliente MCP si la respuesta es SSE. Revisar la especificación correspondiente si se negocia otra revisión.
5. Cambiar refNotification por un aviso existente en el sistema de pruebas. Los números históricos no garantizan datos en otro backend. Ejecutar lecturas y negativos por separado, respetando los límites configurados.
6. T10 invoca creación con prioridad 9, diseñada para rechazo. Usar solo un entorno de pruebas autorizado y con validación activa.
7. T11 CREA UN AVISO REAL. Confirmar permiso y todos los campos, enviar una sola vez, registrar el número, consultar con T12 y comprobar IW23. No ejecutar la colección completa ni repetir una escritura tras un timeout ambiguo; revisar procesamiento e IW28.
8. T09 consulta un aviso para probar límites. Si se usa Runner, aislar únicamente esa petición y partir de una ventana de cuota conocida. No incluir T10/T11 en la ráfaga ni afirmar validación sin capturar 429.

## Ubicación de policies

- ProxyEndpoint, Request del flow condicional GetByNumber: (proxy.pathsuffix MatchesPath "/*") and (request.verb = "GET"). EV_NotifNumberFromPath y después AM_NotifNumberToHeader.
- ProxyEndpoint PreFlow Request: AM_RemoveAgentAuth después de Verify API Key y antes del Basic de CPI generado en TargetEndpoint.
- TargetEndpoint PreFlow Request: AM_NoPathSuffix después de las policies existentes de KVM cifrado y Basic; fija target.copy.pathsuffix=false.
- Las policies previas de API key/KVM/Basic y el iFlow MIX-003 son prerrequisitos externos. Importar XML no adjunta pasos ni crea flows. Activar Edit y verificar su ubicación.

Pendientes: T09, rotación de credenciales, revisión de seguridad y cierre operativo. La confirmación conversacional no equivale a aprobación técnica del servidor; el ZIP no implementa autorización productiva ni idempotencia.
