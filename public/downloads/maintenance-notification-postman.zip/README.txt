SIS-CASE-MIX-003 — prueba inicial

Contenido: collection.json y environment.json para Postman.
Base: prueba documentada en Bruno el 22/09/2026. No es la suite de la revision 1.1.
Respuesta esperada: POST 201 JSON, GET 200 XML de MaintenanceNotificationType.
Los scripts se verifican localmente con fixtures; no constituyen ejecucion contra SAP.

1. Importar ambos JSON y seleccionar el environment.
2. Configurar cpiUrl: URL HTTPS completa terminada en /http/maint-notif/v1.
3. Configurar apimUrl: URL HTTPS completa con /acme/notifications/v1. Conservar cualquier prefijo del tenant.
4. Completar clientId/clientSecret para CPI directo, apikey para APIM. Guardar secretos solo localmente.
5. Sustituir equipment y reportedBy por valores permitidos en el laboratorio.
6. Ejecutar manualmente POST y luego GET dentro de la capa elegida.

Cada POST crea un aviso real; ejecutar ambas carpetas crea dos avisos.
NO reintentar automaticamente un POST de resultado incierto. Reconciliar en SAP/MPL.
Usar datos controlados; la version inicial no serializa caracteres especiales en XML/JSON.
La coleccion limpia IDs previos y solo conserva uno nuevo tras validar status, ID, texto y equipo.
La comparacion de equipo tolera ceros iniciales de SAP; se conserva el valor original.
GET requiere el ID de esa capa y comprueba un unico registro XML con el mismo numero.
La prueba sin API key es un escenario negativo preparado, no una evidencia de ejecucion.
No se afirman contratos 400/404/405/415/429/502 en esta implementacion inicial.
Verificar prioridad, reportante, equipo y datos derivados en SAP (p.ej. IW23).

No exportar ni compartir environments con secretos reales.
Guia: https://sapintegrationlab.com/blog/maintenance-notification-create-query-postman/
