SIS-CASE-MIX-002 — Variante A simple

Importa collection.json y environment.json en Postman y selecciona el environment.
Reemplaza los hosts example.com por los orígenes HTTPS de tu entorno, sin barra final.
Completa cpiClientId y cpiClientSecret localmente. CPI usa /http/maint-simple/v1.
Para APIM completa apiKey. La ruta es /acme/simple/v1 y usa No Auth + header apikey.
Usa un orderNumber existente. 1000 es solo un ejemplo. unknownOrderNumber debe ser inexistente.
Ejecuta primero CPI directo, después APIM y finalmente las pruebas negativas.
Los tests de éxito verifican HTTP 200, JSON, ocho campos y la orden solicitada.
La prueba sin API key espera 401. Las dos requests de diagnóstico CPI no afirman 400/404:
el iFlow simple no implementa ese contrato. Inspecciona la respuesta y el MPL.
La plantilla JSON del iFlow no escapa caracteres especiales. Usa datos controlados.
Guarda secretos solo localmente y no compartas exports que contengan valores reales.
Guía: https://sapintegrationlab.com/blog/maintenance-order-lookup-simple-postman/
